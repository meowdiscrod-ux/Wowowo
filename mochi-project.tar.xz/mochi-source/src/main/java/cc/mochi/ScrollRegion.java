package cc.mochi;

import java.util.function.DoubleConsumer;

public record ScrollRegion(Rect rect, UiLayer layer, DoubleConsumer onScroll) {
   public Rect getRect() {
      return this.rect;
   }

   public UiLayer getLayer() {
      return this.layer;
   }

   public DoubleConsumer getOnScroll() {
      return this.onScroll;
   }
}
