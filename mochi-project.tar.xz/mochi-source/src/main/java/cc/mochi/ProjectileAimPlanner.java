package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.RaycastContext.ShapeType;

public final class ProjectileAimPlanner {
   private static final double[][] doubleArrayArray2;

   public static boolean testWorld(World world, BlockPos blockPos) {
      if (world.isChunkLoaded(blockPos)) {
         ThreadLocalRandom.current().nextInt(12);
         if (world.getWorldBorder().contains(blockPos)) {
            BlockState blockState = world.getBlockState(blockPos);
            if (blockState.isReplaceable()) {
               if (blockState.getFluidState().isEmpty()) {
                  if (Blocks.RAIL.getDefaultState().canPlaceAt(world, blockPos)) {
                     Iterator iterator = RedstoneCartAccess.getHORIZONTAL().iterator();

                     while (iterator.hasNext()) {
                        Direction direction = (Direction)iterator.next();
                        if (world.getBlockState(blockPos.offset(direction).up()).isIn(BlockTags.RAILS)) {
                           return false;
                        }
                     }

                     Box box = new Box(blockPos);

                     return world.getOtherEntities(null, box.expand((0.05)), entity -> testEntity((Entity)entity))
                        .isEmpty();
                  }
               }
            }

            return false;
         }
      }

      return false;
   }

   public static List computeListForWorld(World world, ClientPlayerEntity clientPlayerEntity, List list, Vec3d vec3d, float floatValue, Box box) {
      ProjectileLanding projectileLanding;
      if (list.isEmpty()) {
         projectileLanding = null;
      } else {
         projectileLanding = (ProjectileLanding)list.get(0);
      }

      ProjectileLanding projectileLanding2 = projectileLanding;
      if (projectileLanding2 == null) {
         return List.of();
      } else {
         double blockInteractionRange = clientPlayerEntity.getBlockInteractionRange();
         ArrayList arrayList = new ArrayList();
         List path2 = projectileLanding2.getPath2();

         Iterator iterator = computeSetForList(path2, vec3d, blockInteractionRange + (1.5)).iterator();

         while (iterator.hasNext()) {
            BlockPos blockPos = (BlockPos)iterator.next();
            double doubleValue = vec3d.squaredDistanceTo(blockPos.toCenterPos());

            if (!(doubleValue > (blockInteractionRange + (1.5)) * (blockInteractionRange + 1.5)) && !computeBoxForBlockPos(blockPos).intersects(box)) {
               int intValue = ProjectilePhysics.computeIntForWorld(world, clientPlayerEntity, projectileLanding2, blockPos);
               if (intValue < 1) {
                  ThreadLocalRandom.current().nextInt(4);
               } else if (testWorld(world, blockPos)) {
                  BlockPos blockPos2 = blockPos.down();
                  BlockAim blockAim = computeBlockAimForWorld3(world, clientPlayerEntity, vec3d, blockPos2, Direction.UP, blockPos, floatValue);
                  if ((blockAim != null)) {
                     int[] intArray = new int[list.size()];
                     intArray[0] = intValue;

                     int intValue2 = 1;

                     while (intValue2 < list.size()) {
                        ProjectileLanding projectileLanding3 = (ProjectileLanding)list.get(intValue2);
                        intArray[intValue2] = projectileLanding3 == null ? -1 : ProjectilePhysics.computeIntForWorld(world, clientPlayerEntity, projectileLanding3, blockPos);
                        intValue2++;
                     }

                     arrayList.add(new RailPlacementCandidate(blockPos, blockPos2, blockAim.getPoint2(), blockAim.getYaw2(), blockAim.getPitch2(), intArray));
                  }
               }
            }
         }

         return arrayList;
      }
   }

   public static Vec3d computeVec3dForBlockPos(BlockPos blockPos) {
      double doubleValue = (double)blockPos.getX() + 0.5;
      double doubleValue2 = (double)blockPos.getY() + 0.0625;
      double z = (double)blockPos.getZ();

      return new Vec3d(doubleValue, doubleValue2, z + (0.5));
   }

   public static boolean testWorld2(World world, Item item, BlockPos blockPos) {
      if (!RailItems.itemList.contains(item)) {
         return false;
      } else {
         if (item == Items.POWERED_RAIL) {
            if (blockPos != null) {
               ThreadLocalRandom.current().nextInt(10);

               if (testWorld3(world, blockPos)) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   public static int[] getIntArray2() {
      return ProjectileAxisSwitchMap.intArray2;
   }

   private ProjectileAimPlanner() {
   }

   public static BlockAim computeBlockAimForWorld(World world, Entity entity, Vec3d vec3d, BlockPos blockPos, Direction direction, BlockPos blockPos2, float floatValue, Predicate predicate) {
      double doubleValue = entity instanceof ClientPlayerEntity var10 ? var10.getBlockInteractionRange() : 4.5;
      double[][] doubleArrayArray = doubleArrayArray2;
      int length = doubleArrayArray.length;
      int intValue = 0;

      while (intValue < length) {
         double[] doubleArray = doubleArrayArray[intValue];
         Vec3d vec3d2 = computeVec3dForBlockPos2(blockPos, direction, doubleArray[0], doubleArray[1]);
         if (!(vec3d.squaredDistanceTo(vec3d2) > doubleValue * doubleValue)) {
            float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
            BlockHitResult blockHitResult = computeBlockHitResultForWorld(world, entity, vec3d, floatArray[0], floatArray[1], doubleValue);
            if (blockHitResult != null) {
               if (blockHitResult.getBlockPos().equals(blockPos)) {
                  if (blockHitResult.getSide() != direction) {
                     ThreadLocalRandom.current().nextInt(3);
                  } else {
                     label56: {
                        if (blockPos2 != null) {
                           ThreadLocalRandom.current().nextInt(6);

                           if (!blockPos2.equals(BlockInteractUtils.computeBlockPosForBlockHitResult(blockHitResult))) {
                              break label56;
                           }
                        }

                        if (predicate.test(blockHitResult)) {
                           return new BlockAim(vec3d2, floatArray[0], floatArray[1], blockHitResult);
                        }
                     }
                  }
               }
            }
         }

         intValue++;
      }

      return null;
   }

   private static boolean returnTrue(BlockHitResult blockHitResult) {
      return true;
   }

   public static ProjectileLaunch computeProjectileLaunchForEntity(Entity entity, float floatValue, float floatValue2, float floatValue3) {
      double x = entity.getX();
      double eyeY = entity.getEyeY();

      Vec3d vec3d = new Vec3d(x, eyeY - (0.10000000149011612), entity.getZ());
      Vec3d vec3d2 = new Vec3d(entity.getX() - RedstoneCartAccess.getLastX(entity), entity.getY() - RedstoneCartAccess.getLastY(entity), entity.getZ() - RedstoneCartAccess.getLastZ(entity));
      return computeProjectileLaunchForVec3d(vec3d, floatValue, floatValue2, floatValue3, vec3d2, entity.isOnGround());
   }

   private static boolean testItem(Item item, ItemStack itemStack) {
      if (!itemStack.isEmpty()) {
         if (itemStack.isOf(item)) {
            return true;
         }

         ThreadLocalRandom.current().nextInt(3);
      }

      return false;
   }

   static {
      double[][] doubleArrayArray = new double[13][];

      double[] doubleArray = new double[2];

      doubleArray[0] = (0.5);

      doubleArray[1] = (0.5);
      doubleArrayArray[0] = doubleArray;

      double[] doubleArray2 = new double[2];

      doubleArray2[0] = (0.35);

      doubleArray2[1] = 0.5;
      doubleArrayArray[1] = doubleArray2;
      double[] doubleArray3 = new double[2];

      doubleArray3[0] = (0.65);
      doubleArray3[1] = 0.5;
      doubleArrayArray[2] = doubleArray3;

      double[] doubleArray4 = new double[]{0.5, 0.0};

      doubleArray4[1] = (0.35);
      doubleArrayArray[3] = doubleArray4;
      double[] doubleArray5 = new double[]{0.5, 0.0};

      doubleArray5[1] = (0.65);
      doubleArrayArray[4] = doubleArray5;

      double[] doubleArray6 = new double[2];

      doubleArray6[0] = (0.3);

      doubleArray6[1] = 0.3;
      doubleArrayArray[5] = doubleArray6;
      double[] doubleArray7 = new double[2];

      doubleArray7[0] = (0.7);

      doubleArray7[1] = (0.3);
      doubleArrayArray[6] = doubleArray7;

      double[] doubleArray8 = new double[2];

      doubleArray8[0] = (0.3);

      doubleArray8[1] = (0.7);
      doubleArrayArray[7] = doubleArray8;
      doubleArrayArray[8] = new double[]{0.7, 0.7};

      double[] doubleArray9 = new double[]{0.15, 0.0};

      doubleArray9[1] = (0.5);
      doubleArrayArray[9] = doubleArray9;

      double[] doubleArray10 = new double[2];

      doubleArray10[0] = (0.85);

      doubleArray10[1] = (0.5);
      doubleArrayArray[10] = doubleArray10;

      double[] doubleArray11 = new double[2];

      doubleArray11[0] = (0.5);

      doubleArray11[1] = (0.15);
      doubleArrayArray[11] = doubleArray11;

      double[] doubleArray12 = new double[]{0.5, 0.0};

      doubleArray12[1] = (0.85);
      doubleArrayArray[12] = doubleArray12;
      doubleArrayArray2 = doubleArrayArray;
   }

   public static BlockAim computeBlockAimForWorld2(World world, Entity entity, Vec3d vec3d, BlockPos blockPos, double doubleValue, float floatValue) {
      double blockInteractionRange;
      if (entity instanceof ClientPlayerEntity) {
         ClientPlayerEntity entity2 = (ClientPlayerEntity)entity;
         blockInteractionRange = entity2.getBlockInteractionRange();
      } else {
         blockInteractionRange = (4.5);
      }

      double blockInteractionRange2 = blockInteractionRange;

      for (double[] doubleArray : doubleArrayArray2) {
         double x = (double)blockPos.getX();

         Vec3d vec3d2 = new Vec3d(x + doubleArray[0], (double)blockPos.getY() + doubleValue, (double)blockPos.getZ() + doubleArray[1]);
         if (!(vec3d.squaredDistanceTo(vec3d2) > blockInteractionRange2 * blockInteractionRange2)) {
            float[] floatArray = RotationMath.computeFloatArrayForVec3d(vec3d, vec3d2, floatValue);
            float floatValue2 = floatArray[0];

            BlockHitResult blockHitResult = computeBlockHitResultForWorld(world, entity, vec3d, floatValue2, floatArray[1], blockInteractionRange2);
            if (blockHitResult != null && blockHitResult.getBlockPos().equals(blockPos)) {
               return new BlockAim(vec3d2, floatArray[0], floatArray[1], blockHitResult);
            }
         }
      }

      return null;
   }

   static boolean testWorld3(World world, BlockPos blockPos) {
      if (world.isReceivingRedstonePower(blockPos)) {
         return true;
      } else {
         ThreadLocalRandom.current().nextInt(14);
         Iterator iterator = RedstoneCartAccess.getHORIZONTAL().iterator();

         while (true) {
            if (!iterator.hasNext()) {
               return false;
            }

            Direction direction = (Direction)iterator.next();
            int intValue = -1;

            do {
               ThreadLocalRandom.current().nextInt(15);
               BlockState blockState = world.getBlockState(blockPos.offset(direction).up(intValue));
               if (blockState.isOf(RedstoneCartAccess.getPOWERED_RAIL())) {
                  ThreadLocalRandom.current().nextInt(10);
                  if ((Boolean)blockState.get(RedstoneCartAccess.getPOWERED())) {
                     return true;
                  }
               }

               intValue++;
            } while (intValue <= 1);
         }
      }
   }

   public static List computeListForWorld2(World world, Entity entity, ProjectileLaunch projectileLaunch, Predicate predicate, int intValue) {
      ThreadLocalRandom.current().nextInt(9);
      ArrayList arrayList = new ArrayList(7);
      Iterator iterator = projectileLaunch.computeList().iterator();

      ThreadLocalRandom.current().nextInt(8);

      while (iterator.hasNext()) {
         ThreadLocalRandom.current().nextInt(12);

         Vec3d vec3d = (Vec3d)iterator.next();
         arrayList.add(ProjectilePhysics.computeProjectileLandingForWorld2(world, entity, projectileLaunch.getOrigin(), vec3d, 0, predicate, intValue));
      }

      return arrayList;
   }

   public static BlockAim computeBlockAimForWorld3(World world, Entity entity, Vec3d vec3d, BlockPos blockPos, Direction direction, BlockPos blockPos2, float floatValue) {
      return computeBlockAimForWorld(world, entity, vec3d, blockPos, direction, blockPos2, floatValue, objectValue -> returnTrue((BlockHitResult)objectValue));
   }

   static Vec3d computeVec3dForBlockPos2(BlockPos blockPos, Direction direction, double doubleValue, double doubleValue2) {
      double doubleValue3;
      if (direction.getDirection() == RedstoneCartAccess.getPOSITIVE()) {
         doubleValue3 = (1.0);
      } else {
         doubleValue3 = 0.0;
      }

      double doubleValue32 = doubleValue3;
      Vec3d vec3d;
      switch (getIntArray2()[direction.getAxis().ordinal()]) {
         case 1:

            vec3d = new Vec3d((double)blockPos.getX() + doubleValue32, (double)blockPos.getY() + doubleValue, (double)blockPos.getZ() + doubleValue2);
            break;
         case 2:

            vec3d = new Vec3d((double)blockPos.getX() + doubleValue, (double)blockPos.getY() + doubleValue32, (double)blockPos.getZ() + doubleValue2);
            break;
         case 3:

            vec3d = new Vec3d((double)blockPos.getX() + doubleValue, (double)blockPos.getY() + doubleValue2, (double)blockPos.getZ() + doubleValue32);
            break;
         default:
            byte byteValue = 17;
            ThreadLocalRandom.current().nextInt(16);

            throw new MatchException(null, null);
      }

      return vec3d;
   }

   public static BlockHitResult computeBlockHitResultForWorld(World world, Entity entity, Vec3d vec3d, float floatValue, float floatValue2, double doubleValue) {
      Vec3d vec3d2 = vec3d.add(BlockInteractUtils.computeVec3d(floatValue2, floatValue).multiply(doubleValue));
      BlockHitResult blockHitResult = world.raycast(new RaycastContext(vec3d, vec3d2, ShapeType.OUTLINE, RedstoneCartAccess.getNONE(), entity));
      if (blockHitResult instanceof BlockHitResult) {
         BlockHitResult blockHitResult2 = blockHitResult;
         if (blockHitResult.getType() == RedstoneCartAccess.getBLOCK()) {
            return blockHitResult2;
         }
      }

      return null;
   }

   public static List<Item> getItemList() {
      return RailItems.itemList;
   }

   static Box computeBoxForBlockPos(BlockPos blockPos) {
      double x = (double)blockPos.getX();

      double doubleValue = x + (0.5) - (0.49);
      double y = (double)blockPos.getY();

      double doubleValue2 = y + (0.0625);
      double doubleValue3 = (double)blockPos.getZ() + 0.5 - (0.49);
      double x2 = (double)blockPos.getX();

      double doubleValue4 = x2 + (0.5) + (0.49);
      double y2 = (double)blockPos.getY();

      double doubleValue5 = y2 + (0.0625);

      double doubleValue6 = doubleValue5 + (0.7);
      double z = (double)blockPos.getZ();

      return new Box(doubleValue, doubleValue2, doubleValue3, doubleValue4, doubleValue6, z + (0.5) + (0.49));
   }

   static Set computeSetForList(List list, Vec3d vec3d, double doubleValue) {
      LinkedHashSet linkedHashSet = new LinkedHashSet();
      Box box = new Box(vec3d, vec3d);

      Box box2 = box.expand(doubleValue + (1.0));

      for (int intValue = 1; intValue < list.size(); intValue++) {
         Box box3 = new Box((Vec3d)list.get(intValue - 1), (Vec3d)list.get(intValue)).expand(0.3);
         if (box3.intersects(box2)) {
            int intValue2 = MathHelper.floor(RedstoneCartAccess.getMinY(box3) - 0.0625 - 0.7);
            int intValue3 = MathHelper.floor(box3.maxY - 0.0625);

            for (int intValue4 = MathHelper.floor(box3.minX); intValue4 <= MathHelper.floor(RedstoneCartAccess.getMaxX(box3)); intValue4++) {
               int intValue5 = MathHelper.floor(RedstoneCartAccess.getMinZ(box3));

               while (intValue5 <= MathHelper.floor(box3.maxZ)) {
                  int intValue22 = intValue2;

                  while (intValue22 <= intValue3) {
                     linkedHashSet.add(new BlockPos(intValue4, intValue22, intValue5));
                     intValue22++;
                  }

                  intValue5++;
               }
            }
         }
      }

      return linkedHashSet;
   }

   private static boolean testEntity(Entity entity) {
      return entity instanceof AbstractMinecartEntity;
   }

   public static List computeListForWorld3(World world, ClientPlayerEntity clientPlayerEntity, int intValue, float floatValue) {
      ArrayList arrayList = new ArrayList(intValue + 1);
      Box boundingBox = clientPlayerEntity.getBoundingBox();
      arrayList.add(boundingBox);
      Vec3d vec3d4 = clientPlayerEntity.getVelocity();
      int intValue2 = clientPlayerEntity.isOnGround() ? 1 : 0;
      Vec2f vec2f = RedstoneCartAccess.getInput(clientPlayerEntity) == null ? Vec2f.ZERO : RedstoneCartAccess.getInput(clientPlayerEntity).getMovementInput();
      int intValue3 = RedstoneCartAccess.getInput(clientPlayerEntity) != null && RedstoneCartAccess.getPlayerInput(clientPlayerEntity.input).jump() ? 1 : 0;
      float floatValue2;
      if (clientPlayerEntity.isSneaking()) {
         floatValue2 = (0.3F);
      } else {
         floatValue2 = (1.0F);
      }

      float floatValue3 = floatValue2 * (0.98F);
      double doubleValue = (double)(vec2f.x * floatValue3);

      Vec3d vec3d = new Vec3d(doubleValue, (0.0), (double)(vec2f.y * floatValue3));
      double finalGravity = clientPlayerEntity.getFinalGravity();

      for (int intValue4 = 0; intValue4 < intValue; intValue4++) {
         if (intValue3 != 0 && intValue2 != 0) {
            float floatValue4 = (float)clientPlayerEntity.getAttributeValue(EntityAttributes.JUMP_STRENGTH) + clientPlayerEntity.getJumpBoostVelocityModifier();
            vec3d4 = new Vec3d(RedstoneCartAccess.getX(vec3d4), Math.max((double)floatValue4, vec3d4.y), vec3d4.z);
            if (clientPlayerEntity.isSprinting()) {
               float floatValue5 = floatValue * (float) (Math.PI / 180.0);
               double doubleValue2 = (double)(-MathHelper.sin((double)floatValue5));

               vec3d4 = vec3d4.add(doubleValue2 * (0.2), 0.0, (double)MathHelper.cos((double)floatValue5) * 0.2);
            }
         }

         if (intValue2 != 0) {
            ThreadLocalRandom.current().nextInt(8);
            floatValue2 = world.getBlockState(BlockPos.ofFloored(boundingBox.getCenter().x, RedstoneCartAccess.getMinY(boundingBox) - 0.5000001, boundingBox.getCenter().z)).getBlock().getSlipperiness();
         } else {
            ThreadLocalRandom.current().nextInt(14);

            floatValue2 = (1.0F);
         }

         float floatValue22 = floatValue2;
         if (intValue2 != 0) {
            floatValue2 = clientPlayerEntity.getMovementSpeed();

            floatValue2 *= (0.21600002F) / (floatValue22 * floatValue22 * floatValue22);
         } else if (clientPlayerEntity.isSprinting()) {
            floatValue2 = 0.025999999F;
         } else {
            floatValue2 = 0.02F;
         }

         float floatValue23 = floatValue2;
         vec3d4 = vec3d4.add(computeVec3dForVec3d(vec3d, floatValue23, floatValue));
         Vec3d vec3d2 = Entity.adjustMovementForCollisions(clientPlayerEntity, vec3d4, boundingBox, world, List.of());
         boundingBox = boundingBox.offset(vec3d2);
         arrayList.add(boundingBox);
         double doubleValue3 = Math.abs(RedstoneCartAccess.getY(vec3d2) - vec3d4.y);

         int intValue5 = doubleValue3 > (1.0E-7) ? 1 : 0;
         intValue2 = intValue5 != 0 && vec3d4.y < 0.0 ? 1 : 0;
         float floatValue8 = floatValue22 * (0.91F);
         Vec3d vec3d3;
         doubleValue = Math.abs(RedstoneCartAccess.getX(vec3d2) - vec3d4.x) > 1.0E-7 ? 0.0 : vec3d4.x * (double)floatValue8;
         double y;
         if (intValue5 != 0) {
            y = (0.0);
         } else {
            y = RedstoneCartAccess.getY(vec3d4);
         }

         double doubleValue4 = (y - finalGravity) * 0.98;
         double doubleValue5;
         if (Math.abs(RedstoneCartAccess.getZ(vec3d2) - RedstoneCartAccess.getZ(vec3d4)) > 1.0E-7) {
            doubleValue5 = (0.0);
         } else {
            doubleValue5 = RedstoneCartAccess.getZ(vec3d4) * (double)floatValue8;
         }

         vec3d3 = new Vec3d(doubleValue, doubleValue4, doubleValue5);
         vec3d4 = vec3d3;
      }

      return arrayList;
   }

   public static int computeIntForWorld(World world, BlockPos blockPos) {
      Iterator iterator = getItemList().iterator();

      while (true) {
         if (!iterator.hasNext()) {
            return -1;
         }

         ThreadLocalRandom.current().nextInt(11);
         Item item = (Item)iterator.next();
         if ((testWorld2(world, item, blockPos))) {
            int intValue = InventoryUtils.computeIntForPredicate2(objectValue -> testItem(item, (ItemStack)objectValue));
            if (intValue >= 0) {
               return intValue;
            }
         }
      }
   }

   static Vec3d computeVec3dForVec3d(Vec3d vec3d, float floatValue, float floatValue2) {
      double doubleValue = vec3d.lengthSquared();

      if (doubleValue < (1.0E-7)) {
         return Vec3d.ZERO;
      } else {
         Vec3d vec3d2;
         if (doubleValue > 1.0) {
            vec3d2 = vec3d.normalize();
         } else {
            vec3d2 = vec3d;
         }

         Vec3d vec3d3 = vec3d2.multiply((double)floatValue);

         float floatValue3 = MathHelper.sin((double)(floatValue2 * (0.017453292F)));

         float floatValue4 = MathHelper.cos((double)(floatValue2 * (0.017453292F)));
         return new Vec3d(RedstoneCartAccess.getX(vec3d3) * (double)floatValue4 - RedstoneCartAccess.getZ(vec3d3) * (double)floatValue3, RedstoneCartAccess.getY(vec3d3), vec3d3.z * (double)floatValue4 + RedstoneCartAccess.getX(vec3d3) * (double)floatValue3);
      }
   }

   public static ProjectileLaunch computeProjectileLaunchForVec3d(Vec3d vec3d, float floatValue, float floatValue2, float floatValue3, Vec3d vec3d2, boolean booleanValue) {
      double doubleValue = (double)(-MathHelper.sin((double)(floatValue * (float) (Math.PI / 180.0))) * MathHelper.cos((double)(floatValue2 * (float) (Math.PI / 180.0))));
      double doubleValue2 = (double)(-MathHelper.sin((double)(floatValue2 * (float) (Math.PI / 180.0))));
      double doubleValue3 = (double)(MathHelper.cos((double)(floatValue * (float) (Math.PI / 180.0))) * MathHelper.cos((double)(floatValue2 * (float) (Math.PI / 180.0))));
      Vec3d vec3d3;
      double y;
      if (booleanValue) {
         y = 0.0;
      } else {
         y = vec3d2.y;

         ThreadLocalRandom.current().nextInt(7);
      }

      vec3d3 = new Vec3d(vec3d2.x, y, RedstoneCartAccess.getZ(vec3d2));
      Vec3d vec3d32 = vec3d3;
      return new ProjectileLaunch(vec3d, new Vec3d(doubleValue, doubleValue2, doubleValue3).normalize(), (double)(floatValue3 * 3.0F), vec3d32, null);
   }

   public static ProjectileLaunch createProjectileLaunch(Vec3d vec3d, Vec3d vec3d2) {
      return new ProjectileLaunch(vec3d, vec3d2.normalize(), vec3d2.length(), RedstoneCartAccess.getZERO(), vec3d2);
   }

   public static Vec3d createVec3d(ClientPlayerEntity clientPlayerEntity, Box box) {
      return new Vec3d(RedstoneCartAccess.getX(box.getCenter()), RedstoneCartAccess.getMinY(box) + (clientPlayerEntity.getEyeY() - clientPlayerEntity.getY()), box.getCenter().z);
   }
}
