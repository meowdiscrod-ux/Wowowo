package cc.mochi;

public record PixelPoint(int x, int y) {
   public int getY() {
      return this.y;
   }

   public int getX() {
      return this.x;
   }
}
