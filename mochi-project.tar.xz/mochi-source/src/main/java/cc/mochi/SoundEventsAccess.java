package cc.mochi;

import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public class SoundEventsAccess {
   public static Reference<SoundEvent> getBLOCK_NOTE_BLOCK_PLING() {
      return SoundEvents.BLOCK_NOTE_BLOCK_PLING;
   }

   public static Reference<SoundEvent> getUI_BUTTON_CLICK() {
      return SoundEvents.UI_BUTTON_CLICK;
   }
}
