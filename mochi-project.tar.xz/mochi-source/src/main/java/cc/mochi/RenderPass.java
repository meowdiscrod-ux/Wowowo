package cc.mochi;

enum RenderPass {
   HUD_TEXT,
   WORLD_ESP,
   NOTIFICATIONS,
   ISLAND_HUD,
   SCREENS;

   private static RenderPass[] createValues() {
      return new RenderPass[]{HUD_TEXT, WORLD_ESP, NOTIFICATIONS, ISLAND_HUD, SCREENS};
   }
}
