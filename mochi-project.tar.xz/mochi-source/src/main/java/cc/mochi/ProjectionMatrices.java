package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class ProjectionMatrices {
   public static Matrix4f matrix4f2 = new Matrix4f();
   public static Matrix4f matrix4f = new Matrix4f();

   private static final Vector4f vector4f = new Vector4f();

   public static String computeString() {
      return "proj=" + matrix4f2.toString() + " model=" + matrix4f.toString();
   }

   public static Vec3d computeVec3dForVec3d(Vec3d vec3d) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.getEntityRenderDispatcher() != null && minecraftClient.getEntityRenderDispatcher().camera != null) {
         int framebufferHeight = minecraftClient.getWindow().getFramebufferHeight();
         int framebufferWidth = minecraftClient.getWindow().getFramebufferWidth();
         vector4f.set((float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 1.0F);
         matrix4f.transform(vector4f);
         matrix4f2.transform(vector4f);
         float floatValue = vector4f.w();
         if ((double)Math.abs(floatValue) > 1.0E-5) {
            vector4f.x /= floatValue;
            vector4f.y /= floatValue;
            vector4f.z /= floatValue;
         }

         float floatValue2 = (float)framebufferWidth * (vector4f.x() * 0.5F + 0.5F);
         float floatValue3 = (float)framebufferHeight * (vector4f.y() * 0.5F + 0.5F);
         float floatValue4 = vector4f.z() * 0.5F + 0.5F;
         return new Vec3d((double)(floatValue2 / UiViewport.getScale()), (double)(((float)framebufferHeight - floatValue3) / UiViewport.getScale()), (double)floatValue4);
      } else {
         return null;
      }
   }
}
