package cc.mochi;

import java.awt.Color;

public abstract class UiPanel {
   private String string2;

   private final String string3;
   private float floatState;
   private final String string4;
   private final long timestampNanos;
   private boolean booleanState2 = true;
   private boolean booleanState3;

   protected abstract float computeFloat();

   protected abstract float computeFloat2(float floatValue);

   public static void setBooleanState3(UiPanel uiPanel, boolean booleanState32) {
      uiPanel.booleanState3 = booleanState32;
   }

   public static long getTimestampNanos(UiPanel uiPanel) {
      return uiPanel.timestampNanos;
   }

   protected abstract void updateStateForUiContext(UiContext uiContext, Rect rect, boolean booleanValue, float floatValue);

   private static void updateState13(int intValue, double doubleValue, double doubleValue2) {
   }

   public static void setFloatState(UiPanel uiPanel, float floatState2) {
      uiPanel.floatState = floatState2;
   }

   public boolean checkCondition() {
      return false;
   }

   public boolean getBooleanState22() {
      return this.booleanState2;
   }

   public boolean testUiContext(UiContext uiContext, float floatValue, float floatValue2, float floatValue3) {
      String string = "sheet." + getTimestampNanos(this);
      float floatValue4 = uiContext.getAnimations().spring(string, 0.0F, this.booleanState2 ? 1.0F : 0.0F, 0.34F, 0.86F);
      if (!getBooleanState23(this) && floatValue4 <= 0.02F) {
         return false;
      } else {
         float floatValue5 = floatValue3 * UiContext.clampUnit(floatValue4);
         uiContext.getUiRenderContext().flushBloom();
         PanelRenderer.updateStateForUiContext6(uiContext, floatValue, floatValue2, floatValue5);
         if (this.booleanState2) {
            uiContext.getInputRouter().addModalCatcher(UiLayer.MODAL, () -> this.updateState15());
         }

         float width = this.computeFloat();
         float height = this.computeFloat2(floatValue2);
         Rect rect = Rect.centered(floatValue / 2.0F, floatValue2 / 2.0F + 14.0F * (1.0F - floatValue4), width, height);
         uiContext.getUiRenderContext().pushTransform();
         uiContext.getUiRenderContext().scaleAroundPoint(0.965F + 0.035F * floatValue4, rect.centerX(), rect.centerY());
         PanelRenderer.drawCard(uiContext, rect, floatValue5);
         boolean booleanValue = this.booleanState2 && floatValue4 > 0.6F;
         if (getBooleanState23(this)) {
            uiContext.getInputRouter().addPressRegion(rect, UiLayer.MODAL, (intValue, doubleValue, doubleValue2) -> updateState13(intValue, doubleValue, doubleValue2));
         }

         float floatValue8 = rect.getY() + 22.0F;
         uiContext.drawVerticallyCenteredText(this.string4, rect.getX() + 18.0F, floatValue8 - (this.string3 == null ? 0.0F : 5.0F), TextStyle.TITLE, UiContext.multiplyAlpha(uiContext.getThemeSnapshot().getPrimaryText(), floatValue5));
         if (this.string3 != null) {
            uiContext.drawVerticallyCenteredText(this.string3, rect.getX() + 18.0F, floatValue8 + 8.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(uiContext.getThemeSnapshot().getSecondaryText2(), floatValue5));
         }

         Rect rect2 = new Rect(rect.right() - 34.0F, floatValue8 - 11.0F, 22.0F, 22.0F);
         ButtonWidgets.updateStateForUiContext2(uiContext, string + ".close", rect2, UiLayer.MODAL, Icon.CLOSE, floatValue5, booleanValue ? () -> this.updateState15() : null);
         this.computeFloatForUiContext(uiContext, rect2.getX() - 6.0F, floatValue8, booleanValue, floatValue5);
         PanelRenderer.updateStateForUiContext3(uiContext, rect.getX() + 14.0F, rect.getY() + 44.0F, rect.right() - 14.0F, floatValue5);
         Rect rect3 = new Rect(rect.getX() + 14.0F, rect.getY() + 52.0F, rect.getWidth() - 28.0F, rect.getHeight() - 52.0F - 30.0F);
         this.updateStateForUiContext(uiContext, rect3, booleanValue, floatValue5);
         setFloatState(this, getFloatState(this) + uiContext.getDeltaSeconds());
         float floatValue9 = uiContext.animateToggle(string + ".status", getString22(this) != null && this.floatState < 2.6F, 0.06F);
         if (floatValue9 > 0.01F && this.string2 != null) {
            float floatValue6 = rect.bottom() - 15.0F;
            Color color = this.booleanState3 ? uiContext.getThemeSnapshot().getDanger() : uiContext.getThemeSnapshot().getSuccess();
            uiContext.getUiRenderContext().fillCircle(rect.getX() + 21.0F, floatValue6, 2.5F, UiContext.multiplyAlpha(color, floatValue5 * floatValue9));
            uiContext.drawVerticallyCenteredText(uiContext.ellipsize(getString22(this), TextStyle.SMALL, rect.getWidth() - 50.0F), rect.getX() + 29.0F, floatValue6, TextStyle.SMALL, UiContext.multiplyAlpha(uiContext.getThemeSnapshot().getSecondaryText2(), floatValue5 * floatValue9));
         }

         uiContext.getUiRenderContext().popTransform();
         return true;
      }
   }

   public void updateState6() {
   }

   protected void updateState14(String string22, boolean booleanState32) {
      this.string2 = string22;
      setBooleanState3(this, booleanState32);
      this.floatState = 0.0F;
   }

   public boolean checkCondition3(int intValue, boolean booleanValue) {
      return false;
   }

   public boolean checkCondition2(char charValue) {
      return false;
   }

   public static String getString22(UiPanel uiPanel) {
      return uiPanel.string2;
   }

   public static boolean getBooleanState23(UiPanel uiPanel) {
      return uiPanel.booleanState2;
   }

   public static void setBooleanState2(UiPanel uiPanel, boolean booleanState22) {
      uiPanel.booleanState2 = booleanState22;
   }

   protected UiPanel(String string42, String string32) {
      this.timestampNanos = System.nanoTime();
      this.floatState = 99.0F;
      this.string4 = string42;
      this.string3 = string32;
   }

   protected float computeFloatForUiContext(UiContext uiContext, float floatValue, float floatValue2, boolean booleanValue, float floatValue3) {
      return floatValue;
   }

   public static float getFloatState(UiPanel uiPanel) {
      return uiPanel.floatState;
   }

   public void updateState15() {
      setBooleanState2(this, false);
      this.updateState6();
   }
}
