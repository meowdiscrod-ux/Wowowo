package cc.mochi;

public class Notification {
   private long timestampMillis;
   private NotificationEvent notificationEvent;
   private String string;

   private String string2;

   private long longState;
   private float floatState;
   private boolean booleanState;
   private String string3;

   public void setString32(String string32) {
      setString3(this, string32);
   }

   public long getLongState2() {
      return getLongState(this);
   }

   public void setString2(String string22) {
      this.string2 = string22;
   }

   public static void setString3(Notification notification, String string32) {
      notification.string3 = string32;
   }

   public void setFloatState2(float floatState2) {
      setFloatState(this, floatState2);
   }

   public static String getString3(Notification notification) {
      return notification.string3;
   }

   public void setTimestampMillis(long timestampMillis2) {
      this.timestampMillis = timestampMillis2;
   }

   public void setNotificationEvent(NotificationEvent notificationEvent2) {
      this.notificationEvent = notificationEvent2;
   }

   public long getTimestampMillis() {
      return this.timestampMillis;
   }

   public static void setString(Notification notification, String string4) {
      notification.string = string4;
   }

   public float getFloatState2() {
      return getFloatState(this);
   }

   public static void setFloatState(Notification notification, float floatState2) {
      notification.floatState = floatState2;
   }

   public void setString4(String string4) {
      setString(this, string4);
   }

   public static long getTimestampMillis2(Notification notification) {
      return notification.timestampMillis;
   }

   public void setLongState(long longState2) {
      this.longState = longState2;
   }

   public static String getString(Notification notification) {
      return notification.string;
   }

   public static float getFloatState(Notification notification) {
      return notification.floatState;
   }

   public String computeString() {
      return getString(this) == null ? this.string2 : getString(this);
   }

   public float computeFloat() {
      long longValue = System.currentTimeMillis() - this.timestampMillis;
      return Math.min(1.0F, (float)longValue / (float)this.longState);
   }

   public boolean checkCondition() {
      return System.currentTimeMillis() - getTimestampMillis2(this) > this.longState;
   }

   public static void setBooleanState(Notification notification, boolean booleanState2) {
      notification.booleanState = booleanState2;
   }

   public static long getLongState(Notification notification) {
      return notification.longState;
   }

   public static String getString22(Notification notification) {
      return notification.string2;
   }

   public String getString222() {
      return getString22(this);
   }

   public Notification(String string22, String string32, NotificationEvent notificationEvent2, long longState2) {
      this.string2 = string22;
      this.string3 = string32;
      this.notificationEvent = notificationEvent2;
      this.longState = longState2;
      this.timestampMillis = System.currentTimeMillis();
      this.floatState = 0.0F;
      this.booleanState = false;
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   public NotificationEvent getNotificationEvent() {
      return this.notificationEvent;
   }

   public void setBooleanState2(boolean booleanState2) {
      setBooleanState(this, booleanState2);
   }

   public String getString32() {
      return getString3(this);
   }
}
