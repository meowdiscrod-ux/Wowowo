package cc.mochi.module.events;

import cc.mochi.Module;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.input.MouseClickEvent;
import meteordevelopment.orbit.EventHandler;

public class MouseModuleHandler {
   @EventHandler
   public void onMouseClick(MouseClickEvent mouseClickEvent) {
      int intValue = mouseClickEvent.action();
      if (intValue == 1 || intValue == 0) {
         int intValue2 = mouseClickEvent.button();

         for (Module module : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(MochiClient.INSTANCE.getModuleManager().getModules())) {
            int keyCode = module.getKeyCode();
            if (keyCode != -1 && keyCode != 0) {
               boolean booleanValue = keyCode == intValue2 || keyCode == -(intValue2 + 1) || keyCode == -100 - intValue2;
               if (booleanValue) {
                  if (module.getKeybind().isHoldMode()) {
                     if (intValue == 1 && !module.isEnabled()) {
                        module.setEnabled(true);
                     } else if (intValue == 0 && module.isEnabled()) {
                        module.setEnabled(false);
                     }
                  } else if (intValue == 1) {
                     module.toggle();
                  }
               }
            }
         }
      }
   }
}
