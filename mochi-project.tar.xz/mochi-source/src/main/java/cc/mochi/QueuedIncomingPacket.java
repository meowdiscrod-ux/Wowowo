package cc.mochi;

import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;

public final class QueuedIncomingPacket {
   public final Packet<?> packet;
   public final int entityId;
   public final long queuedAtMillis;
   public final double x;
   public final PacketListener listener;
   public final double z;

   public final double y;

   public QueuedIncomingPacket(PacketListener listener2, Packet packet2, long queuedAtMillis2, int entityId2, double x2, double y2, double z2) {
      this.listener = listener2;
      this.packet = packet2;
      this.queuedAtMillis = queuedAtMillis2;
      this.entityId = entityId2;
      this.x = x2;
      this.y = y2;
      this.z = z2;
   }
}
