package cc.mochi;

import java.util.Comparator;
import java.util.Locale;

public class TextStyleAccess4 {
   public static Locale getROOT() {
      return Locale.ROOT;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static Icon getSEARCH() {
      return Icon.SEARCH;
   }

   public static Comparator<String> getCASE_INSENSITIVE_ORDER() {
      return String.CASE_INSENSITIVE_ORDER;
   }
}
