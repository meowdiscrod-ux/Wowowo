package cc.mochi;

import java.math.RoundingMode;

public class RoundingModeAccess {
   public static RoundingMode getHALF_UP() {
      return RoundingMode.HALF_UP;
   }
}
