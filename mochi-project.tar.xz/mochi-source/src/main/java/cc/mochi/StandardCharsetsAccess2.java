package cc.mochi;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class StandardCharsetsAccess2 {
   public static Charset getUTF_8() {
      return StandardCharsets.UTF_8;
   }
}
