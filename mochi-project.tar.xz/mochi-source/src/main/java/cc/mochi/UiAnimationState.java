package cc.mochi;

public final class UiAnimationState {
   float value;
   long lastAccessFrame;
   float velocity;

   UiAnimationState(float value2) {
      this.value = value2;
   }
}
