package cc.mochi;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager {
   private final List<Notification> notificationList = new ArrayList<>();

   private static final NotificationManager INSTANCE = new NotificationManager();

   public List getNotificationList2() {
      return getNotificationList(this);
   }

   private void updateStateForNotificationEvent(String string, String string2, String string3, NotificationEvent notificationEvent) {
      for (Notification notification : this.notificationList) {
         if (!notification.getBooleanState() && notification.computeString().equals(string)) {
            notification.setString2(string2);
            notification.setString32(string3);
            notification.setNotificationEvent(notificationEvent);
            notification.setTimestampMillis(System.currentTimeMillis());
            return;
         }
      }

      Notification notification2 = new Notification(string2, string3, notificationEvent, 3000L);
      notification2.setString4(string);
      this.notificationList.add(notification2);
      int intValue = 0;

      for (Notification notification3 : this.notificationList) {
         if (!notification3.getBooleanState()) {
            intValue++;
         }
      }

      for (Notification notification4 : this.notificationList) {
         if (intValue <= 5) {
            break;
         }

         if (!notification4.getBooleanState()) {
            notification4.setBooleanState2(true);
            intValue--;
         }
      }
   }

   public void updateState(boolean booleanValue, String string) {
      String string2 = booleanValue ? "Friend added" : "Friend removed";
      String string3 = booleanValue ? string + " will be ignored by combat" : string;
      NotificationEvent notificationEvent = booleanValue ? NotificationEvent.FRIEND_ADDED : NotificationEvent.FRIEND_REMOVED;
      this.updateStateForNotificationEvent2(string2, string3, notificationEvent);
   }

   private void updateStateForNotificationEvent2(String string, String string3, NotificationEvent notificationEvent) {
      this.updateStateForNotificationEvent(string, string, string3, notificationEvent);
   }

   public static NotificationManager getINSTANCE() {
      return INSTANCE;
   }

   public void updateStateForModule(Module module, boolean booleanValue) {
      String string22 = "Module Update";
      String string3 = module.getName() + " - " + (booleanValue ? "Enabled" : "Disabled");
      NotificationEvent notificationEvent = booleanValue ? NotificationEvent.MODULE_ENABLED : NotificationEvent.MODULE_DISABLED;
      this.updateStateForNotificationEvent(module.getName(), string22, string3, notificationEvent);
   }

   public void updateState2(String string3) {
      String string2 = "Rebuff";
      this.updateStateForNotificationEvent2(string2, string3, NotificationEvent.BUFF_EXPIRED);
   }

   public static List<Notification> getNotificationList(NotificationManager notificationManager) {
      return notificationManager.notificationList;
   }
}
