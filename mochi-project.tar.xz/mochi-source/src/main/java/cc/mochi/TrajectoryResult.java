package cc.mochi;

import java.util.List;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

public record TrajectoryResult(List<Vec3d> points, HitResult hit) {
   public List getPoints() {
      return this.points;
   }

   public HitResult getHit() {
      return this.hit;
   }
}
