package cc.mochi;

public final class RotationSpeedScale {
   public static double toSpeedFactor(double doubleValue) {
      double doubleValue2 = (Math.max((1.0), Math.min((10.0), doubleValue)) - 1.0) / 9.0;

      return (1.0) + doubleValue2 * 7.0;
   }

   public static double normalizeLegacySpeed(double doubleValue) {
      if (doubleValue <= (10.0)) {
         return doubleValue;
      } else {
         double doubleValue2 = Math.min(doubleValue, (100.0));

         double doubleValue3 = (doubleValue2 - 1.0) / 99.0;

         return (double)Math.round((1.0) + doubleValue3 * (9.0));
      }
   }

   public static double toPercentage(double doubleValue) {
      double doubleValue2 = toSpeedFactor(doubleValue);

      double doubleValue3 = (doubleValue2 - (1.0)) / 7.0;

      return 1.0 + doubleValue3 * (99.0);
   }

   private RotationSpeedScale() {
   }
}
