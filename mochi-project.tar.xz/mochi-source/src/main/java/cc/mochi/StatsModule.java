package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.MathHelper;

public class StatsModule extends Module implements HudElement {
   private final HudLayout hudLayout;

   private final DoubleSetting paddingSetting;

   private final BooleanSetting camoSetting;

   private final BooleanSetting uppercaseSetting;
   private final BooleanSetting pingSetting;

   private final DoubleSetting bGAlphaSetting;

   private final BooleanSetting statusDotSetting;

   private final BooleanSetting shadowSetting;
   private final BooleanSetting fPSSetting = new BooleanSetting("FPS", true);
   private final BooleanSetting serverSetting;

   private final DoubleSetting sizeSetting;

   private String computeString2() {
      if (mc.getCurrentServerEntry() == null) {
         return mc.isInSingleplayer() ? "Singleplayer" : "";
      } else {
         return mc.getCurrentServerEntry().address;
      }
   }

   @Override
   public float getFloatConstant() {
      return 34.0F;
   }

   @Override
   public float getFloatConstant2() {
      return 120.0F;
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private float computeFloat(String text, float size) {
      return this.uppercaseSetting.getValue() ? LegacyUiTheme.measureText2(text, size) : LegacyUiTheme.measureText(text, size, LegacyUiTheme.fontFace2);
   }

   private static void fillCircle(float centerX, float centerY, Color color) {
      HudBloomRenderer.fillCircle(centerX, centerY, 2.0F, color);
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
               List list = this.computeListForThemeSnapshot(themeSnapshot);
               if (!list.isEmpty()) {
                  float value = (float)this.sizeSetting.getValue();
                  float size = value * 0.8F;
                  float value2 = (float)this.paddingSetting.getValue();

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     float floatValue = value * 1.4F;
                     float floatValue2 = this.statusDotSetting.getValue() ? 7.0F : 0.0F;
                     float[] floatArray = new float[list.size()];
                     float floatValue3 = 0.0F;

                     for (int intValue = 0; intValue < list.size(); intValue++) {
                        StatHudEntry statHudEntry = (StatHudEntry)list.get(intValue);
                        floatArray[intValue] = Math.max(floatValue2 + this.computeFloat(statHudEntry.getLabel(), size), LegacyUiTheme.measureText(statHudEntry.getValue(), value, LegacyUiTheme.fontFace));
                        floatValue3 += floatArray[intValue];
                     }

                     floatValue3 += floatValue * (float)(list.size() - 1);
                     float floatValue4 = LegacyUiTheme.measureFontHeight(size, LegacyUiTheme.fontFace2);
                     float floatValue5 = LegacyUiTheme.measureFontHeight(value, LegacyUiTheme.fontFace);
                     float width = Math.max(list.size() == 1 ? 72.0F : 0.0F, 10.0F + floatValue3 + value2 + 2.0F);
                     float height = value2 * 2.0F + floatValue4 + 2.0F + floatValue5;
                     this.updateState4(width, height);
                     float x = this.hudLayout.getX();
                     float y = this.hudLayout.getY();
                     LegacyUiTheme.updateStateForThemeSnapshot(x, y, width, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), true, themeSnapshot);
                     float x2 = x + 10.0F;
                     float y3 = y + value2;
                     float y2 = y3 + floatValue4 + 2.0F;

                     for (int intValue2 = 0; intValue2 < list.size(); intValue2++) {
                        StatHudEntry statHudEntry2 = (StatHudEntry)list.get(intValue2);
                        float x22 = x2;
                        if (this.statusDotSetting.getValue()) {
                           Color color = statHudEntry2.getColor();
                           float centerX = x2 + 2.0F;
                           float centerY = y3 + floatValue4 / 2.0F;
                           LegacyUiTheme.updateStateForRunnable(0.7F, () -> fillCircle(centerX, centerY, color));
                           x22 = x2 + floatValue2;
                        }

                        this.updateState2(statHudEntry2.getLabel(), x22, y3, size);
                        LegacyUiTheme.drawText(statHudEntry2.getValue(), x2, y2, value, LegacyUiTheme.color3, LegacyUiTheme.fontFace);
                        x2 += floatArray[intValue2];
                        if (intValue2 < list.size() - 1) {
                           HudBloomRenderer.fillRect(x2 + floatValue / 2.0F - 0.5F, y + value2, 1.0F, height - value2 * 2.0F, LegacyUiTheme.createColor(Color.WHITE, 0.08F));
                           x2 += floatValue;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.TOP, 4.0F, HudLayoutMetrics.computeFloat2(4.0F, WatermarkModule.class));
   }

   private void updateState2(String string, float x, float y, float size) {
      if (this.uppercaseSetting.getValue()) {
         LegacyUiTheme.computeFloat(string, x, y, size);
      } else {
         LegacyUiTheme.drawText(string.toLowerCase(Locale.ROOT), x, y, size, LegacyUiTheme.color5, LegacyUiTheme.fontFace2);
      }
   }

   private int computeInt() {
      if (mc.getNetworkHandler() != null && mc.player != null) {
         PlayerListEntry playerListEntry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
         return playerListEntry == null ? -1 : playerListEntry.getLatency();
      } else {
         return -1;
      }
   }

   private List computeListForThemeSnapshot(ThemeSnapshot themeSnapshot) {
      ArrayList arrayList = new ArrayList(3);
      if (this.fPSSetting.getValue()) {
         int currentFps = mc.getCurrentFps();
         arrayList.add(new StatHudEntry("FPS", String.valueOf(currentFps), LegacyUiTheme.computeColorForThemeSnapshot(themeSnapshot, MathHelper.clamp((float)currentFps / 120.0F, 0.0F, 1.0F))));
      }

      if (this.pingSetting.getValue()) {
         int intValue = this.computeInt();
         float floatValue = intValue < 0 ? 0.0F : MathHelper.clamp(1.0F - (float)(intValue - 40) / 260.0F, 0.0F, 1.0F);
         arrayList.add(new StatHudEntry("Ping", intValue < 0 ? "offline" : intValue + " ms", LegacyUiTheme.computeColorForThemeSnapshot(themeSnapshot, floatValue)));
      }

      if (this.serverSetting.getValue()) {
         String string = this.computeString2();
         if (!string.isBlank()) {
            arrayList.add(new StatHudEntry("Server", string, LegacyUiTheme.computeColorForThemeSnapshot2(themeSnapshot)));
         }
      }

      return arrayList;
   }

   public StatsModule() {
      super("Stats", "Frame rate, ping and server readout", -1, ModuleCategory.RENDER);
      this.pingSetting = new BooleanSetting("Ping", true);
      this.serverSetting = new BooleanSetting("Server", false);
      this.uppercaseSetting = new BooleanSetting("Uppercase", true);
      this.statusDotSetting = new BooleanSetting("Status Dot", true);
      this.sizeSetting = new DoubleSetting("Size", 7.0, 24.0, 13.0, 0.5);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 8.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 120.0F, 34.0F);
      this.addSettings(new Setting[]{this.fPSSetting, this.pingSetting, this.serverSetting, this.uppercaseSetting, this.statusDotSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   @Override
   public String computeString() {
      return this.getName();
   }
}
