package cc.mochi;

import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.BufferAllocator;

final class WorldRenderBatch {
   private BufferBuilder bufferBuilder;
   private BufferAllocator bufferAllocator;
   private final RenderLayer renderLayer;

   private final DrawMode drawMode;
   private final boolean booleanState;

   public void updateState() {
      if (this.bufferBuilder != null) {
         try {
            BuiltBuffer builtBuffer = this.bufferBuilder.endNullable();
            if (builtBuffer != null) {
               builtBuffer.close();
            }
         } catch (RuntimeException failure) {
         } finally {
            this.bufferBuilder = null;
         }
      }
   }

   public void updateState2() {
      if (this.bufferBuilder != null) {
         BuiltBuffer builtBuffer = this.bufferBuilder.endNullable();
         this.bufferBuilder = null;
         if (builtBuffer != null) {
            this.renderLayer.draw(builtBuffer);
         }
      }
   }

   public BufferBuilder computeBufferBuilder() {
      if (this.bufferBuilder == null) {
         if (this.bufferAllocator == null) {
            this.bufferAllocator = new BufferAllocator(65536);
         }

         this.bufferBuilder = new BufferBuilder(this.bufferAllocator, this.drawMode, this.booleanState ? VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH : VertexFormats.POSITION_COLOR);
      }

      return this.bufferBuilder;
   }

   public WorldRenderBatch(RenderLayer renderLayer2, DrawMode drawMode2, boolean booleanState2) {
      this.renderLayer = renderLayer2;
      this.drawMode = drawMode2;
      this.booleanState = booleanState2;
   }
}
