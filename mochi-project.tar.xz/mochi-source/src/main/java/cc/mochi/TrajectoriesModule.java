package cc.mochi;

import cc.mochi.event.impl.render.Render3DEvent;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.entity.projectile.SpectralArrowEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.EggItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SnowballItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class TrajectoriesModule extends Module {
   private final BooleanSetting landingReticleSetting;

   private final BooleanSetting trackThrownSetting;
   private final DoubleSetting dotSpacingSetting;
   private final ColorSetting customColorSetting;

   private final BooleanSetting showLandingPointSetting;
   private final DoubleSetting pointSizeSetting;

   private final DoubleSetting trackDurationSSetting;
   private final ChoiceSetting colorModeSetting;

   private final Map<Entity, TrajectoryTrail> trajectoryTrailByEntity;
   private final BooleanSetting throughWallsSetting;

   private final DoubleSetting maxPointsSetting;
   private final ChoiceSetting pathStyleSetting = new ChoiceSetting("Path Style", "Glow Line", "Glow Line", "Dots", "Fading Line");

   private final DoubleSetting lineWidthSetting;

   private static boolean testEntity(Entity entity) {
      return !entity.isSpectator() && entity != mc.player;
   }

   private void updateStateForVec3d(Vec3d pos, Color color, HitResult hitResult, ThemeSnapshot themeSnapshot, boolean booleanValue) {
      long longValue = System.currentTimeMillis();
      float floatValue = (float)(Math.sin((double)longValue / 260.0) + 1.0) * 0.5F;
      double doubleValue = this.pointSizeSetting.getValue() * 0.045;
      if (hitResult instanceof EntityHitResult var35) {
         int rgb = ThemeSnapshot.computeColorForColor(themeSnapshot.getDanger()).getRGB();
         Box box = var35.getEntity().getBoundingBox().expand(0.04 + (double)floatValue * 0.03);
         Render3D.updateStateForBox2(box, Render3D.computeInt2(rgb, 34), booleanValue);
         Render3D.updateStateForBox(box, Render3D.computeFloat(1.6F), Render3D.computeInt2(rgb, 215), booleanValue);
      } else {
         Vec3d vec3d = new Vec3d(0.0, 1.0, 0.0);
         if (hitResult instanceof BlockHitResult var12 && hitResult.getType() == Type.BLOCK) {
            vec3d = Vec3d.of(var12.getSide().getVector());
            pos = var12.getPos();
         }

         Vec3d vec3d2 = pos.add(vec3d.multiply(0.012));
         int rgb2 = color.getRGB();
         int intValue = rgb2 & 16777215;
         Render3D.updateStateForVec3d(vec3d2, vec3d, 0.0, doubleValue * 0.55, -419430401, Render3D.computeInt2(rgb2, 235), 32, booleanValue);
         Render3D.updateStateForVec3d(vec3d2, vec3d, doubleValue * 0.55, doubleValue * (1.9 + (double)floatValue * 0.5), Render3D.computeInt2(rgb2, 70), intValue, 40, booleanValue);
         double doubleValue2 = doubleValue * (2.2 + (double)floatValue * 0.6);
         Render3D.updateStateForVec3d(vec3d2, vec3d, doubleValue2, doubleValue2 + 0.02, Render3D.computeInt2(rgb2, 190), Render3D.computeInt2(rgb2, 190), 48, booleanValue);
         if (this.landingReticleSetting.getValue()) {
            Vec3d vec3d3 = Math.abs(vec3d.y) < 0.9 ? new Vec3d(0.0, 1.0, 0.0) : new Vec3d(1.0, 0.0, 0.0);
            Vec3d vec3d4 = vec3d.crossProduct(vec3d3).normalize();
            Vec3d vec3d5 = vec3d.crossProduct(vec3d4);
            double doubleValue3 = doubleValue2 + 0.07 + (double)floatValue * 0.03;
            double doubleValue4 = 0.09 + (double)floatValue * 0.04;
            float floatValue2 = Render3D.computeFloat(1.4F);
            int intValue2 = Render3D.computeInt2(rgb2, 200);

            for (Vec3d vec3d6 : new Vec3d[]{vec3d4, vec3d4.negate(), vec3d5, vec3d5.negate()}) {
               Vec3d vec3d7 = vec3d2.add(vec3d6.multiply(doubleValue3));
               Vec3d vec3d8 = vec3d2.add(vec3d6.multiply(doubleValue3 + doubleValue4));
               Render3D.updateState9(vec3d7.x, vec3d7.y, vec3d7.z, vec3d8.x, vec3d8.y, vec3d8.z, floatValue2, intValue2, booleanValue);
            }
         }
      }
   }

   private Vec3d computeVec3d(float floatValue, float floatValue2) {
      float floatValue3 = floatValue * (float) (Math.PI / 180.0);
      float floatValue4 = -floatValue2 * (float) (Math.PI / 180.0);
      float floatValue5 = (float)Math.cos((double)floatValue4);
      float floatValue6 = (float)Math.sin((double)floatValue4);
      float floatValue7 = (float)Math.cos((double)floatValue3);
      float floatValue8 = (float)Math.sin((double)floatValue3);
      return new Vec3d((double)(floatValue6 * floatValue7), (double)(-floatValue8), (double)(floatValue5 * floatValue7));
   }

   private boolean testItemStack(ItemStack itemStack) {
      Item item = itemStack.getItem();
      return item instanceof BowItem
         || item instanceof CrossbowItem
         || item instanceof TridentItem
         || item instanceof SnowballItem
         || item instanceof EggItem
         || item instanceof EnderPearlItem
         || item instanceof ExperienceBottleItem
         || item instanceof PotionItem
         || item instanceof FishingRodItem;
   }

   private TrajectoryPoints computeTrajectoryPointsForItemStack(ItemStack itemStack) {
      TrajectoryPoints trajectoryPoints = new TrajectoryPoints();
      List points = trajectoryPoints.points;
      Item item = itemStack.getItem();
      if (item instanceof EnderPearlItem) {
         TrajectoryResult trajectoryResult = TrajectoryPlanner.computeTrajectoryResultForClientPlayerEntity(mc.player, mc.world, this.maxPointsSetting.intValue());
         points.addAll(trajectoryResult.getPoints());
         trajectoryPoints.hitResult = trajectoryResult.getHit();
         return trajectoryPoints;
      } else {
         float tickProgress = mc.getRenderTickCounter().getTickProgress(true);
         double doubleValue = mc.player.lastX + (mc.player.getX() - mc.player.lastX) * (double)tickProgress;
         double doubleValue2 = mc.player.lastY + (mc.player.getY() - mc.player.lastY) * (double)tickProgress;
         double doubleValue3 = mc.player.lastZ + (mc.player.getZ() - mc.player.lastZ) * (double)tickProgress;
         float floatValue = mc.player.lastYaw + (mc.player.getYaw() - mc.player.lastYaw) * tickProgress;
         float floatValue2 = mc.player.lastPitch + (mc.player.getPitch() - mc.player.lastPitch) * tickProgress;
         Vec3d vec3d32 = new Vec3d(doubleValue, doubleValue2 + (double)mc.player.getStandingEyeHeight(), doubleValue3);
         Vec3d vec3d2 = this.computeVec3d(floatValue2, floatValue);
         float floatValue3 = this.computeFloatForItem(item, itemStack);
         vec3d2 = vec3d2.multiply((double)floatValue3);
         float floatValue4 = this.computeFloatForItem2(item);
         float floatConstant = this.getFloatConstant(item);
         int intValue = this.maxPointsSetting.intValue();

         for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
            points.add(vec3d32);
            Vec3d vec3d3 = vec3d32.add(vec3d2);
            HitResult hitResult = this.computeHitResultForVec3d(vec3d32, vec3d3);
            if (hitResult != null && hitResult.getType() != Type.MISS) {
               points.add(hitResult.getPos());
               trajectoryPoints.hitResult = hitResult;
               break;
            }

            vec3d32 = vec3d3;
            vec3d2 = vec3d2.multiply((double)floatConstant);
            vec3d2 = vec3d2.add(0.0, (double)(-floatValue4), 0.0);
            if (vec3d2.lengthSquared() < 0.001) {
               break;
            }
         }

         return trajectoryPoints;
      }
   }

   private void updateState() {
      this.trajectoryTrailByEntity.entrySet().removeIf(entry -> this.testEntry(entry));

      for (Entity entity : mc.world.getEntities()) {
         if (this.testEntity2(entity) && !this.trajectoryTrailByEntity.containsKey(entity) && entity.age < 5 && entity.squaredDistanceTo(mc.player) < 100.0) {
            this.trajectoryTrailByEntity.put(entity, new TrajectoryTrail());
         }
      }

      float tickProgress = mc.getRenderTickCounter().getTickProgress(true);

      for (Entry entry2 : this.trajectoryTrailByEntity.entrySet()) {
         Entity key = (Entity)entry2.getKey();
         TrajectoryTrail value = (TrajectoryTrail)entry2.getValue();
         double doubleValue = key.lastX + (key.getX() - key.lastX) * (double)tickProgress;
         double doubleValue2 = key.lastY + (key.getY() - key.lastY) * (double)tickProgress;
         double doubleValue3 = key.lastZ + (key.getZ() - key.lastZ) * (double)tickProgress;
         Vec3d vec3d = new Vec3d(doubleValue, doubleValue2, doubleValue3);
         if (value.points.isEmpty() || value.points.get(value.points.size() - 1).squaredDistanceTo(vec3d) > 0.01) {
            value.points.add(vec3d);
            if (value.points.size() > this.maxPointsSetting.intValue()) {
               value.points.remove(0);
            }
         }
      }
   }

   private float computeFloatForItem(Item item, ItemStack itemStack) {
      if (item instanceof BowItem) {
         int itemUseTime = mc.player.getItemUseTime();
         float pullProgress = BowItem.getPullProgress(itemUseTime);
         return pullProgress * 3.0F;
      } else if (item instanceof CrossbowItem) {
         return 3.15F;
      } else if (item instanceof TridentItem) {
         return 2.5F;
      } else if (item instanceof SnowballItem || item instanceof EggItem || item instanceof EnderPearlItem) {
         return 1.5F;
      } else if (item instanceof ExperienceBottleItem || item instanceof PotionItem) {
         return 1.0F;
      } else {
         return item instanceof FishingRodItem ? 1.5F : 1.5F;
      }
   }

   private float getFloatConstant(Item item) {
      return 0.99F;
   }

   private boolean testItemStack2(ItemStack itemStack) {
      Item item = itemStack.getItem();
      if (item instanceof BowItem) {
         return mc.player.isUsingItem() && mc.player.getItemUseTime() > 0;
      } else if (item instanceof CrossbowItem) {
         return CrossbowItem.isCharged(itemStack);
      } else if (!(item instanceof TridentItem)) {
         if (item instanceof SnowballItem
            || item instanceof EggItem
            || item instanceof EnderPearlItem
            || item instanceof ExperienceBottleItem
            || item instanceof PotionItem) {
            return true;
         } else {
            return item instanceof FishingRodItem ? mc.player.isUsingItem() : false;
         }
      } else {
         return mc.player.isUsingItem() && mc.player.getItemUseTime() > 0;
      }
   }

   private static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }

   private void updateStateForList(List list, Color color, boolean booleanValue, HitResult hitResult, ThemeSnapshot themeSnapshot) {
      if (list.size() >= 2) {
         boolean value = this.throughWallsSetting.getValue();
         float floatValue = Render3D.computeFloat(this.lineWidthSetting.floatValue());
         String selected = this.pathStyleSetting.getSelected();
         int rgb = color.getRGB();
         int intValue = list.size() - 1;
         if (!selected.equals("Dots")) {
            for (int intValue2 = 0; intValue2 < intValue; intValue2++) {
               Vec3d vec3d = (Vec3d)list.get(intValue2);
               Vec3d vec3d2 = (Vec3d)list.get(intValue2 + 1);
               float floatValue2 = (float)intValue2 / (float)intValue;
               float floatValue3 = booleanValue ? floatValue2 * floatValue2 : MathHelper.clamp(1.0F - floatValue2 * 0.55F, 0.25F, 1.0F);
               if (selected.equals("Glow Line")) {
                  Render3D.updateState9(vec3d.x, vec3d.y, vec3d.z, vec3d2.x, vec3d2.y, vec3d2.z, floatValue + Render3D.computeFloat(3.4F), Render3D.computeInt2(rgb, (int)(26.0F * floatValue3)), value);
                  Render3D.updateState9(vec3d.x, vec3d.y, vec3d.z, vec3d2.x, vec3d2.y, vec3d2.z, floatValue + Render3D.computeFloat(1.4F), Render3D.computeInt2(rgb, (int)(52.0F * floatValue3)), value);
               }

               Render3D.updateState9(vec3d.x, vec3d.y, vec3d.z, vec3d2.x, vec3d2.y, vec3d2.z, floatValue, Render3D.computeInt2(rgb, (int)((float)color.getAlpha() * floatValue3)), value);
            }
         } else {
            int intValue3 = Math.max(1, this.dotSpacingSetting.intValue());

            for (int intValue4 = 0; intValue4 <= intValue; intValue4 += intValue3) {
               Vec3d vec3d3 = (Vec3d)list.get(intValue4);
               float floatValue4 = (float)intValue4 / (float)intValue;
               float floatValue5 = booleanValue ? floatValue4 * floatValue4 : MathHelper.clamp(1.0F - floatValue4 * 0.55F, 0.25F, 1.0F);
               double doubleValue = (0.018 + this.lineWidthSetting.getValue() * 0.012) * (0.55 + 0.45 * (double)floatValue4);
               Render3D.updateState8(vec3d3.x, vec3d3.y, vec3d3.z, doubleValue * 2.2, Render3D.computeInt2(rgb, (int)(60.0F * floatValue5)), Render3D.computeInt2(rgb, 0), value);
               Render3D.updateState8(vec3d3.x, vec3d3.y, vec3d3.z, doubleValue, Render3D.computeInt2(rgb, (int)(235.0F * floatValue5)), Render3D.computeInt2(rgb, (int)(150.0F * floatValue5)), value);
            }
         }

         if (this.showLandingPointSetting.getValue() && !booleanValue) {
            this.updateStateForVec3d((Vec3d)list.get(intValue), color, hitResult, themeSnapshot, value);
         }
      }
   }

   @EventHandler
   private void onRender3D(Render3DEvent render3DEvent) {
      if (!this.isWorldUnavailable() && mc.player != null && mc.world != null) {
         if (!GlCapabilities.checkCondition5()) {
            if (this.trackThrownSetting.getValue()) {
               this.updateState();
            } else {
               this.trajectoryTrailByEntity.clear();
            }

            ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
            ItemStack mainHandStack = mc.player.getMainHandStack();
            if (this.testItemStack(mainHandStack) && this.testItemStack2(mainHandStack)) {
               TrajectoryPoints trajectoryPoints = this.computeTrajectoryPointsForItemStack(mainHandStack);
               if (!trajectoryPoints.points.isEmpty()) {
                  this.updateStateForList(trajectoryPoints.points, this.computeColorForThemeSnapshot(themeSnapshot, 0), false, trajectoryPoints.hitResult, themeSnapshot);
               }
            }

            if (this.trackThrownSetting.getValue()) {
               int intValue = 0;

               for (TrajectoryTrail trajectoryTrail : this.trajectoryTrailByEntity.values()) {
                  if (!trajectoryTrail.points.isEmpty()) {
                     this.updateStateForList(trajectoryTrail.points, this.computeColorForThemeSnapshot(themeSnapshot, intValue), true, null, themeSnapshot);
                     intValue++;
                  }
               }
            }
         }
      }
   }

   private float computeFloatForItem2(Item item) {
      if (item instanceof BowItem || item instanceof CrossbowItem) {
         return 0.05F;
      } else if (item instanceof TridentItem) {
         return 0.05F;
      } else {
         return item instanceof FishingRodItem ? 0.04F : 0.03F;
      }
   }

   public TrajectoriesModule() {
      super("Trajectories", "Shows projectile trajectory path", -1, ModuleCategory.RENDER);
      this.colorModeSetting = new ChoiceSetting("Color Mode", "Mochi Theme", "Mochi Theme", "Gradient", "Custom");
      this.customColorSetting = new ColorSetting("Custom Color", new Color(255, 255, 255, 210));
      this.showLandingPointSetting = new BooleanSetting("Show Landing Point", true);
      this.landingReticleSetting = new BooleanSetting("Landing Reticle", true);
      this.trackThrownSetting = new BooleanSetting("Track Thrown", true);
      this.trackDurationSSetting = new DoubleSetting("Track Duration (s)", 1.0, 10.0, 3.0, 0.5);
      this.lineWidthSetting = new DoubleSetting("Line Width", 1.0, 5.0, 1.8, 0.2);
      this.pointSizeSetting = new DoubleSetting("Point Size", 2.0, 10.0, 5.0, 0.5);
      this.dotSpacingSetting = new DoubleSetting("Dot Spacing", 1.0, 6.0, 2.0, 1.0);
      this.maxPointsSetting = new DoubleSetting("Max Points", 50.0, 500.0, 200.0, 10.0);
      this.throughWallsSetting = new BooleanSetting("Through Walls", true);
      this.trajectoryTrailByEntity = new HashMap<>();
      this.addSettings(new Setting[]{this.pathStyleSetting, this.colorModeSetting, this.customColorSetting, this.showLandingPointSetting, this.landingReticleSetting, this.trackThrownSetting, this.trackDurationSSetting, this.lineWidthSetting, this.pointSizeSetting, this.dotSpacingSetting, this.maxPointsSetting, this.throughWallsSetting});
      this.customColorSetting.setVisibility(() -> this.equals());
   }

   private Boolean equals() {
      return this.colorModeSetting.equals("Custom");
   }

   private boolean testEntry(Entry entry) {
      return ((TrajectoryTrail)entry.getValue()).isOlderThan(this.trackDurationSSetting.getValue()) || !((Entity)entry.getKey()).isAlive() || ((Entity)entry.getKey()).isRemoved();
   }

   private Color computeColorForThemeSnapshot(ThemeSnapshot themeSnapshot, int intValue) {
      String selected = this.colorModeSetting.getSelected();
      switch (selected.hashCode()) {
         case 154295120:
            if (selected.equals("Gradient")) {
               return computeColorForColor(ThemeSnapshot.computeColorForColor(themeSnapshot.getGradientStart()), ThemeSnapshot.computeColorForColor(themeSnapshot.getGradientEnd2()), (float)((double)(intValue % 5) / 4.0));
            }
            break;
         case 2029746065:
            if (selected.equals("Custom")) {
               return this.customColorSetting.getValue();
            }
      }

      return ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
   }

   private boolean testEntity2(Entity entity) {
      return entity instanceof ArrowEntity
         || entity instanceof SpectralArrowEntity
         || entity instanceof TridentEntity
         || entity instanceof SnowballEntity
         || entity instanceof EggEntity
         || entity instanceof EnderPearlEntity
         || entity instanceof ExperienceBottleEntity
         || entity instanceof PotionEntity
         || entity instanceof FishingBobberEntity;
   }

   private HitResult computeHitResultForVec3d(Vec3d vec3d, Vec3d vec3d2) {
      BlockHitResult blockHitResult = mc.world.raycast(new RaycastContext(vec3d, vec3d2, ShapeType.COLLIDER, FluidHandling.NONE, mc.player));
      Box box = new Box(vec3d, vec3d2).expand(1.0);
      EntityHitResult entityCollision = ProjectileUtil.getEntityCollision(mc.world, mc.player, vec3d, vec3d2, box, entity -> testEntity((Entity)entity), 1.0F);
      return (HitResult)(entityCollision != null ? entityCollision : blockHitResult);
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.trajectoryTrailByEntity.clear();
   }
}
