package cc.mochi;

public enum ShieldAttackState {
   IDLE,
   LOWER_SHIELD,
   ATTACK,
   RAISE_SHIELD;

   public static ShieldAttackState getATTACK() {
      return ATTACK;
   }

   private static ShieldAttackState[] computeShieldAttackStateArray() {
      ShieldAttackState[] shieldAttackStateArray = new ShieldAttackState[]{IDLE, null, null, null};

      shieldAttackStateArray[1] = LOWER_SHIELD;
      shieldAttackStateArray[2] = getATTACK();
      shieldAttackStateArray[3] = getRAISE_SHIELD();
      return shieldAttackStateArray;
   }

   public static ShieldAttackState getRAISE_SHIELD() {
      return RAISE_SHIELD;
   }
}
