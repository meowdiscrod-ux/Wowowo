package cc.mochi;

public enum UiLayer {
   BASE,
   RAISED,
   POPOVER,
   MODAL,
   SYSTEM;

   private static UiLayer[] createValues() {
      return new UiLayer[]{BASE, RAISED, POPOVER, MODAL, SYSTEM};
   }
}
