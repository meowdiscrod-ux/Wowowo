package cc.mochi;

import java.awt.Color;
import java.util.Comparator;

public class UiControlAccess {
   public static ButtonVariant getGHOST() {
      return ButtonVariant.GHOST;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

   public static Icon getCLOSE() {
      return Icon.CLOSE;
   }

   public static ControlTone getDANGER() {
      return ControlTone.DANGER;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Comparator<String> getCASE_INSENSITIVE_ORDER() {
      return String.CASE_INSENSITIVE_ORDER;
   }

   public static Icon getSEARCH() {
      return Icon.SEARCH;
   }

   public static Icon getKEYBOARD() {
      return Icon.KEYBOARD;
   }

   public static TextStyle getTITLE() {
      return TextStyle.TITLE;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static KeybindCaptureState getCAPTURING() {
      return KeybindCaptureState.CAPTURING;
   }

   public static Icon getRESET() {
      return Icon.RESET;
   }
}
