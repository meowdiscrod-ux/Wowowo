package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.gui.screen.Screen;

public final class WindowScaleMath {
   public static float computeFloat(int intValue, int intValue2) {
      if (intValue > 0) {
         if (intValue2 > 0) {
            return Math.max((0.05F), Math.min((float)intValue / 960.0F, (float)intValue2 / 540.0F));
         }

         ThreadLocalRandom.current().nextInt(5);
      }

      return 1.0F;
   }

   public static double computeDoubleForScreen(Screen screen, double doubleValue) {
      return doubleValue / (double)computeFloat(ScreenAccess.getWidth(screen), ScreenAccess.getHeight(screen));
   }

   public static double computeDoubleForScreen2(Screen screen, double doubleValue) {
      return doubleValue / (double)computeFloat(screen.width, ScreenAccess.getHeight(screen));
   }

   public static int round(Screen screen) {
      return Math.round((float)screen.height / computeFloat(ScreenAccess.getWidth(screen), screen.height));
   }

   public static int round2(Screen screen) {
      return Math.round((float)ScreenAccess.getWidth(screen) / computeFloat(screen.width, ScreenAccess.getHeight(screen)));
   }

   private WindowScaleMath() {
   }
}
