package cc.mochi;

import java.awt.Color;
import java.util.List;

public final class ThemeEditorPanel extends UiPanel {
   private final ColorSetting[] colorSettingArray;
   private String string;
   private final ScrollModel scrollModel = new ScrollModel();
   private final ConfirmationDialog confirmationDialog;
   private boolean booleanState;

   private final ColorPicker colorPicker;

   private final TextInputModel textInputModel;

   private boolean light22;

   private static final String[] stringArray = new String[]{"Background", "Surface", "Accent", "Text"};

   private int intState;
   private final TextInputModel textInputModel2 = new TextInputModel(32);

   public static String getString(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.string;
   }

   @Override
   public boolean checkCondition() {
      if (getTextInputModel(this).getBooleanState2() || getTextInputModel2(this).getBooleanState2()) {
         this.updateState6();
         return true;
      } else if (this.booleanState) {
         this.updateState3();
         return true;
      } else {
         return false;
      }
   }

   private void updateStateForUiContext2(UiContext uiContext, Theme theme, Rect rect, float floatValue, float floatValue2, float progress) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      uiContext.getUiRenderContext().drawGlowOutline(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 10.0F, 10.0F + 6.0F * floatValue2, 3.0F + 2.0F * floatValue2, UiRenderContext.withAlpha(theme.getShadow2(), 80.0F * floatValue));
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 10.0F, UiRenderContext.withAlpha(theme.getShellGlass22(), 255.0F * floatValue));
      uiContext.getUiRenderContext()
         .fillAngledGradient(
            rect.getX() - rect.getWidth() * 0.3F,
            rect.getY() - rect.getHeight() * 0.5F,
            rect.getWidth() * 0.9F,
            rect.getHeight() * 1.4F,
            0.0F,
            UiRenderContext.withAlpha(theme.getGradientStart22(), 110.0F * floatValue),
            UiRenderContext.withAlpha(theme.getGradientStart22(), 0.0F),
            1.2F
         );
      uiContext.getUiRenderContext()
         .fillAngledGradient(
            rect.right() - rect.getWidth() * 0.6F,
            rect.getY() + rect.getHeight() * 0.1F,
            rect.getWidth() * 0.9F,
            rect.getHeight() * 1.3F,
            0.0F,
            UiRenderContext.withAlpha(theme.getGradientMid2(), 90.0F * floatValue),
            UiRenderContext.withAlpha(theme.getGradientMid2(), 0.0F),
            1.2F
         );
      float x = rect.getX() + 9.0F;
      float width = rect.getWidth() - 18.0F;
      float y = rect.getY() + 9.0F;
      uiContext.getUiRenderContext().fillRoundedRect(x, y, width, 14.0F, 4.0F, UiRenderContext.withAlpha(theme.getCardGlass(), 235.0F * floatValue));
      uiContext.getUiRenderContext().fillHorizontalGradient(x, y, width, 14.0F, 4.0F, UiRenderContext.withAlpha(theme.getAccent2(), 60.0F * floatValue), UiRenderContext.withAlpha(theme.getAccent2(), 0.0F));
      uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * floatValue);
      uiContext.getUiRenderContext().fillRoundedRect(x + 2.0F, y + 3.5F, 1.8F, 7.0F, 0.9F, UiRenderContext.withAlpha(theme.getAccent2(), 255.0F * floatValue));
      uiContext.getUiRenderContext().popBloom();
      uiContext.getUiRenderContext().fillRoundedRect(x + 7.0F, y + 5.5F, 26.0F, 3.0F, 1.5F, UiRenderContext.withAlpha(theme.getPrimaryText3(), 220.0F * floatValue));
      uiContext.getUiRenderContext().fillRoundedRect(x + width - 16.0F, y + 3.5F, 12.0F, 7.0F, 3.5F, UiRenderContext.withAlpha(theme.getAccent2(), 255.0F * floatValue));
      uiContext.getUiRenderContext().fillCircle(x + width - 7.5F, y + 7.0F, 2.4F, UiRenderContext.withAlpha(Color.WHITE, 255.0F * floatValue));
      uiContext.getUiRenderContext().fillRoundedRect(x, y + 17.0F, width, 14.0F, 4.0F, UiRenderContext.withAlpha(theme.getCardGlass(), 170.0F * floatValue));
      uiContext.getUiRenderContext().fillRoundedRect(x + 7.0F, y + 22.5F, 34.0F, 3.0F, 1.5F, UiRenderContext.withAlpha(theme.getSecondaryText(), 170.0F * floatValue));
      uiContext.getUiRenderContext().fillRoundedRect(x + width - 16.0F, y + 20.5F, 12.0F, 7.0F, 3.5F, UiRenderContext.withAlpha(theme.getControlGlass2(), 255.0F * floatValue));
      float floatValue3 = rect.bottom() - 14.0F;
      uiContext.drawVerticallyCenteredText(uiContext.ellipsize(theme.getName(), TextStyle.STRONG, rect.getWidth() - 50.0F), rect.getX() + 10.0F, floatValue3, TextStyle.STRONG, UiRenderContext.withAlpha(theme.getPrimaryText3(), 255.0F * floatValue));
      Color[] colorArray = new Color[]{theme.getGradientStart22(), theme.getGradientMid2(), theme.getGradientEnd3()};

      for (int intValue = 0; intValue < colorArray.length; intValue++) {
         float centerX = rect.right() - 12.0F - (float)(colorArray.length - 1 - intValue) * 7.0F;
         uiContext.getUiRenderContext().fillCircle(centerX, floatValue3, 3.0F, UiRenderContext.withAlpha(ThemeSnapshot.computeColorForColor(colorArray[intValue]), 255.0F * floatValue));
      }

      Color color = UiContext.blendColors(UiContext.blendColors(ThemeSnapshot.computeColorForColor(theme.getBorder2()), UiIconsAccess.getWHITE(), 0.1F * floatValue2), ThemeSnapshot.computeColorForColor(theme.getAccent2()), progress);
      if (progress > 0.01F) {
         uiContext.getUiRenderContext().pushBloom(themeSnapshot2.computeFloat3(0.6F) * progress * floatValue);
      }

      uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 10.0F, 1.0F + progress * 0.6F, UiRenderContext.withAlpha(color, (120.0F + 135.0F * Math.max(progress, floatValue2)) * floatValue));
      if (progress > 0.01F) {
         uiContext.getUiRenderContext().popBloom();
      }
   }

   public static TextInputModel getTextInputModel(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.textInputModel;
   }

   public static TextInputModel getTextInputModel2(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.textInputModel2;
   }

   public static void setLight22(ThemeEditorPanel themeEditorPanel, boolean light222) {
      themeEditorPanel.light22 = light222;
   }

   public static ColorSetting[] getColorSettingArray(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.colorSettingArray;
   }

   public static int getIntState(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.intState;
   }

   private void updateStateForUiContext3(UiContext uiContext, Rect rect, boolean booleanValue, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect2 = new Rect(rect.getX(), rect.getY(), 196.0F, rect.getHeight());
      Rect rect3 = new Rect(rect2.right() + 14.0F, rect.getY(), rect.getWidth() - 196.0F - 14.0F, rect.getHeight());
      float y5 = rect2.getY();
      Rect rect4 = new Rect(rect2.getX(), y5, rect2.getWidth(), 24.0F);
      TextInputWidget.updateStateForUiContext(uiContext, "themes.name", rect4, UiLayer.MODAL, getTextInputModel2(this), "Name your theme", Icon.PALETTE, floatValue);
      y5 += 34.0F;

      for (int intValue = 0; intValue < this.colorSettingArray.length; intValue++) {
         Rect rect5 = new Rect(rect2.getX(), y5, rect2.getWidth(), 26.0F);
         boolean active = intValue == getIntState(this);
         boolean hovered = booleanValue && uiContext.isHovered(rect5, UiLayer.MODAL);
         float floatValue2 = uiContext.animateHover("themes.color." + intValue, hovered);
         float progress = uiContext.animateToggle("themes.color.sel." + intValue, active, 0.035F);
         PanelRenderer.updateStateForUiContext7(uiContext, rect5, 8.0F, Math.max(floatValue2, progress), floatValue);
         Color color = this.computeColor(intValue);

         uiContext.getUiRenderContext().fillCircle(rect5.getX() + 15.0F, rect5.centerY(), 7.0F, UiContext.multiplyAlpha(color, floatValue));
         uiContext.getUiRenderContext().strokeCircle(rect5.getX() + 15.0F, rect5.centerY(), 8.0F, 1.0F, UiContext.multiplyAlpha(UiContext.blendColors(themeSnapshot2.getHairline2(), themeSnapshot2.getAccent2(), progress), floatValue));
         uiContext.drawVerticallyCenteredText(getStringArray()[intValue], rect5.getX() + 29.0F, rect5.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), floatValue));
         uiContext.drawRightAlignedText(format(color), rect5.right() - 9.0F, rect5.centerY(), TextStyle.CAPTION, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue));
         int intValue2 = intValue;
         if (booleanValue) {
            uiContext.getInputRouter().addClickRegion(rect5, UiLayer.MODAL, () -> this.updateState2(intValue2));
         }

         y5 += 30.0F;
      }

      Rect rect6 = new Rect(rect2.getX(), y5 + 2.0F, rect2.getWidth(), 22.0F);
      uiContext.drawVerticallyCenteredText("Light theme", rect6.getX() + 2.0F, rect6.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue));
      Rect rect7 = PanelHeaderRenderer.createRect(rect6.right(), rect6.centerY());
      PanelHeaderRenderer.updateStateForUiContext(uiContext, "themes.light", rect7, this.light22, uiContext.animateHover("themes.light.h", booleanValue && uiContext.isHovered(rect6, UiLayer.MODAL)), floatValue);
      if (booleanValue) {
         uiContext.getInputRouter().addClickRegion(rect6, UiLayer.MODAL, () -> this.updateState11());
      }

      Rect rect8 = new Rect(rect3.getX(), rect3.getY(), rect3.getWidth(), 74.0F);
      this.updateStateForUiContext2(uiContext, this.computeTheme(), rect8, floatValue, 0.0F, 0.0F);
      float floatValue4 = rect8.bottom() + 12.0F;
      ColorSetting colorSetting = this.colorSettingArray[getIntState(this)];
      uiContext.drawVerticallyCenteredText(getStringArray()[getIntState(this)], rect3.getX(), floatValue4 + 7.0F, TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), floatValue));
      Rect rect9 = new Rect(rect3.right() - 84.0F, floatValue4 - 2.0F, 84.0F, 18.0F);
      if (!this.textInputModel.getBooleanState2()) {
         String string2 = format(this.computeColor(getIntState(this)));
         if (!string2.equals(getTextInputModel(this).toString())) {
            getTextInputModel(this).updateState(string2);
         }
      }

      TextInputWidget.updateStateForUiContext(uiContext, "themes.hex", rect9, UiLayer.MODAL, this.textInputModel, "#RRGGBB", null, floatValue);
      floatValue4 += 24.0F;
      this.colorPicker.updateStateForUiContext2(uiContext, "themes.picker", colorSetting, rect3.getX(), floatValue4, rect3.getWidth(), UiLayer.MODAL, rect, floatValue);
      float floatValue5 = rect.bottom() - 24.0F + 2.0F;
      float floatValue6 = ButtonWidgets.computeFloatForUiContext(uiContext, "Back", Icon.CHEVRON_LEFT);
      Rect rect10 = new Rect(rect2.getX(), floatValue5, floatValue6, 24.0F);
      ButtonWidgets.updateStateForUiContext4(uiContext, "themes.back", rect10, UiLayer.MODAL, ButtonVariant.SECONDARY, "Back", Icon.CHEVRON_LEFT, floatValue, booleanValue ? () -> this.updateState3() : null);
      float floatValue7 = ButtonWidgets.computeFloatForUiContext(uiContext, this.string == null ? "Save theme" : "Save changes", null);
      Rect rect11 = new Rect(rect.right() - floatValue7, floatValue5, floatValue7, 24.0F);
      ButtonWidgets.updateStateForUiContext(
         uiContext,
         "themes.save",
         rect11,
         UiLayer.MODAL,
         ButtonVariant.PRIMARY,
         getString(this) == null ? "Save theme" : "Save changes",
         null,
         !this.textInputModel2.toString().isBlank(),
         floatValue,
         booleanValue ? () -> this.updateState10() : null
      );
      if (this.string != null) {
         float floatValue8 = ButtonWidgets.computeFloatForUiContext(uiContext, "Delete", Icon.TRASH);
         Rect rect12 = new Rect(rect11.getX() - 6.0F - floatValue8, floatValue5, floatValue8, 24.0F);
         String string3 = this.string;
         ButtonWidgets.updateStateForUiContext4(uiContext, "themes.delete", rect12, UiLayer.MODAL, ButtonVariant.GHOST, "Delete", Icon.TRASH, floatValue, booleanValue ? () -> this.updateState9(string3) : null);
      }
   }

   private void updateState() {
      this.updateState4(null);
   }

   private static void updateStateForTheme(boolean booleanValue, Theme theme) {
      if (!booleanValue) {
         ClickGuiModule.themeSetting.select(theme.getName());
         ClientSounds.updateState3();
      }
   }

   private void updateState2(int intState2) {
      this.intState = intState2;
      getTextInputModel(this).updateState3(false);
      ClientSounds.updateState5();
   }

   private void updateState3() {
      this.booleanState = false;
      setString(this, null);
      getTextInputModel2(this).updateState3(false);
      this.textInputModel.updateState3(false);
      ClientSounds.updateState5();
   }

   private void updateState4(String string2) {
      ThemePreset themePreset = string2 == null ? null : ThemeManager.computeThemePreset(string2);
      if (themePreset != null) {
         this.string = themePreset.getName2();
         getTextInputModel2(this).updateState(themePreset.getName2());
         this.setRgb(0, themePreset.getBackground());
         this.setRgb(1, themePreset.getSurface());
         this.setRgb(2, themePreset.getAccent());
         this.setRgb(3, themePreset.getText());
         this.light22 = themePreset.getLight22();
      } else {
         Theme theme = ThemeManager.getOrDefault();
         setString(this, null);
         this.textInputModel2.updateState2();
         this.setRgb(0, theme.getShellGlass22());
         this.setRgb(1, theme.getCardGlass());
         this.setRgb(2, theme.getAccent2());
         this.setRgb(3, theme.getPrimaryText3());
         setLight22(this, theme.getLight2());
      }

      setIntState(this, 2);
      this.textInputModel.updateState3(false);
      getTextInputModel2(this).updateState3(false);
      this.booleanState = true;
      ClientSounds.updateState5();
   }

   public static String[] getStringArray() {
      return stringArray;
   }

   private void updateStateForUiContext4(UiContext uiContext, Rect rect, boolean booleanValue, float opacity) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Rect rect2 = new Rect(rect.right() - 128.0F, rect.getY(), 128.0F, 20.0F);
      uiContext.drawVerticallyCenteredText("Accent", rect.getX(), rect2.centerY(), TextStyle.LABEL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
      cc.mochi.ChoiceDropdown.updateStateForUiContext(uiContext, "themes.accent", rect2, UiLayer.MODAL, List.of("Theme", "Custom"), UiIconsAccess.getAccentSourceSetting().equals("Custom") ? 1 : 0, opacity, booleanValue ? intValue -> select(intValue) : null);
      List list = ThemeManager.unmodifiableList();
      Rect rect3 = new Rect(rect.getX() - 2.0F, rect.getY() + 30.0F, rect.getWidth() + 4.0F, rect.getHeight() - 30.0F);
      float floatValue2 = (rect.getWidth() - 16.0F) / 3.0F;
      int intValue2 = (list.size() + 3 - 1) / 3;
      float contentHeight = (float)intValue2 * 82.0F - 8.0F + 4.0F;
      float floatValue4 = this.scrollModel.update(uiContext, contentHeight, rect3.getHeight());
      uiContext.getInputRouter().addScrollRegion(rect3, UiLayer.MODAL, wheelDelta -> this.scrollModel.scroll(wheelDelta));
      uiContext.getUiRenderContext().pushClip(rect3.getX(), rect3.getY(), rect3.getWidth(), rect3.getHeight());

      for (int intValue3 = 0; intValue3 < list.size(); intValue3++) {
         Theme theme = (Theme)list.get(intValue3);
         Rect rect4 = new Rect(rect.getX() + (float)(intValue3 % 3) * (floatValue2 + 8.0F), rect3.getY() + 2.0F + (float)(intValue3 / 3) * 82.0F - floatValue4, floatValue2, 74.0F);
         if (!(rect4.bottom() < rect3.getY()) && !(rect4.getY() > rect3.bottom())) {
            float floatValue5 = uiContext.getAnimations().exponential("themes.enter." + intValue3, 0.0F, 1.0F, 0.06F + (float)Math.min(intValue3, 12) * 0.012F);
            this.updateStateForUiContext5(uiContext, theme, rect4, rect3, booleanValue, opacity * floatValue5, (1.0F - floatValue5) * 8.0F);
         }
      }

      uiContext.getUiRenderContext().popClip();
      this.scrollModel.drawScrollbar(uiContext, rect3, contentHeight, opacity);
   }

   private void updateState5(String string2) {
      if (ThemeManager.checkCondition2(string2)) {
         this.updateState14("Deleted ‘" + string2 + "’", false);
         this.updateState3();
      } else {
         this.updateState14("Couldn't delete ‘" + string2 + "’", true);
         ClientSounds.updateState2();
      }
   }

   public static boolean getBooleanState(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.booleanState;
   }

   private static void select(int intValue) {
      UiIconsAccess.getAccentSourceSetting().select(intValue == 1 ? "Custom" : "Theme");
   }

   @Override
   public void updateState6() {
      getTextInputModel2(this).updateState3(false);
      this.textInputModel.updateState3(false);
   }

   public static void setString(ThemeEditorPanel themeEditorPanel, String string2) {
      themeEditorPanel.string = string2;
   }

   @Override
   public boolean checkCondition2(char charValue) {
      if (!getBooleanState(this)) {
         return false;
      } else if (getTextInputModel(this).getBooleanState2()) {
         if (charValue != '#' && Character.digit(charValue, 16) < 0) {
            return true;
         } else {
            boolean booleanValue = getTextInputModel(this).checkCondition3(charValue);
            this.updateState8();
            return booleanValue;
         }
      } else {
         return this.textInputModel2.checkCondition3(charValue);
      }
   }

   public static void setIntState(ThemeEditorPanel themeEditorPanel, int intState2) {
      themeEditorPanel.intState = intState2;
   }

   private void setRgb(int intValue, Color color) {
      getColorSettingArray(this)[intValue].setRgb(color.getRed(), color.getGreen(), color.getBlue());
   }

   private void updateState7(String string2) {
      this.updateState5(string2);
   }

   private void updateState8() {
      String string2 = getTextInputModel(this).toString().trim();
      if (string2.startsWith("#")) {
         string2 = string2.substring(1);
      }

      if (string2.length() == 6) {
         try {
            int intValue = Integer.parseInt(string2, 16);
            getColorSettingArray(this)[getIntState(this)].setRgb(intValue >> 16 & 0xFF, intValue >> 8 & 0xFF, intValue & 0xFF);
         } catch (NumberFormatException failure) {
         }
      }
   }

   public static ConfirmationDialog getConfirmationDialog(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.confirmationDialog;
   }

   private Color computeColor(int intValue) {
      Color value = this.colorSettingArray[intValue].getValue();
      return new Color(value.getRed(), value.getGreen(), value.getBlue());
   }

   private void updateStateForUiContext5(UiContext uiContext, Theme theme, Rect rect, Rect rect2, boolean booleanValue, float floatValue, float offsetY) {
      uiContext.getThemeSnapshot();
      Rect rect3 = rect.translate(0.0F, offsetY);
      boolean active = theme.getName().equals(ThemeManager.getString());
      boolean hovered = booleanValue && uiContext.isHovered(rect3.intersection(rect2), UiLayer.MODAL);
      float floatValue3 = uiContext.animateHover("themes.card." + theme.getName(), hovered);
      float progress = uiContext.animateToggle("themes.on." + theme.getName(), active, 0.045F);
      this.updateStateForUiContext2(uiContext, theme, rect3, floatValue, floatValue3, progress);
      if (active) {
         uiContext.getUiRenderContext().fillCircle(rect3.right() - 11.0F, rect3.getY() + 11.0F, 6.0F, UiRenderContext.withAlpha(theme.getAccent2(), 255.0F * floatValue));
         UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.CHECK, rect3.right() - 11.0F, rect3.getY() + 11.0F, 7.0F, UiRenderContext.withAlpha(Color.WHITE, 255.0F * floatValue));
      }

      if (booleanValue) {
         uiContext.getInputRouter().addClickRegion(rect3.intersection(rect2), UiLayer.MODAL, () -> updateStateForTheme(active, theme));
      }

      if (ThemeManager.checkCondition(theme.getName()) && floatValue3 > 0.02F) {
         Rect rect4 = new Rect(rect3.right() - (active ? 40.0F : 22.0F), rect3.getY() + 3.0F, 18.0F, 16.0F);
         ButtonWidgets.updateStateForUiContext2(uiContext, "themes.edit." + theme.getName(), rect4.intersection(rect2), UiLayer.MODAL, Icon.WRENCH, floatValue * floatValue3, booleanValue ? () -> this.updateStateForTheme2(theme) : null);
      }
   }

   @Override
   public boolean checkCondition3(int intValue, boolean booleanValue) {
      if (!this.booleanState) {
         return false;
      } else {
         TextInputModel textInputModel3 = this.textInputModel.getBooleanState2() ? getTextInputModel(this) : (this.textInputModel2.getBooleanState2() ? getTextInputModel2(this) : null);
         if (textInputModel3 == null) {
            return false;
         } else if (intValue == 257 || intValue == 335) {
            textInputModel3.updateState3(false);
            return true;
         } else if (intValue == 256) {
            textInputModel3.updateState3(false);
            return true;
         } else {
            boolean booleanValue2 = textInputModel3.checkCondition(intValue, booleanValue);
            if (booleanValue2 && textInputModel3 == getTextInputModel(this)) {
               this.updateState8();
            }

            return booleanValue2;
         }
      }
   }

   @Override
   protected float computeFloatForUiContext(UiContext uiContext, float floatValue, float floatValue2, boolean booleanValue, float floatValue3) {
      if (getBooleanState(this)) {
         return floatValue;
      } else {
         float floatValue4 = ButtonWidgets.computeFloatForUiContext(uiContext, "New theme", Icon.PLUS);
         Rect rect = new Rect(floatValue - floatValue4, floatValue2 - 10.0F, floatValue4, 20.0F);
         ButtonWidgets.updateStateForUiContext4(uiContext, "themes.new", rect, UiLayer.MODAL, ButtonVariant.GHOST, "New theme", Icon.PLUS, floatValue3, booleanValue ? () -> this.updateState() : null);
         return rect.getX();
      }
   }

   @Override
   protected float computeFloat2(float floatValue) {
      return Math.min(floatValue - 60.0F, getBooleanState(this) ? 352.0F : 372.0F);
   }

   public ThemeEditorPanel(ConfirmationDialog confirmationDialog2) {
      super("Themes", "Applies everywhere, instantly");
      this.textInputModel = new TextInputModel(7);
      this.colorSettingArray = new ColorSetting[]{
         new ColorSetting("Background", new Color(1511706)),
         new ColorSetting("Surface", new Color(2234662)),
         new ColorSetting("Accent", new Color(16751814)),
         new ColorSetting("Text", new Color(16250106))
      };
      this.intState = 2;
      this.colorPicker = new ColorPicker();
      this.confirmationDialog = confirmationDialog2;
   }

   private static String format(Color color) {
      return String.format(UiIconsAccess.getROOT(), "#%06X", color.getRGB() & 16777215);
   }

   @Override
   protected void updateStateForUiContext(UiContext uiContext, Rect rect, boolean booleanValue, float opacity) {
      if (getBooleanState(this)) {
         this.updateStateForUiContext3(uiContext, rect, booleanValue, opacity);
      } else {
         this.updateStateForUiContext4(uiContext, rect, booleanValue, opacity);
      }
   }

   @Override
   protected float computeFloat() {
      return getBooleanState(this) ? 470.0F : 396.0F;
   }

   public static boolean getLight22(ThemeEditorPanel themeEditorPanel) {
      return themeEditorPanel.light22;
   }

   private void updateState9(String string2) {
      getConfirmationDialog(this).updateStateForControlTone("Delete ‘" + string2 + "’?", "The theme is removed from your themes file. This cannot be undone.", "Delete", ControlTone.DANGER, () -> this.updateState7(string2));
   }

   private void updateState10() {
      String string2 = this.textInputModel2.toString().trim();
      ThemeParseResult themeParseResult = ThemeManager.computeThemeParseResultForColor(string2, this.computeColor(0), this.computeColor(1), this.computeColor(2), this.computeColor(3), this.light22);
      if (!themeParseResult.checkCondition()) {
         this.updateState14(themeParseResult.getError(), true);
         ClientSounds.updateState2();
      } else {
         if (getString(this) != null && !this.string.equalsIgnoreCase(string2)) {
            ThemeManager.checkCondition2(getString(this));
         }

         ClickGuiModule.themeSetting.select(themeParseResult.getTheme3().getName());
         this.updateState14("Saved ‘" + themeParseResult.getTheme3().getName() + "’", false);
         ClientSounds.updateState3();
         this.updateState3();
      }
   }

   private Theme computeTheme() {
      String string2 = this.textInputModel2.toString().isBlank() ? "Untitled" : this.textInputModel2.toString().trim();
      return ThemeManager.computeThemeForColor(string2, this.computeColor(0), this.computeColor(1), this.computeColor(2), this.computeColor(3), getLight22(this));
   }

   private void updateState11() {
      setLight22(this, !this.light22);
      ClientSounds.updateState4();
   }

   private void updateStateForTheme2(Theme theme) {
      this.updateState4(theme.getName());
   }

}
