package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public final class TriggerCooldown {
   private int delayTicks;

   private int recoveryTicks;

   public static void setDelayTicks(TriggerCooldown triggerCooldown, int delayTicks2) {
      triggerCooldown.delayTicks = delayTicks2;
   }

   public static int getDelayTicks(TriggerCooldown triggerCooldown) {
      return triggerCooldown.delayTicks;
   }

   public void reset() {
      this.clear();
   }

   public static void setRecoveryTicks(TriggerCooldown triggerCooldown, int recoveryTicks2) {
      triggerCooldown.recoveryTicks = recoveryTicks2;
   }

   public void clear() {
      this.delayTicks = 0;

      setRecoveryTicks(this, 0);
   }

   public boolean isRecovering() {
      byte byteValue;
      if (this.recoveryTicks > 0) {
         byteValue = 20;
         ThreadLocalRandom.current().nextInt(12);

         byteValue = 1;
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public void clearDelay() {
      setDelayTicks(this, 0);
   }

   public void beginDelay() {
      ThreadLocalRandom.current().nextInt(10);

      if (!(getDelayTicks(this) > 0)) {
         setDelayTicks(this, 3);
      }
   }

   public boolean tickDelay() {
      if (this.recoveryTicks > 0) {
         int recoveryTicks2 = getRecoveryTicks(this);

         setRecoveryTicks(this, recoveryTicks2 - 1);
      }

      if (getDelayTicks(this) <= 0) {
         return false;
      } else {
         byte byteValue = 17;
         ThreadLocalRandom.current().nextInt(12);

         setDelayTicks(this, getDelayTicks(this) - 1);
         if (getDelayTicks(this) > 0) {
            byteValue = 1;
         } else {
            byteValue = 16;
            ThreadLocalRandom.current().nextInt(13);
            byteValue = 0;
         }

         return (byteValue != 0);
      }
   }

   public void beginRecovery(boolean booleanValue) {
      this.recoveryTicks = booleanValue ? 3 : 1;
   }

   public static int getRecoveryTicks(TriggerCooldown triggerCooldown) {
      return triggerCooldown.recoveryTicks;
   }
}
