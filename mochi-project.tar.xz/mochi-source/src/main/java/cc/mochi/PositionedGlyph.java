package cc.mochi;

record PositionedGlyph(TextureRegion slot, float xOffset, float yOffset, float width, float height) {
   public TextureRegion getSlot() {
      return this.slot;
   }

   public float getXOffset() {
      return this.xOffset;
   }

   public float getYOffset() {
      return this.yOffset;
   }

   public float getHeight() {
      return this.height;
   }

   public float getWidth() {
      return this.width;
   }
}
