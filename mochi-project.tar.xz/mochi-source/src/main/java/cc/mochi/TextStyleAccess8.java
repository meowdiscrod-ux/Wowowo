package cc.mochi;

public class TextStyleAccess8 {
   public static TextStyle getTITLE() {
      return TextStyle.TITLE;
   }

   public static TextStyle getBODY() {
      return TextStyle.BODY;
   }

   public static UiLayer getMODAL() {
      return UiLayer.MODAL;
   }

   public static Icon getTRASH() {
      return Icon.TRASH;
   }

   public static ButtonVariant getPRIMARY() {
      return ButtonVariant.PRIMARY;
   }
}
