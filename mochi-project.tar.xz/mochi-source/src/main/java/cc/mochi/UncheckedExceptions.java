package cc.mochi;

final class UncheckedExceptions {
   private UncheckedExceptions() {
   }

   static RuntimeException rethrow(Throwable error) {
      return UncheckedExceptions.<RuntimeException, RuntimeException>throwAny(error);
   }

   @SuppressWarnings("unchecked")
   private static <E extends Throwable, R> R throwAny(Throwable error) throws E {
      throw (E)error;
   }
}
