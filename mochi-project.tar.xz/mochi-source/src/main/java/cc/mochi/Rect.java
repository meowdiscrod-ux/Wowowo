package cc.mochi;

public record Rect(float x, float y, float w, float h) {
   public static final Rect INSTANCE = new Rect(0.0F, 0.0F, 0.0F, 0.0F);

   public static Rect centered(float centerX, float centerY, float width, float height) {
      return new Rect(centerX - width / 2.0F, centerY - height / 2.0F, width, height);
   }

   public static float getX(Rect rect) {
      return rect.x;
   }

   public float getX() {
      return getX(this);
   }

   public Rect withHeight(float height) {
      return new Rect(getX(this), this.y, this.w, height);
   }

   public Rect withWidth(float width) {
      return new Rect(this.x, getY(this), width, getH(this));
   }

   public Rect translate(float offsetX, float offsetY) {
      return new Rect(getX(this) + offsetX, this.y + offsetY, this.w, getH(this));
   }

   public Rect expand(float amount) {
      return new Rect(getX(this) - amount, getY(this) - amount, this.w + amount * 2.0F, getH(this) + amount * 2.0F);
   }

   public Rect scaleAroundCenter(float factor) {
      float floatValue = this.w * factor;
      float floatValue2 = this.h * factor;
      return new Rect(this.centerX() - floatValue / 2.0F, this.centerY() - floatValue2 / 2.0F, floatValue, floatValue2);
   }

   public float centerY() {
      return getY(this) + this.h / 2.0F;
   }

   public static float getY(Rect rect) {
      return rect.y;
   }

   public float getWidth() {
      return getW(this);
   }

   public static float getH(Rect rect) {
      return rect.h;
   }

   public float right() {
      return getX(this) + this.w;
   }

   public Rect inset(float horizontal, float vertical) {
      return new Rect(this.x + horizontal, this.y + vertical, Math.max(0.0F, this.w - horizontal * 2.0F), Math.max(0.0F, getH(this) - vertical * 2.0F));
   }

   public Rect clampInside(Rect rect) {
      float floatValue = Math.max(rect.x, Math.min(rect.right() - getW(this), this.x));
      float floatValue2 = Math.max(getY(rect), Math.min(rect.bottom() - this.h, this.y));
      return new Rect(floatValue, floatValue2, this.w, getH(this));
   }

   public float getY() {
      return this.y;
   }

   public float bottom() {
      return this.y + this.h;
   }

   public static float getW(Rect rect) {
      return rect.w;
   }

   public Rect intersection(Rect rect) {
      float floatValue = Math.max(this.x, rect.x);
      float floatValue2 = Math.max(getY(this), rect.y);
      float floatValue3 = Math.min(this.right(), rect.right());
      float floatValue4 = Math.min(this.bottom(), rect.bottom());
      return new Rect(floatValue, floatValue2, Math.max(0.0F, floatValue3 - floatValue), Math.max(0.0F, floatValue4 - floatValue2));
   }

   public boolean contains(double pointX, double pointY) {
      return pointX >= (double)getX(this) && pointX < (double)(getX(this) + this.w) && pointY >= (double)this.y && pointY < (double)(getY(this) + this.h);
   }

   public Rect insetUniform(float amount) {
      return this.inset(amount, amount);
   }

   public float getHeight() {
      return this.h;
   }

   public float centerX() {
      return this.x + this.w / 2.0F;
   }

}
