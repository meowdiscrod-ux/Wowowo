package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.math.MathHelper;

public class PotionsModule extends Module implements HudElement {
   private final BooleanSetting shadowSetting;

   private final DoubleSetting paddingSetting;

   public static final FontFace fontFace2 = FontFace.MEDIUM;

   private final BooleanSetting durationBarSetting;

   private final HudLayout hudLayout;

   private final DoubleSetting sizeSetting;

   private final BooleanSetting durationSetting = new BooleanSetting("Duration", true);

   private final BooleanSetting colourMarkSetting;

   private final BooleanSetting camoSetting;

   private final ChoiceSetting sortSetting;

   private final DoubleSetting bGAlphaSetting;

   private final BooleanSetting headerSetting;

   private final BooleanSetting amplifierSetting = new BooleanSetting("Amplifier", true);

   public static final FontFace fontFace = FontFace.MEDIUM;

   public static String computeString2(int intValue) {
      int intValue2 = Math.max(0, intValue / 20);
      return String.format("%d:%02d", intValue2 / 60, intValue2 % 60);
   }

   @Override
   public float getFloatConstant() {
      return 48.0F;
   }

   private void updateStateForPotionHudEntry(PotionHudEntry potionHudEntry, float floatValue, float y, float floatValue2, float floatValue3, float size, float floatValue4, ThemeSnapshot themeSnapshot) {
      float x = floatValue + 10.0F;
      float floatValue5 = potionHudEntry.getUrgent() ? 0.55F + 0.45F * (float)Math.sin((double)System.nanoTime() / 1.6E8) : 1.0F;
      if (this.colourMarkSetting.getValue()) {
         float centerX = x + 2.0F;
         float centerY = y + floatValue4 / 2.0F;
         Color color = LegacyUiTheme.createColor(potionHudEntry.getColor(), floatValue5);
         LegacyUiTheme.updateStateForRunnable(0.6F, () -> fillCircle(centerX, centerY, (2.0F), color));
         x += 8.0F;
      }

      LegacyUiTheme.drawText(potionHudEntry.getLabel(), x, y, size, LegacyUiTheme.color3, fontFace2);
      if (this.amplifierSetting.getValue() && potionHudEntry.getAmplifier() > 0) {
         float floatValue6 = LegacyUiTheme.measureText(potionHudEntry.getLabel(), size, fontFace2);
         LegacyUiTheme.drawText(computeString3(potionHudEntry.getAmplifier() + 1), x + floatValue6 + 3.0F, y, size, LegacyUiTheme.color3, fontFace2);
      }

      if (this.durationSetting.getValue()) {
         Color color2 = potionHudEntry.getUrgent() ? LegacyUiTheme.createColor(ThemeSnapshot.computeColorForColor(themeSnapshot.getDanger()), floatValue5) : LegacyUiTheme.color5;
         LegacyUiTheme.drawText3(computeString2(potionHudEntry.getDuration()), floatValue + floatValue2 - floatValue3, y, size, color2, fontFace);
      }

      if (this.durationBarSetting.getValue()) {
         LegacyUiTheme.updateStateForColor(floatValue + 10.0F, y + floatValue4 + 2.0F, floatValue2 - 10.0F - floatValue3, 1.6F, potionHudEntry.getFraction(), potionHudEntry.getColor(), 0.9F);
      }
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.LEFT, HudVerticalAlignment.CENTRE, 4.0F, 0.0F);
   }

   public static String computeString3(int intValue) {
      String string;
      switch (MathHelper.clamp(intValue, 1, 10)) {
         case 1:
            string = "I";
            break;
         case 2:
            string = "II";
            break;
         case 3:
            string = "III";
            break;
         case 4:
            string = "IV";
            break;
         case 5:
            string = "V";
            break;
         case 6:
            string = "VI";
            break;
         case 7:
            string = "VII";
            break;
         case 8:
            string = "VIII";
            break;
         case 9:
            string = "IX";
            break;
         default:
            string = "X";
      }

      return string;
   }

   @Override
   public float getFloatConstant2() {
      return 150.0F;
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   private static void fillCircle(float centerX, float centerY, float radius, Color color) {
      HudBloomRenderer.fillCircle(centerX, centerY, radius, color);
   }

   public PotionsModule() {
      super("Potions", "Active effects with timers", -1, ModuleCategory.RENDER);
      this.colourMarkSetting = new BooleanSetting("Colour Mark", true);
      this.durationBarSetting = new BooleanSetting("Duration Bar", true);
      this.headerSetting = new BooleanSetting("Header", true);
      this.sortSetting = new ChoiceSetting("Sort", "Duration", "Duration", "Name");
      this.sizeSetting = new DoubleSetting("Size", 7.0, 18.0, 8.0, 0.5);
      this.paddingSetting = new DoubleSetting("Padding", 2.0, 14.0, 8.0, 1.0);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 150.0, 5.0);
      this.shadowSetting = new BooleanSetting("Shadow", true);
      this.camoSetting = new BooleanSetting("Camo", false);
      this.hudLayout = new HudLayout(4.0F, 4.0F, 150.0F, 48.0F);
      this.addSettings(new Setting[]{this.durationSetting, this.amplifierSetting, this.colourMarkSetting, this.durationBarSetting, this.headerSetting, this.sortSetting, this.sizeSetting, this.paddingSetting, this.bGAlphaSetting, this.shadowSetting, this.camoSetting});
   }

   private List computeList() {
      ArrayList arrayList = new ArrayList();

      for (StatusEffectInstance statusEffectInstance : mc.player.getStatusEffects()) {
         StatusEffect statusEffect = (StatusEffect)statusEffectInstance.getEffectType().value();
         String string = statusEffect.getName().getString();
         int duration = statusEffectInstance.getDuration();
         int intValue = Math.max(duration, 1200);
         arrayList.add(new PotionHudEntry(string, statusEffectInstance.getAmplifier(), duration, (float)duration / (float)intValue, new Color(statusEffect.getColor() & 16777215), duration <= 200));
      }

      if (this.sortSetting.equals("Name")) {
         arrayList.sort(Comparator.comparing(objectValue -> ((PotionHudEntry)objectValue).getLabel(), String.CASE_INSENSITIVE_ORDER));
      } else {
         arrayList.sort(Comparator.comparingInt(objectValue2 -> ((PotionHudEntry)objectValue2).getDuration()));
      }

      return arrayList;
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (mc.currentScreen == null || mc.currentScreen instanceof ChatScreen) {
            if (!GlCapabilities.checkCondition3()) {
               this.updateState8();
               List list = this.computeList();
               if (!list.isEmpty()) {
                  ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();
                  float value = (float)this.sizeSetting.getValue();
                  float value5 = value;
                  float value2 = (float)this.paddingSetting.getValue();
                  boolean value3 = this.headerSetting.getValue();
                  boolean value4 = this.durationBarSetting.getValue();

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     float floatValue = LegacyUiTheme.measureFontHeight(value, fontFace2);
                     float floatValue2 = floatValue + (value4 ? 4.6F : 0.0F) + 4.0F;
                     float floatValue3 = value3 ? LegacyUiTheme.measureFontHeight(value5, LegacyUiTheme.fontFace2) + 6.0F : 0.0F;
                     float floatValue4 = value3 ? LegacyUiTheme.measureText2("Potion Effects", value5) + 24.0F : 0.0F;

                     for (PotionHudEntry potionHudEntry : (java.lang.Iterable<PotionHudEntry>)(java.lang.Iterable<?>)(list)) {
                        floatValue4 = Math.max(floatValue4, potionHudEntry.computeFloat(value, this.durationSetting.getValue(), this.amplifierSetting.getValue(), this.colourMarkSetting.getValue()));
                     }

                     float width = Math.max(96.0F, 10.0F + floatValue4 + value2);
                     float height = value2 * 2.0F + floatValue3 + (float)list.size() * floatValue2 - 4.0F;
                     this.updateState4(width, height);
                     float x = this.hudLayout.getX();
                     float y = this.hudLayout.getY();
                     LegacyUiTheme.updateStateForThemeSnapshot(x, y, width, height, (int)this.bGAlphaSetting.getValue(), true, this.shadowSetting.getValue(), this.camoSetting.getValue(), true, themeSnapshot);
                     float y2 = y + value2;
                     if (value3) {
                        LegacyUiTheme.computeFloat("Potion Effects", x + 10.0F, y2, value5);
                        LegacyUiTheme.drawText3(String.valueOf(list.size()), x + width - value2, y2, value5, LegacyUiTheme.color5, LegacyUiTheme.fontFace2);
                        y2 += floatValue3;
                     }

                     for (PotionHudEntry potionHudEntry2 : (java.lang.Iterable<PotionHudEntry>)(java.lang.Iterable<?>)(list)) {
                        this.updateStateForPotionHudEntry(potionHudEntry2, x, y2, width, value2, value, floatValue, themeSnapshot);
                        y2 += floatValue2;
                     }
                  }
               }
            }
         }
      }
   }
}
