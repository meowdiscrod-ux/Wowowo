package cc.mochi;

public enum VerticalAlignment {
   TOP,
   CENTER,
   BOTTOM;

   private static VerticalAlignment[] createValues() {
      return new VerticalAlignment[]{TOP, CENTER, BOTTOM};
   }
}
