package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

public final class UiInputRouter {
   private UiLayer activeLayer;
   private List<PressRegion> activePressRegions;

   private boolean blocked;
   private List<ScrollRegion> nextScrollRegions;
   private DragHandler dragHandler;
   private UiLayer nextLayer;

   private List<ScrollRegion> activeScrollRegions;
   private List<PressRegion> nextPressRegions = new ArrayList<>();

   public void commitFrame() {
      List nextPressRegions2 = getPressRegionList(this);
      this.activePressRegions = getPressRegionList2(this);
      this.nextPressRegions = nextPressRegions2;
      List nextScrollRegions2 = getScrollRegionList2(this);
      setScrollRegionList2(this, this.nextScrollRegions);
      this.nextScrollRegions = nextScrollRegions2;
      this.activeLayer = getUiLayer2(this);
   }

   public static List<PressRegion> getPressRegionList(UiInputRouter uiInputRouter) {
      return uiInputRouter.activePressRegions;
   }

   public static UiLayer getUiLayer2(UiInputRouter uiInputRouter) {
      return uiInputRouter.nextLayer;
   }

   public static void setDragHandler(UiInputRouter uiInputRouter, DragHandler dragHandler2) {
      uiInputRouter.dragHandler = dragHandler2;
   }

   public void addModalCatcher(UiLayer nextLayer2, Runnable runnable) {
      if (nextLayer2.ordinal() > this.nextLayer.ordinal()) {
         this.nextLayer = nextLayer2;
      }

      PressRegion pressRegion = new PressRegion(new Rect(((-1000000.0F)), ((-1000000.0F)), 2000000.0F, 2000000.0F), nextLayer2, (intValue, doubleValue, doubleValue2) -> runCatcher(runnable, intValue, doubleValue, doubleValue2), true);
      getPressRegionList2(this).add(0, pressRegion);
   }

   public void addPressRegion(Rect rect, UiLayer uiLayer, PressHandler pressHandler) {
      if (rect != null && pressHandler != null && this.nextPressRegions.size() < 4096) {
         this.nextPressRegions.add(new PressRegion(rect, uiLayer, pressHandler, false));
      }
   }

   public static List<ScrollRegion> getScrollRegionList(UiInputRouter uiInputRouter) {
      return uiInputRouter.nextScrollRegions;
   }

   public static List<PressRegion> getPressRegionList2(UiInputRouter uiInputRouter) {
      return uiInputRouter.nextPressRegions;
   }

   public boolean acceptsLayer(UiLayer uiLayer) {
      return !this.blocked && uiLayer.ordinal() >= this.nextLayer.ordinal() && uiLayer.ordinal() >= getUiLayer(this).ordinal();
   }

   public static UiLayer getUiLayer(UiInputRouter uiInputRouter) {
      return uiInputRouter.activeLayer;
   }

   public boolean endDrag(double doubleValue, double doubleValue2) {
      DragHandler dragHandler2 = this.dragHandler;
      setDragHandler(this, null);
      this.blocked = false;
      if (dragHandler2 == null) {
         return false;
      } else {
         dragHandler2.release(doubleValue, doubleValue2);
         return true;
      }
   }

   public void addClickRegion(Rect rect, UiLayer uiLayer, Runnable runnable) {
      this.addPressRegion(rect, uiLayer, (intValue, doubleValue, doubleValue2) -> runLeftClick(runnable, intValue, doubleValue, doubleValue2));
   }

   public void beginFrame() {
      getPressRegionList2(this).clear();
      getScrollRegionList(this).clear();
      setUiLayer2(this, UiLayer.BASE);
   }

   public static UiLayer layer(ScrollRegion scrollRegion) {
      return scrollRegion.layer();
   }

   public UiInputRouter() {
      this.activePressRegions = new ArrayList<>();
      this.nextScrollRegions = new ArrayList<>();
      this.activeScrollRegions = new ArrayList<>();
      this.nextLayer = UiLayer.BASE;
      this.activeLayer = UiLayer.BASE;
   }

   public static void setScrollRegionList2(UiInputRouter uiInputRouter, List activeScrollRegions2) {
      uiInputRouter.activeScrollRegions = activeScrollRegions2;
   }

   public static List<ScrollRegion> getScrollRegionList2(UiInputRouter uiInputRouter) {
      return uiInputRouter.activeScrollRegions;
   }

   public boolean dispatchScroll(double pointX, double pointY, double doubleValue3) {
      ScrollRegion scrollRegion22 = null;

      for (ScrollRegion scrollRegion2 : this.activeScrollRegions) {
         if (rect(scrollRegion2).contains(pointX, pointY) && scrollRegion2.layer().ordinal() >= this.activeLayer.ordinal() && (scrollRegion22 == null || layer(scrollRegion2).ordinal() >= layer2(scrollRegion22).ordinal())) {
            scrollRegion22 = scrollRegion2;
         }
      }

      if (scrollRegion22 == null) {
         return getUiLayer(this).ordinal() > UiLayer.BASE.ordinal();
      } else {
         onScroll(scrollRegion22).accept(doubleValue3);
         return true;
      }
   }

   public void setBlocked(boolean blocked2) {
      setBlocked2(this, blocked2);
   }

   public static DragHandler getDragHandler(UiInputRouter uiInputRouter) {
      return uiInputRouter.dragHandler;
   }

   public static Rect rect(ScrollRegion scrollRegion) {
      return scrollRegion.rect();
   }

   public static void setBlocked2(UiInputRouter uiInputRouter, boolean blocked2) {
      uiInputRouter.blocked = blocked2;
   }

   public static DoubleConsumer onScroll(ScrollRegion scrollRegion) {
      return scrollRegion.onScroll();
   }

   public static void setUiLayer2(UiInputRouter uiInputRouter, UiLayer nextLayer2) {
      uiInputRouter.nextLayer = nextLayer2;
   }

   int size() {
      return getPressRegionList(this).size();
   }

   public void addScrollRegion(Rect rect, UiLayer uiLayer, DoubleConsumer doubleConsumer) {
      if (rect != null && doubleConsumer != null) {
         this.nextScrollRegions.add(new ScrollRegion(rect, uiLayer, doubleConsumer));
      }
   }

   public boolean updateDrag(double doubleValue, double doubleValue2) {
      if (this.dragHandler == null) {
         return false;
      } else {
         this.dragHandler.drag(doubleValue, doubleValue2);
         return true;
      }
   }

   public static boolean catcher(PressRegion pressRegion) {
      return pressRegion.catcher();
   }

   public UiLayer getUiLayer32() {
      return getUiLayer(this);
   }

   public static UiLayer layer2(ScrollRegion scrollRegion) {
      return scrollRegion.layer();
   }

   public boolean isDragging() {
      return getDragHandler(this) != null;
   }

   private static void runLeftClick(Runnable runnable, int intValue, double doubleValue, double doubleValue2) {
      if (intValue == 0) {
         runnable.run();
      }
   }

   public void beginDrag(DragHandler dragHandler2) {
      setDragHandler(this, dragHandler2);
      this.blocked = dragHandler2 != null;
   }

   public boolean dispatchPress(double pointX, double pointY, int intValue) {
      PressRegion pressRegion22 = null;

      for (PressRegion pressRegion2 : this.activePressRegions) {
         if (pressRegion2.rect().contains(pointX, pointY) && (pressRegion22 == null || pressRegion2.layer().ordinal() > pressRegion22.layer().ordinal() || pressRegion2.layer() == pressRegion22.layer() && !catcher(pressRegion2))) {
            pressRegion22 = pressRegion2;
         }
      }

      if (pressRegion22 == null) {
         return false;
      } else {
         pressRegion22.press().press(intValue, pointX, pointY);
         return true;
      }
   }

   private static void runCatcher(Runnable runnable, int intValue, double doubleValue, double doubleValue2) {
      if (runnable != null) {
         runnable.run();
      }
   }
}
