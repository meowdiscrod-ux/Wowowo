package cc.mochi;

final class RenderBackendLease extends DelegatingRenderBackend {
   private boolean booleanState;

   @Override
   public void close() {
      if (!this.booleanState) {
         this.booleanState = true;
         HudBloomRenderer.ACTIVE_BACKEND.remove();
         this.uiRenderBackend.close();
      }
   }

   public RenderBackendLease(UiRenderBackend uiRenderBackend2) {
      super(uiRenderBackend2);
   }
}
