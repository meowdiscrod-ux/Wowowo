package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record ProjectileState(int id, int owner, Vec3d position, Vec3d velocity) {
   public Vec3d getVelocity2() {
      return getVelocity(this);
   }

   public int getOwner() {
      return this.owner;
   }

   public Vec3d getPosition2() {
      return getPosition(this);
   }

   public int getId() {
      return this.id;
   }

   public static Vec3d getVelocity(ProjectileState projectileState) {
      return projectileState.velocity;
   }

   public static Vec3d getPosition(ProjectileState projectileState) {
      return projectileState.position;
   }
}
