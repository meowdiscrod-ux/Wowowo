package cc.mochi;

public class TextStyleAccess10 {
   public static float getSize(TextStyle textStyle) {
      return textStyle.size;
   }

   public static FontFace getFace(TextStyle textStyle) {
      return textStyle.face;
   }

}
