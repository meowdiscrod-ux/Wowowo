package cc.mochi;

public class ModuleCategoryAccess {
   public static ModuleCategory getCOMBAT() {
      return ModuleCategory.COMBAT;
   }

   public static ModuleCategory getMOVEMENT() {
      return ModuleCategory.MOVEMENT;
   }

   public static ModuleCategory getMISC() {
      return ModuleCategory.MISC;
   }

   public static ModuleCategory getRENDER() {
      return ModuleCategory.RENDER;
   }
}
