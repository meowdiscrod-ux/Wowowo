package cc.mochi;

public enum PotionRefillState {
   IDLE,
   SILENT,
   OPENING,
   SETTLE,

   PLAN,

   SOURCE,
   TARGET,
   RETURN,
   CLOSING;

   public static PotionRefillState getRETURN() {
      return RETURN;
   }

   public static PotionRefillState getSETTLE() {
      return SETTLE;
   }

   private static PotionRefillState[] computePotionRefillStateArray() {
      PotionRefillState[] potionRefillStateArray = new PotionRefillState[9];

      potionRefillStateArray[0] = IDLE;
      potionRefillStateArray[1] = SILENT;
      potionRefillStateArray[2] = getOPENING();
      potionRefillStateArray[3] = getSETTLE();
      potionRefillStateArray[4] = PLAN;
      potionRefillStateArray[5] = SOURCE;

      potionRefillStateArray[6] = TARGET;

      potionRefillStateArray[7] = getRETURN();

      potionRefillStateArray[8] = getCLOSING();
      return potionRefillStateArray;
   }

   public static PotionRefillState getOPENING() {
      return OPENING;
   }

   public static PotionRefillState getCLOSING() {
      return CLOSING;
   }
}
