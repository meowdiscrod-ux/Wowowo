package cc.mochi;

public class TextStyleAccess2 {
   public static TextStyle getOVERLINE() {
      return TextStyle.OVERLINE;
   }

}
