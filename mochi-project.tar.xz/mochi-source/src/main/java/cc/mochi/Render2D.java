package cc.mochi;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.util.Identifier;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class Render2D {
   private static int intState;

   private static final Logger logger = NOPLogger.NOP_LOGGER;

   private static int intState2;

   private static TextureHandle textureHandle;

   private static int bloomDepth;

   private static final long timestampNanos = System.nanoTime();

   private static int scissorY;

   private static final UiQuadRenderer uiQuadRenderer = new UiQuadRenderer("Mochi 2D");

   private static int counter;

   private static boolean frameOpen;

   private static final UiQuadRenderer uiQuadRenderer2 = new UiQuadRenderer("Mochi 2D emissive");

   private static final BloomRenderTargets bloomRenderTargets = new BloomRenderTargets();

   private static final AuroraBackdropRenderer auroraBackdropRenderer = new AuroraBackdropRenderer();

   private static float transform01;

   public static GlyphAtlas glyphAtlas = new GlyphAtlas();

   private static int scissorWidth;
   private static float translateY;

   private static GpuBuffer gpuBuffer;
   private static ImageCache imageCache = new ImageCache();

   private static BooleanSupplier booleanSupplier = () -> returnTrue2();

   private static int opacityDepth;

   private static boolean booleanState;

   private static int intState3;
   private static DoubleSupplier doubleSupplier = () -> getDoubleConstant2();

   private static float viewportWidth = 1.0F;

   private static float viewportHeight = 1.0F;

   public static float pixelScaleX = 1.0F;

   public static float pixelScaleY = 1.0F;

   private static int intState4;

   private static int framebufferWidth = 1;

   private static int scissorDepth;
   private static int transformDepth;

   private static int framebufferHeight = 1;

   private static float transform00 = 1.0F;

   private static boolean scissorEnabled;
   private static float transform11 = 1.0F;

   private static GpuTexture gpuTexture;

   private static final float[] transformStack = new float[384];

   private static float opacity = 1.0F;

   private static int scissorHeight;

   private static GpuTextureView gpuTextureView;

   private static float translateX;

   private static final float[] opacityStack = new float[64];
   private static float transform10;

   private static final float[] bloomStack = new float[64];

   private static int scissorX;

   private static final int[] scissorStack = new int[320];

   private static float bloomStrength;

   private static boolean initialized;
   private static final List<Runnable> runnableList = new ArrayList<>();

   private static final GlyphPreloader glyphPreloader = new GlyphPreloader();

   public static void popOpacity() {
      if (opacityDepth != 0) {
         opacity = opacityStack[--opacityDepth];
      }
   }

   public static void updateStateForRunnable(Runnable runnable) {
      if (!runnableList.contains(runnable)) {
         runnableList.add(runnable);
      }
   }

   public static void rotate(float floatValue) {
      float floatValue2 = (float)Math.cos((double)floatValue);
      float floatValue3 = (float)Math.sin((double)floatValue);
      float transform002 = transform00 * floatValue2 + transform10 * floatValue3;
      float transform012 = transform01 * floatValue2 + transform11 * floatValue3;
      float transform102 = -transform00 * floatValue3 + transform10 * floatValue2;
      float transform112 = -transform01 * floatValue3 + transform11 * floatValue2;
      transform00 = transform002;
      transform01 = transform012;
      transform10 = transform102;
      transform11 = transform112;
   }

   public static void popTransform() {
      if (transformDepth != 0) {
         int intValue = --transformDepth * 6;
         transform00 = transformStack[intValue];
         transform01 = transformStack[intValue + 1];
         transform10 = transformStack[intValue + 2];
         transform11 = transformStack[intValue + 3];
         translateX = transformStack[intValue + 4];
         translateY = transformStack[intValue + 5];
      }
   }

   public static float getViewportWidth() {
      return viewportWidth;
   }

   public static void updateState(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && !(floatValue6 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, 0.0F, floatValue6, ((-1.0F)), 0.0F, 0.0F, intValue2, intValue2, intValue2, intValue2);
         }
      }
   }

   public static void fillHorizontalGradient(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue, int intValue2) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue3 = computeInt(intValue);
         int intValue4 = computeInt(intValue2);
         if (intValue3 != 0 || intValue4 != 0) {
            updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, 0.0F, 0.0F, ((-1.0F)), 0.0F, 0.0F, intValue3, intValue4, intValue4, intValue3);
         }
      }
   }

   public static float computeFloat() {
      return pixelScaleX * sqrt();
   }

   public static void updateState2(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue, int intValue2, int intValue3, int intValue4) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, 0.0F, 0.0F, ((-1.0F)), 0.0F, 0.0F, computeInt(intValue), computeInt(intValue2), computeInt(intValue3), computeInt(intValue4));
      }
   }

   private static void updateStateForUiQuadRenderer(
      UiQuadRenderer uiQuadRenderer3,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      float floatValue9,
      float floatValue10,
      float floatValue11,
      float floatValue12,
      float floatValue13,
      float floatValue14,
      float floatValue15,
      float floatValue16,
      float floatValue17,
      float floatValue18,
      float floatValue19,
      float floatValue20,
      float floatValue21,
      boolean booleanValue,
      int intValue
   ) {
      float floatValue242 = floatValue2 + floatValue4 * floatValue6 - floatValue5 * floatValue7;
      float floatValue252 = floatValue3 + floatValue5 * floatValue6 + floatValue4 * floatValue7;
      if (booleanValue) {
         float floatValue24 = transform00 * floatValue242 + transform10 * floatValue252 + translateX;
         float floatValue25 = transform01 * floatValue242 + transform11 * floatValue252 + translateY;
         floatValue242 = floatValue24;
         floatValue252 = floatValue25;
      }

      uiQuadRenderer3.writeVertex(floatValue242, floatValue252, floatValue, intValue, floatValue6, floatValue7, floatValue8, floatValue9, floatValue10, floatValue11, floatValue12, floatValue13, floatValue14, floatValue15, floatValue16, floatValue17, floatValue18, floatValue19, floatValue20, floatValue21);
   }

   public static float computeFloatForFontResourceFamily(FontResourceFamily fontResourceFamily, String string, float floatValue) {
      if (string != null && !string.isEmpty() && !(floatValue <= 0.0F)) {
         float floatValue2 = frameOpen ? sqrt() * pixelScaleX : 1.0F;
         if (floatValue2 <= 0.0F) {
            floatValue2 = 1.0F;
         }

         return FontResourceCache.computeFloatForFontResourceFamily(fontResourceFamily, string, floatValue * floatValue2, null) / floatValue2;
      } else {
         return 0.0F;
      }
   }

   public static boolean drawAurora(int[] intArray, int intValue, float floatValue, float floatValue2, float floatValue3) {
      if (frameOpen && initialized && intArray != null && intArray.length != 0) {
         updateState21();
         GpuTextureView gpuTextureView2 = computeGpuTextureView();
         if (gpuTextureView2 == null) {
            return false;
         } else {
            auroraBackdropRenderer.updateStateForGpuTextureView(gpuTextureView2, intArray, intValue, computeFloat2(), floatValue, floatValue2, floatValue3);
            return true;
         }
      } else {
         return false;
      }
   }

   public static void updateState3(float[] floatArray, float floatValue, int intValue) {
      if (floatArray != null && floatArray.length >= 4) {
         for (int vertexOffset = 0; vertexOffset + 3 < floatArray.length; vertexOffset += 2) {
            updateState25(floatArray[vertexOffset], floatArray[vertexOffset + 1], floatArray[vertexOffset + 2], floatArray[vertexOffset + 3], floatValue, intValue, true);
         }
      }
   }

   private static void updateState4(boolean booleanState2, int intState5, int intState42, int intState22, int intState32) {
      booleanState = booleanState2;
      intState = intState5;
      intState4 = intState42;
      intState2 = intState22;
      intState3 = intState32;
   }

   public static boolean beginFrame(float viewportWidth2, float viewportHeight2) {
      RenderSystem.assertOnRenderThread();
      if (frameOpen) {
         throw new IllegalStateException("Nested 2D frame");
      } else {
         if (!initialized) {
            initialize();
         }

         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         Framebuffer framebuffer = minecraftClient == null ? null : minecraftClient.getFramebuffer();
         if (framebuffer != null && framebuffer.textureWidth > 0 && framebuffer.textureHeight > 0 && !(viewportWidth2 <= 0.0F) && !(viewportHeight2 <= 0.0F)) {
            cc.mochi.UiRenderPipelines.precompileAll();
            viewportWidth = viewportWidth2;
            viewportHeight = viewportHeight2;
            framebufferWidth = framebuffer.textureWidth;
            framebufferHeight = framebuffer.textureHeight;
            pixelScaleX = (float)framebufferWidth / viewportWidth2;
            pixelScaleY = (float)framebufferHeight / viewportHeight2;
            transform00 = 1.0F;
            transform01 = 0.0F;
            transform10 = 0.0F;
            transform11 = 1.0F;
            translateX = 0.0F;
            translateY = 0.0F;
            transformDepth = 0;
            opacity = 1.0F;
            opacityDepth = 0;
            bloomStrength = 0.0F;
            bloomDepth = 0;
            booleanState = false;
            scissorEnabled = false;
            scissorDepth = 0;
            updateState30();
            frameOpen = true;
            return true;
         } else {
            return false;
         }
      }
   }

   public static void updateState5(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && !(floatValue6 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            updateState17(floatValue, floatValue2 + floatValue7, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, 0.0F, floatValue6, 0.0F, 0.0F, floatValue7, intValue2, intValue2, intValue2, intValue2);
         }
      }
   }

   public static float getViewportHeight() {
      return viewportHeight;
   }

   private static boolean returnTrue() {
      return true;
   }

   private static double getDoubleConstant() {
      return 1.0;
   }

   public static void popClip() {
      if (scissorDepth != 0) {
         int intValue = --scissorDepth * 5;
         scissorEnabled = scissorStack[intValue] != 0;
         scissorX = scissorStack[intValue + 1];
         scissorY = scissorStack[intValue + 2];
         scissorWidth = scissorStack[intValue + 3];
         scissorHeight = scissorStack[intValue + 4];
         updateState4(scissorEnabled, scissorX, scissorY, scissorWidth, scissorHeight);
      }
   }

   public static void updateState6(String string) {
      if (initialized) {
         if (frameOpen) {
            updateState21();
         }

         imageCache.updateState2(string);
      }
   }

   public static void fillVerticalGradient(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue, int intValue2) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue3 = computeInt(intValue);
         int intValue4 = computeInt(intValue2);
         if (intValue3 != 0 || intValue4 != 0) {
            updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, 0.0F, 0.0F, ((-1.0F)), 0.0F, 0.0F, intValue3, intValue3, intValue4, intValue4);
         }
      }
   }

   private static float computeFloat2() {
      return (float)((double)(System.nanoTime() - timestampNanos) / 1.0E9 % 3600.0);
   }

   public static void updateState7(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      int[] intArray = computeIntArray(floatValue, floatValue2, floatValue3, floatValue4);
      if (scissorEnabled) {
         updateState27(intArray, scissorX, scissorY, scissorWidth, scissorHeight);
      }

      updateState4(true, intArray[0], intArray[1], intArray[2], intArray[3]);
   }

   private static void updateState8() {
      uiQuadRenderer.closeBuffers();
      uiQuadRenderer2.closeBuffers();
      bloomRenderTargets.updateState();
      auroraBackdropRenderer.updateState();
      glyphAtlas.updateState();
      glyphAtlas = new GlyphAtlas();
      imageCache.updateState();
      imageCache = new ImageCache();
      MapAccess.clear();
      FontResourceCache.updateState();
      if (gpuTextureView != null) {
         gpuTextureView.close();
      }

      if (gpuTexture != null) {
         gpuTexture.close();
      }

      gpuTextureView = null;
      gpuTexture = null;
      textureHandle = null;
      if (gpuBuffer != null) {
         gpuBuffer.close();
      }

      gpuBuffer = null;
      initialized = false;
   }

   public static void translate(float floatValue, float floatValue2) {
      translateX = translateX + transform00 * floatValue + transform10 * floatValue2;
      translateY = translateY + transform01 * floatValue + transform11 * floatValue2;
   }

   public static void updateStateForTextureHandle(
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      float floatValue9,
      float floatValue10,
      float floatValue11,
      float floatValue12,
      float floatValue13,
      float floatValue14,
      float floatValue15,
      float floatValue16,
      float floatValue17,
      float floatValue18,
      float floatValue19,
      float floatValue20,
      float floatValue21,
      float floatValue22,
      boolean booleanValue,
      TextureHandle texture,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4
   ) {
      if (frameOpen && initialized) {
         if (uiQuadRenderer.isFull() || uiQuadRenderer2.isFull()) {
            updateState21();
         }

         updateStateForUiQuadRenderer2(
            uiQuadRenderer,
            0.0F,
            floatValue,
            floatValue2,
            floatValue3,
            floatValue4,
            floatValue5,
            floatValue6,
            floatValue7,
            floatValue8,
            floatValue9,
            floatValue10,
            floatValue11,
            floatValue12,
            floatValue13,
            floatValue14,
            floatValue15,
            floatValue16,
            floatValue17,
            floatValue18,
            floatValue19,
            floatValue20,
            floatValue21,
            floatValue22,
            booleanValue,
            texture,
            intValue,
            intValue2,
            intValue3,
            intValue4
         );
         if (bloomStrength > 0.0F) {
            updateStateForUiQuadRenderer2(
               uiQuadRenderer2,
               bloomStrength,
               floatValue,
               floatValue2,
               floatValue3,
               floatValue4,
               floatValue5,
               floatValue6,
               floatValue7,
               floatValue8,
               floatValue9,
               floatValue10,
               floatValue11,
               floatValue12,
               floatValue13,
               floatValue14,
               floatValue15,
               floatValue16,
               floatValue17,
               floatValue18,
               floatValue19,
               floatValue20,
               floatValue21,
               floatValue22,
               booleanValue,
               texture,
               intValue,
               intValue2,
               intValue3,
               intValue4
            );
         }
      }
   }

   public static void updateStateForTextureHandle2(TextureHandle texture, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, float floatValue8, float floatValue9, float floatValue10) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue = Math.round(Math.max(0.0F, Math.min(1.0F, floatValue10)) * 255.0F);
         updateStateForTextureHandle3(
            texture,
            floatValue5,
            floatValue6,
            floatValue7,
            floatValue8,
            floatValue9,
            (floatValue5 - floatValue) / floatValue3,
            (floatValue6 - floatValue2) / floatValue4,
            (floatValue5 + floatValue7 - floatValue) / floatValue3,
            (floatValue6 + floatValue8 - floatValue2) / floatValue4,
            intValue << 24 | 16777215
         );
      }
   }

   public static void updateState9(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, float floatValue8, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue6, floatValue7, floatValue8, 0.0F, 0.0F, ((-1.0F)), 0.0F, 0.0F, intValue2, intValue2, intValue2, intValue2);
         }
      }
   }

   private static double getDoubleConstant2() {
      return 1.0;
   }

   public static void updateState10() {
      counter++;
   }

   public static void updateState11(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue) {
      updateState9(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, intValue);
   }

   public static void updateState12(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && !(floatValue6 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            float floatValue8 = floatValue5 + floatValue7;
            updateState17(floatValue - floatValue7, floatValue2 - floatValue7, floatValue3 + floatValue7 * 2.0F, floatValue4 + floatValue7 * 2.0F, floatValue8, floatValue8, floatValue8, floatValue8, 0.0F, floatValue6, floatValue7, 0.0F, 0.0F, intValue2, intValue2, intValue2, intValue2);
         }
      }
   }

   private static boolean returnTrue2() {
      return true;
   }

   private static GpuTextureView computeGpuTextureView() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      Framebuffer framebuffer = minecraftClient == null ? null : minecraftClient.getFramebuffer();
      GpuTextureView gpuTextureView2 = framebuffer == null ? null : framebuffer.getColorAttachmentView();
      return gpuTextureView2 != null && !gpuTextureView2.isClosed() ? gpuTextureView2 : null;
   }

   private static void updateStateForUiQuadRenderer2(
      UiQuadRenderer uiQuadRenderer3,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      float floatValue9,
      float floatValue10,
      float floatValue11,
      float floatValue12,
      float floatValue13,
      float floatValue14,
      float floatValue15,
      float floatValue16,
      float floatValue17,
      float floatValue18,
      float floatValue19,
      float floatValue20,
      float floatValue21,
      float floatValue22,
      float floatValue23,
      boolean booleanValue,
      TextureHandle texture,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4
   ) {
      uiQuadRenderer3.setBatchState(texture, booleanState, intState, intState4, intState2, intState3);
      uiQuadRenderer3.finishQuad();
      updateStateForUiQuadRenderer(
         uiQuadRenderer3,
         floatValue,
         floatValue2,
         floatValue3,
         floatValue4,
         floatValue5,
         -floatValue6,
         -floatValue7,
         floatValue8,
         floatValue9,
         floatValue10,
         floatValue11,
         floatValue12,
         floatValue13,
         floatValue14,
         floatValue15,
         floatValue16,
         floatValue17,
         floatValue18,
         floatValue19,
         floatValue22,
         floatValue23,
         booleanValue,
         intValue
      );
      updateStateForUiQuadRenderer(
         uiQuadRenderer3,
         floatValue,
         floatValue2,
         floatValue3,
         floatValue4,
         floatValue5,
         floatValue6,
         -floatValue7,
         floatValue8,
         floatValue9,
         floatValue10,
         floatValue11,
         floatValue12,
         floatValue13,
         floatValue14,
         floatValue15,
         floatValue16,
         floatValue17,
         floatValue20,
         floatValue19,
         floatValue22,
         floatValue23,
         booleanValue,
         intValue2
      );
      updateStateForUiQuadRenderer(
         uiQuadRenderer3,
         floatValue,
         floatValue2,
         floatValue3,
         floatValue4,
         floatValue5,
         floatValue6,
         floatValue7,
         floatValue8,
         floatValue9,
         floatValue10,
         floatValue11,
         floatValue12,
         floatValue13,
         floatValue14,
         floatValue15,
         floatValue16,
         floatValue17,
         floatValue20,
         floatValue21,
         floatValue22,
         floatValue23,
         booleanValue,
         intValue3
      );
      updateStateForUiQuadRenderer(
         uiQuadRenderer3,
         floatValue,
         floatValue2,
         floatValue3,
         floatValue4,
         floatValue5,
         -floatValue6,
         floatValue7,
         floatValue8,
         floatValue9,
         floatValue10,
         floatValue11,
         floatValue12,
         floatValue13,
         floatValue14,
         floatValue15,
         floatValue16,
         floatValue17,
         floatValue18,
         floatValue21,
         floatValue22,
         floatValue23,
         booleanValue,
         intValue4
      );
   }

   public static void updateState13(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && !(floatValue6 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            updateState17(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, floatValue5, floatValue5, floatValue5, floatValue6, 0.0F, ((-1.0F)), 0.0F, 0.0F, intValue2, intValue2, intValue2, intValue2);
         }
      }
   }

   public static void updateStateForTextureHandle3(TextureHandle texture, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, float floatValue7, float floatValue8, float floatValue9, int intValue) {
      if (texture != null && texture.getView() != null && !texture.getView().isClosed() && !(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            if (texture.getFlipY()) {
               floatValue7 = 1.0F - floatValue7;
               floatValue9 = 1.0F - floatValue9;
            }

            float floatValue10 = floatValue3 * 0.5F;
            float floatValue11 = floatValue4 * 0.5F;
            updateStateForTextureHandle(
               floatValue + floatValue10,
               floatValue2 + floatValue11,
               1.0F,
               0.0F,
               floatValue10,
               floatValue11,
               floatValue10,
               floatValue11,
               floatValue5,
               floatValue5,
               floatValue5,
               floatValue5,
               texture.getPremultiplied() ? 2.0F : 3.0F,
               0.0F,
               0.0F,
               0.0F,
               floatValue6,
               floatValue7,
               floatValue8,
               floatValue9,
               0.0F,
               0.0F,
               true,
               texture,
               intValue2,
               intValue2,
               intValue2,
               intValue2
            );
         }
      }
   }

   public static void pushOpacity(float floatValue) {
      if (opacityDepth < 64) {
         opacityStack[opacityDepth++] = opacity;
         opacity = opacity * Math.max(0.0F, Math.min(1.0F, floatValue));
      }
   }

   public static void updateState14(float floatValue, float floatValue2, float floatValue3, float floatValue4, int intValue) {
      if (!(floatValue3 <= 0.0F)) {
         updateState13(floatValue - floatValue3, floatValue2 - floatValue3, floatValue3 * 2.0F, floatValue3 * 2.0F, floatValue3, floatValue4, intValue);
      }
   }

   private static float computeFloat3(float floatValue) {
      float floatValue2 = pixelScaleX * sqrt();
      return (floatValue2 > 0.0F ? 1.5F / floatValue2 : 1.5F) + floatValue;
   }

   public static void updateStateForBooleanSupplier(BooleanSupplier booleanSupplier2, DoubleSupplier doubleSupplier2) {
      booleanSupplier = booleanSupplier2 == null ? () -> returnTrue() : booleanSupplier2;
      doubleSupplier = doubleSupplier2 == null ? () -> getDoubleConstant() : doubleSupplier2;
   }

   public static void updateState15(float floatValue, float floatValue2, float floatValue3, int intValue) {
      if (!(floatValue3 <= 0.0F)) {
         updateState11(floatValue - floatValue3, floatValue2 - floatValue3, floatValue3 * 2.0F, floatValue3 * 2.0F, floatValue3, intValue);
      }
   }

   private static boolean checkCondition() {
      try {
         return booleanSupplier.getAsBoolean();
      } catch (RuntimeException failure) {
         return false;
      }
   }

   public static void resetResources() {
      RenderSystem.assertOnRenderThread();
      frameOpen = false;
      counter = 0;
      uiQuadRenderer.reset();
      uiQuadRenderer2.reset();
      runnableList.clear();
      updateState8();
   }

   public static float computeFloatForFontResourceFamily2(FontResourceFamily fontResourceFamily, float floatValue) {
      return FontResourceCache.computeFloatForFontResourceFamily3(fontResourceFamily) * floatValue;
   }

   public static boolean isFrameOpen() {
      return frameOpen;
   }

   public static void pushClip(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      if (scissorDepth < 64) {
         int intValue = scissorDepth++ * 5;
         scissorStack[intValue] = scissorEnabled ? 1 : 0;
         scissorStack[intValue + 1] = scissorX;
         scissorStack[intValue + 2] = scissorY;
         scissorStack[intValue + 3] = scissorWidth;
         scissorStack[intValue + 4] = scissorHeight;
         int[] intArray = computeIntArray(floatValue, floatValue2, floatValue3, floatValue4);
         if (scissorEnabled) {
            updateState27(intArray, scissorX, scissorY, scissorWidth, scissorHeight);
         }

         scissorEnabled = true;
         scissorX = intArray[0];
         scissorY = intArray[1];
         scissorWidth = intArray[2];
         scissorHeight = intArray[3];
         updateState4(true, scissorX, scissorY, scissorWidth, scissorHeight);
      }
   }

   public static void updateState16() {
      if (counter != 0) {
         if (--counter <= 0 && !frameOpen) {
            GpuTextureView gpuTextureView2 = initialized ? computeGpuTextureView() : null;
            if (gpuTextureView2 != null && bloomRenderTargets.getBooleanState3()) {
               if (!checkCondition()) {
                  bloomRenderTargets.resetBooleanState3();
               } else {
                  bloomRenderTargets.updateStateForGpuTextureView(gpuTextureView2, (float)Math.max(0.0, doubleSupplier.getAsDouble()));
               }
            }
         }
      }
   }

   public static float computeFloatForFontResourceFamily3(FontResourceFamily fontResourceFamily, String string, float floatState3, float floatValue, float floatValue2, int intValue, float floatValue3) {
      if (string != null && !string.isEmpty() && !(floatValue2 <= 0.0F)) {
         int intState5 = computeInt(intValue);
         float floatValue4 = sqrt();
         float floatValue5 = floatValue2 * floatValue4 * pixelScaleX;
         if (intState5 != 0 && !(floatValue5 < 0.5F) && initialized) {
            float floatState2 = floatValue5 / 40.0F;
            float floatValue6 = FontResourceCache.computeFloatForFontResourceFamily3(fontResourceFamily) * floatValue5;
            boolean booleanValue = transform01 == 0.0F && transform10 == 0.0F && transform00 > 0.0F && transform11 > 0.0F;
            GlyphPreloader glyphPreloader2 = glyphPreloader;
            glyphPreloader2.intState = intState5;
            glyphPreloader2.floatState4 = Math.max(((-0.2F)), Math.min(0.2F, floatValue3));
            glyphPreloader2.floatState2 = floatState2;
            glyphPreloader2.floatState5 = 0.0F;
            if (booleanValue) {
               glyphPreloader2.booleanState = true;
               if (floatValue5 <= 24.0F) {
                  glyphPreloader2.floatState5 = (float)Math.round(floatValue5 * 4.0F) / 4.0F;
               }

               glyphPreloader2.floatState3 = (float)Math.round((transform00 * floatState3 + translateX) * pixelScaleX);
               glyphPreloader2.floatState6 = (float)Math.round((transform11 * floatValue + translateY) * pixelScaleY + floatValue6);
            } else {
               glyphPreloader2.booleanState = false;
               glyphPreloader2.floatState3 = floatState3;
               glyphPreloader2.floatState6 = floatValue + floatValue6 / (floatValue4 * pixelScaleX);
               glyphPreloader2.floatState = 1.0F / (floatValue4 * pixelScaleX);
            }

            float floatValue7 = FontResourceCache.computeFloatForFontResourceFamily(fontResourceFamily, string, floatValue5, glyphPreloader2);
            return floatValue7 / (floatValue4 * pixelScaleX);
         } else {
            return computeFloatForFontResourceFamily(fontResourceFamily, string, floatValue2);
         }
      } else {
         return 0.0F;
      }
   }

   private static void updateState17(
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      float floatValue9,
      float floatValue10,
      float floatValue11,
      float floatValue12,
      float floatValue13,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4
   ) {
      float floatValue14 = floatValue3 * 0.5F;
      float floatValue15 = floatValue4 * 0.5F;
      float floatValue16 = computeFloat3(floatValue10 * 0.5F) + floatValue9 * 0.5F;
      updateState19(
         floatValue + floatValue14,
         floatValue2 + floatValue15,
         1.0F,
         0.0F,
         floatValue14 + floatValue16,
         floatValue15 + floatValue16,
         floatValue14,
         floatValue15,
         floatValue5,
         floatValue6,
         floatValue7,
         floatValue8,
         0.0F,
         floatValue9,
         floatValue10,
         floatValue11,
         0.0F,
         0.0F,
         0.0F,
         0.0F,
         floatValue12,
         floatValue13,
         true,
         intValue,
         intValue2,
         intValue3,
         intValue4
      );
   }

   public static void updateState18(float floatValue, float floatValue2, float floatValue3) {
      translate(floatValue2, floatValue3);
      scale(floatValue, floatValue);
      translate(-floatValue2, -floatValue3);
   }

   private static void updateState19(
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      float floatValue9,
      float floatValue10,
      float floatValue11,
      float floatValue12,
      float floatValue13,
      float floatValue14,
      float floatValue15,
      float floatValue16,
      float floatValue17,
      float floatValue18,
      float floatValue19,
      float floatValue20,
      float floatValue21,
      float floatValue22,
      boolean booleanValue,
      int intValue,
      int intValue2,
      int intValue3,
      int intValue4
   ) {
      updateStateForTextureHandle(
         floatValue,
         floatValue2,
         floatValue3,
         floatValue4,
         floatValue5,
         floatValue6,
         floatValue7,
         floatValue8,
         floatValue9,
         floatValue10,
         floatValue11,
         floatValue12,
         floatValue13,
         floatValue14,
         floatValue15,
         floatValue16,
         floatValue17,
         floatValue18,
         floatValue19,
         floatValue20,
         floatValue21,
         floatValue22,
         booleanValue,
         null,
         intValue,
         intValue2,
         intValue3,
         intValue4
      );
   }

   private Render2D() {
   }

   public static void updateState20(String string, float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue) {
      if (string != null && !(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && initialized) {
         if (!imageCache.containsKey(string)) {
            updateState21();
         }

         TextureHandle texture = imageCache.computeTextureHandle(string);
         if (texture != null) {
            updateStateForTextureHandle3(texture, floatValue, floatValue2, floatValue3, floatValue4, floatValue5, 0.0F, 0.0F, 1.0F, 1.0F, intValue);
         }
      }
   }

   public static void updateState21() {
      if (!runnableList.isEmpty()) {
         ArrayList arrayList = new ArrayList<>(runnableList);
         runnableList.clear();

         for (Runnable runnable : (java.lang.Iterable<Runnable>)(java.lang.Iterable<?>)(arrayList)) {
            runnable.run();
         }
      }

      GpuTextureView targetView = initialized ? computeGpuTextureView() : null;
      if (targetView == null) {
         uiQuadRenderer.reset();
         uiQuadRenderer2.reset();
      } else {
         uiQuadRenderer.flush(cc.mochi.UiRenderPipelines.UI, targetView, gpuBuffer, textureHandle, 1.0F, false);
         if (!uiQuadRenderer2.isEmpty()) {
            GpuTextureView targetView2 = bloomRenderTargets.computeGpuTextureView(targetView.getWidth(0), targetView.getHeight(0));
            boolean clearTarget = bloomRenderTargets.checkCondition();
            uiQuadRenderer2.flush(cc.mochi.UiRenderPipelines.UI_EMISSIVE, targetView2, gpuBuffer, textureHandle, bloomRenderTargets.computeFloat(targetView.getWidth(0)), clearTarget);
         }
      }
   }

   public static void updateState22(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, float floatValue6, int intValue) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F) && floatValue6 != 0.0F) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            if (floatValue6 < 0.0F) {
               floatValue5 += floatValue6;
               floatValue6 = -floatValue6;
            }

            floatValue6 = Math.min(floatValue6, (float) (Math.PI * 2));
            floatValue5 = (float)((double)floatValue5 - (float) (Math.PI * 2) * Math.floor((double)(floatValue5 / (float) (Math.PI * 2))));
            float floatValue7 = floatValue3 + floatValue4 * 0.5F + computeFloat3(0.0F);
            updateState19(
               floatValue,
               floatValue2,
               1.0F,
               0.0F,
               floatValue7,
               floatValue7,
               floatValue3,
               floatValue3,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               4.0F,
               floatValue4,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               floatValue5,
               floatValue6,
               true,
               intValue2,
               intValue2,
               intValue2,
               intValue2
            );
         }
      }
   }

   public static void updateState23() {
      frameOpen = false;
      uiQuadRenderer.reset();
      uiQuadRenderer2.reset();
      if (counter == 0) {
         bloomRenderTargets.resetBooleanState3();
      }

      runnableList.clear();
   }

   public static void scale(float floatValue, float floatValue2) {
      transform00 *= floatValue;
      transform01 *= floatValue;
      transform10 *= floatValue2;
      transform11 *= floatValue2;
   }

   public static void updateState24(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue) {
      updateState25(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, intValue, false);
   }

   public static void updateStateForIdentifier(
      Identifier identifier,
      float floatValue,
      float floatValue2,
      float floatValue3,
      float floatValue4,
      float floatValue5,
      float floatValue6,
      float floatValue7,
      float floatValue8,
      int intValue,
      int intValue2,
      float floatValue9,
      int intValue3
   ) {
      if (initialized) {
         TextureHandle texture = imageCache.computeTextureHandleForIdentifier(identifier);
         if (texture != null && intValue > 0 && intValue2 > 0) {
            updateStateForTextureHandle3(texture, floatValue, floatValue2, floatValue3, floatValue4, floatValue9, floatValue5 / (float)intValue, floatValue6 / (float)intValue2, (floatValue5 + floatValue7) / (float)intValue, (floatValue6 + floatValue8) / (float)intValue2, intValue3);
         }
      }
   }

   public static float computeFloatForFontResourceFamily4(FontResourceFamily fontResourceFamily, float floatValue) {
      return FontResourceCache.computeFloatForFontResourceFamily2(fontResourceFamily) * floatValue;
   }

   public static void pushTransform() {
      if (transformDepth < 64) {
         int intValue = transformDepth++ * 6;
         transformStack[intValue] = transform00;
         transformStack[intValue + 1] = transform01;
         transformStack[intValue + 2] = transform10;
         transformStack[intValue + 3] = transform11;
         transformStack[intValue + 4] = translateX;
         transformStack[intValue + 5] = translateY;
      }
   }

   public static void flushBloom() {
      updateState21();
      GpuTextureView gpuTextureView2 = initialized ? computeGpuTextureView() : null;
      if (gpuTextureView2 != null && bloomRenderTargets.getBooleanState3()) {
         if (!checkCondition()) {
            bloomRenderTargets.resetBooleanState3();
         } else {
            bloomRenderTargets.updateStateForGpuTextureView(gpuTextureView2, (float)Math.max(0.0, doubleSupplier.getAsDouble()));
         }
      }
   }

   private static void updateState25(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue, boolean booleanValue) {
      float floatValue6 = floatValue3 - floatValue;
      float floatValue7 = floatValue4 - floatValue2;
      float floatValue8 = (float)Math.sqrt((double)(floatValue6 * floatValue6 + floatValue7 * floatValue7));
      if (!(floatValue8 <= 1.0E-4F) && !(floatValue5 <= 0.0F)) {
         int intValue2 = computeInt(intValue);
         if (intValue2 != 0) {
            float floatValue9 = floatValue6 / floatValue8;
            float floatValue10 = floatValue7 / floatValue8;
            float floatValue11 = floatValue5 * 0.5F;
            float floatValue12 = floatValue8 * 0.5F + (booleanValue ? floatValue11 : 0.0F);
            float floatValue13 = booleanValue ? floatValue11 : 0.0F;
            float floatValue14 = computeFloat3(0.0F);
            updateState19(
               (floatValue + floatValue3) * 0.5F,
               (floatValue2 + floatValue4) * 0.5F,
               floatValue9,
               floatValue10,
               floatValue12 + floatValue14,
               floatValue11 + floatValue14,
               floatValue12,
               floatValue11,
               floatValue13,
               floatValue13,
               floatValue13,
               floatValue13,
               0.0F,
               0.0F,
               0.0F,
               ((-1.0F)),
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               0.0F,
               true,
               intValue2,
               intValue2,
               intValue2,
               intValue2
            );
         }
      }
   }

   public static void endFrame() {
      if (frameOpen) {
         try {
            if (counter > 0) {
               updateState21();
            } else {
               flushBloom();
            }
         } finally {
            frameOpen = false;
            uiQuadRenderer.reset();
            uiQuadRenderer2.reset();
            if (counter == 0) {
               bloomRenderTargets.resetBooleanState3();
            }

            runnableList.clear();
         }
      }
   }

   public static void updateState26(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue) {
      updateState25(floatValue, floatValue2, floatValue3, floatValue4, floatValue5, intValue, true);
   }

   private static String getStringConstant() {
      return "Mochi UI uniforms";
   }

   private static void updateState27(int[] intArray, int intValue, int intValue2, int intValue3, int intValue4) {
      int intValue5 = Math.max(intArray[0], intValue);
      int intValue6 = Math.max(intArray[1], intValue2);
      int intValue7 = Math.min(intArray[0] + intArray[2], intValue + intValue3);
      int intValue8 = Math.min(intArray[1] + intArray[3], intValue2 + intValue4);
      intArray[0] = intValue5;
      intArray[1] = intValue6;
      intArray[2] = Math.max(0, intValue7 - intValue5);
      intArray[3] = Math.max(0, intValue8 - intValue6);
   }

   public static void applyClip() {
      updateState4(scissorEnabled, scissorX, scissorY, scissorWidth, scissorHeight);
   }

   public static void updateState28(float floatValue, float floatValue2, float floatValue3, float floatValue4, float floatValue5, int intValue, int intValue2, float floatValue6) {
      if (!(floatValue3 <= 0.0F) && !(floatValue4 <= 0.0F)) {
         int intValue3 = computeInt(intValue);
         int intValue4 = computeInt(intValue2);
         if (intValue3 != 0 || intValue4 != 0) {
            float floatValue7 = floatValue3 * 0.5F;
            float floatValue8 = floatValue4 * 0.5F;
            float floatValue9 = (float)(intValue4 >> 16 & 0xFF) * 256.0F + (float)(intValue4 >> 8 & 0xFF);
            float floatValue10 = (float)(intValue4 & 0xFF) * 256.0F + (float)(intValue4 >>> 24);
            float floatValue11 = computeFloat3(0.0F);
            updateStateForTextureHandle(
               floatValue + floatValue7,
               floatValue2 + floatValue8,
               1.0F,
               0.0F,
               floatValue7 + floatValue11,
               floatValue8 + floatValue11,
               floatValue7,
               floatValue8,
               floatValue5,
               floatValue5,
               floatValue5,
               floatValue5,
               6.0F,
               0.0F,
               Math.max(0.05F, floatValue6),
               0.0F,
               floatValue9,
               floatValue10,
               floatValue9,
               floatValue10,
               0.0F,
               0.0F,
               true,
               null,
               intValue3,
               intValue3,
               intValue3,
               intValue3
            );
         }
      }
   }

   private static float sqrt() {
      return (float)Math.sqrt((double)Math.abs(transform00 * transform11 - transform01 * transform10));
   }

   public static void updateStateForStbFontRenderer(StbFontRenderer stbFontRenderer, int intValue, float floatValue) {
      GlyphPreloader glyphPreloader2 = glyphPreloader;
      PositionedGlyph positionedGlyph = stbFontRenderer.computePositionedGlyphForGlyphAtlas2(intValue, glyphPreloader2.floatState5, glyphAtlas);
      if (positionedGlyph != null && positionedGlyph.getSlot() != null) {
         TextureRegion slot = positionedGlyph.getSlot();
         float floatValue2 = (glyphPreloader2.floatState3 + floatValue + positionedGlyph.getXOffset()) / pixelScaleX;
         float floatValue3 = (glyphPreloader2.floatState6 + positionedGlyph.getYOffset()) / pixelScaleY;
         float floatValue4 = positionedGlyph.getWidth() / pixelScaleX * 0.5F;
         float floatValue5 = positionedGlyph.getHeight() / pixelScaleY * 0.5F;
         updateStateForTextureHandle(
            floatValue2 + floatValue4,
            floatValue3 + floatValue5,
            1.0F,
            0.0F,
            floatValue4,
            floatValue5,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            5.0F,
            0.0F,
            0.0F,
            glyphPreloader2.floatState4,
            slot.getU0(),
            slot.getV0(),
            slot.getU1(),
            slot.getV1(),
            0.0F,
            0.0F,
            false,
            slot.getTexture(),
            glyphPreloader2.intState,
            glyphPreloader2.intState,
            glyphPreloader2.intState,
            glyphPreloader2.intState
         );
      }
   }

   private static int computeInt(int intValue) {
      int intValue2 = intValue >>> 24;
      if (opacity < 1.0F) {
         intValue2 = Math.round((float)intValue2 * opacity);
      }

      return intValue2 <= 0 ? 0 : intValue2 << 24 | intValue & 16777215;
   }

   public static void pushBloom(float floatValue) {
      if (bloomDepth < 64) {
         bloomStack[bloomDepth++] = bloomStrength;
         float floatValue2 = bloomDepth == 1 ? 1.0F : bloomStrength;
         bloomStrength = checkCondition() ? Math.max(0.0F, floatValue2 * floatValue) : 0.0F;
      }
   }

   public static void updateState29(float floatValue, float floatValue2, float floatValue3, float floatValue4, int intValue) {
      updateState9(floatValue, floatValue2, floatValue3, floatValue4, 0.0F, 0.0F, 0.0F, 0.0F, intValue);
   }

   public static boolean getInitialized() {
      return initialized;
   }

   public static void initialize() {
      RenderSystem.assertOnRenderThread();
      if (!initialized) {
         try {
            cc.mochi.UiRenderPipelines.precompileAll();
            GpuDevice device = RenderSystem.getDevice();
            gpuTexture = device.createTexture("Mochi white", 5, TextureFormat.RGBA8, 1, 1, 1, 1);
            ByteBuffer byteBuffer = MemoryUtil.memAlloc(4).put((((byte)-1))).put((((byte)-1))).put((((byte)-1))).put((((byte)-1))).flip();

            try {
               device.createCommandEncoder().writeToTexture(gpuTexture, byteBuffer, Format.RGBA, 0, 0, 0, 0, 1, 1);
            } finally {
               MemoryUtil.memFree(byteBuffer);
            }

            gpuTextureView = device.createTextureView(gpuTexture);
            textureHandle = new TextureHandle(gpuTextureView, RenderSystem.getSamplerCache().get(FilterMode.NEAREST), 1, 1, true, false);
            gpuBuffer = device.createBuffer(() -> getStringConstant(), 136, 32L);
            initialized = true;
            logger.info("2D renderer ready (Blaze3D)");
         } catch (LinkageError | RuntimeException failure) {
            updateState8();
            throw failure;
         }
      }
   }

   private static void updateState30() {
      MemoryStack memoryStack = MemoryStack.stackPush();

      try {
         ByteBuffer byteBuffer = Std140Builder.onStack(memoryStack, 32).putVec4(viewportWidth, viewportHeight, 1.0F / viewportWidth, 1.0F / viewportHeight).putVec4(computeFloat2(), 0.003921569F, 0.0F, 0.0F).get();
         RenderSystem.getDevice().createCommandEncoder().writeToBuffer(gpuBuffer.slice(), byteBuffer);
      } catch (Throwable failure) {
         if (memoryStack != null) {
            try {
               memoryStack.close();
            } catch (Throwable failure2) {
               failure.addSuppressed(failure2);
            }
         }

         throw failure;
      }

      if (memoryStack != null) {
         memoryStack.close();
      }
   }

   public static void popBloom() {
      if (bloomDepth != 0) {
         bloomStrength = bloomStack[--bloomDepth];
      }
   }

   private static int[] computeIntArray(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      float positiveInfinity = Float.POSITIVE_INFINITY;
      float positiveInfinity2 = Float.POSITIVE_INFINITY;
      float negativeInfinity = Float.NEGATIVE_INFINITY;
      float negativeInfinity2 = Float.NEGATIVE_INFINITY;

      for (int intValue = 0; intValue < 4; intValue++) {
         float floatValue5 = (intValue & 1) == 0 ? floatValue : floatValue + floatValue3;
         float floatValue6 = (intValue & 2) == 0 ? floatValue2 : floatValue2 + floatValue4;
         float floatValue7 = (transform00 * floatValue5 + transform10 * floatValue6 + translateX) * pixelScaleX;
         float floatValue8 = (transform01 * floatValue5 + transform11 * floatValue6 + translateY) * pixelScaleY;
         positiveInfinity = Math.min(positiveInfinity, floatValue7);
         negativeInfinity = Math.max(negativeInfinity, floatValue7);
         positiveInfinity2 = Math.min(positiveInfinity2, floatValue8);
         negativeInfinity2 = Math.max(negativeInfinity2, floatValue8);
      }

      int intValue2 = (int)Math.floor((double)positiveInfinity);
      int intValue3 = (int)Math.floor((double)positiveInfinity2);
      int intValue4 = (int)Math.ceil((double)negativeInfinity);
      int intValue5 = (int)Math.ceil((double)negativeInfinity2);
      return new int[]{intValue2, framebufferHeight - intValue5, Math.max(0, intValue4 - intValue2), Math.max(0, intValue5 - intValue3)};
   }
}
