package cc.mochi.mixin;

import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Window.class})
public class WindowMixin {
   @Inject(
      method = {"<init>"},
      at = {@At(
         value = "INVOKE",
         target = "Lorg/lwjgl/glfw/GLFW;glfwCreateWindow(IILjava/lang/CharSequence;JJ)J",
         shift = Shift.BEFORE
      )}
   )
   private void enableDebugContext(CallbackInfo ci) {
      GLFW.glfwWindowHint(139271, 1);
   }
}
