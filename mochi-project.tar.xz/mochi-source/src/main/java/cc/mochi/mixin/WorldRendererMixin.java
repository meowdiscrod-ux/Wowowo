package cc.mochi.mixin;

import cc.mochi.ItemMeshRenderer;
import cc.mochi.StreamRenderLayers;
import cc.mochi.MochiClient;
import cc.mochi.Render3D;
import cc.mochi.event.impl.render.Render3DEvent;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public class WorldRendererMixin {
   @Inject(
      method = {"method_62214"},
      at = {@At(
         value = "INVOKE:LAST",
         target = "Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;draw()V",
         shift = Shift.AFTER
      )}
   )
   private void mochi$renderWorldVisuals(CallbackInfo ci) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (MochiClient.INSTANCE != null && minecraftClient.world != null && minecraftClient.gameRenderer != null) {
         Vec3d cameraPos = minecraftClient.gameRenderer.getCamera().getCameraPos();
         float tickProgress = minecraftClient.getRenderTickCounter().getTickProgress(true);
         boolean booleanValue = StreamRenderLayers.checkCondition2();
         Render3D.updateStateForVec3d2(cameraPos, tickProgress);

         try {
            MochiClient.INSTANCE.getMochiEventBus().post(new Render3DEvent(new MatrixStack(), cameraPos, tickProgress));
         } finally {
            try {
               Render3D.updateState11();
            } finally {
               if (booleanValue) {
                  StreamRenderLayers.updateState11();
               }
            }
         }
      }
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void mochi$beginOutlineFrame(
      ObjectAllocator allocator,
      RenderTickCounter tickCounter,
      boolean renderBlockOutline,
      Camera camera,
      Matrix4f positionMatrix,
      Matrix4f basicProjectionMatrix,
      Matrix4f projectionMatrix,
      GpuBufferSlice fogBuffer,
      Vector4f fogColor,
      boolean renderSky,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateStateForMatrix4fc2(positionMatrix, basicProjectionMatrix);
      Render3D.mul(positionMatrix, basicProjectionMatrix);
   }

   @Inject(
      method = {"render"},
      at = {@At("RETURN")}
   )
   private void mochi$endOutlineFrame(
      ObjectAllocator allocator,
      RenderTickCounter tickCounter,
      boolean renderBlockOutline,
      Camera camera,
      Matrix4f positionMatrix,
      Matrix4f basicProjectionMatrix,
      Matrix4f projectionMatrix,
      GpuBufferSlice fogBuffer,
      Vector4f fogColor,
      boolean renderSky,
      CallbackInfo ci
   ) {
      ItemMeshRenderer.updateState3();
   }
}
