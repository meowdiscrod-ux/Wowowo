package cc.mochi.mixin;

import cc.mochi.AntiDebuffModule;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.fog.StatusEffectFogModifier;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({StatusEffectFogModifier.class})
public class StatusEffectFogModifierMixin {
   @Inject(
      method = {"shouldApply"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldApply(CameraSubmersionType type, Entity entity, CallbackInfoReturnable<Boolean> cir) {
      if (AntiDebuffModule.checkCondition()) {
         cir.setReturnValue(false);
      }
   }
}
