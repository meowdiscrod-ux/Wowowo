package cc.mochi.mixin;

import cc.mochi.NickModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListHud.class})
public class PlayerListHudMixin {
   @Inject(
      method = {"getPlayerName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void mochi$nickTabList(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient.player != null && entry.getProfile().id().equals(minecraftClient.player.getUuid())) {
         cir.setReturnValue(NickModule.computeTextForText2((Text)cir.getReturnValue()));
      }
   }
}
