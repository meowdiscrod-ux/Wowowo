package cc.mochi.mixin;

import cc.mochi.FreeCamModule;
import cc.mochi.RotationManager;
import cc.mochi.MochiClient;
import cc.mochi.event.impl.input.MouseClickEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseMixin {
   @Shadow
   @Final
   private MinecraftClient field_1779;

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")}
   )
   private void onMouseButton(long window, MouseInput mouseInput, int action, CallbackInfo ci) {
      if (MochiClient.INSTANCE != null) {
         if (window == this.field_1779.getWindow().getHandle()) {
            if (this.field_1779.currentScreen == null) {
               MouseClickEvent mouseClickEvent = new MouseClickEvent(mouseInput.button(), action, mouseInput.modifiers());
               MochiClient.INSTANCE.getMochiEventBus().post(mouseClickEvent);
            }
         }
      }
   }

   @Redirect(
      method = {"updateMouse(D)V"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"
      )
   )
   private void redirectLocalPlayerLook(ClientPlayerEntity player, double cursorDeltaX, double cursorDeltaY) {
      if (!FreeCamModule.checkCondition3(cursorDeltaX, cursorDeltaY)) {
         RotationManager.updateStateForClientPlayerEntity(player, cursorDeltaX, cursorDeltaY);
      }
   }
}
