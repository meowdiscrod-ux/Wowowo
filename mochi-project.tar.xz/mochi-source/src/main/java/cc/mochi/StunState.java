package cc.mochi;

public enum StunState {
   IDLE,
   WAITING_ATTACK,
   WAITING_STUN,
   WAITING_SWAP_BACK;

   private static final StunState[] ENUM_VALUES = {IDLE, WAITING_ATTACK, WAITING_STUN, WAITING_SWAP_BACK};

   public static StunState getIDLE() {
      return IDLE;
   }

   public static StunState[] getENUM_VALUES() {
      return ENUM_VALUES;
   }

   private static StunState[] computeStunStateArray() {
      StunState[] stunStateArray = new StunState[]{getIDLE(), WAITING_ATTACK, WAITING_STUN, null};

      stunStateArray[3] = WAITING_SWAP_BACK;
      return stunStateArray;
   }
}
