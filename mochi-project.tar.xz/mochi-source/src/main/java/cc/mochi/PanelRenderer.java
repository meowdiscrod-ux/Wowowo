package cc.mochi;

import java.awt.Color;

public final class PanelRenderer {
   public static void updateStateForUiContext(UiContext uiContext, Rect rect, float radius, float floatValue2, float floatValue3) {
      if (!(floatValue2 <= 0.001F)) {
         Color color = uiContext.getThemeSnapshot().getLight4() ? uiContext.getThemeSnapshot().getPrimaryText() : Color.WHITE;
         uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiRenderContext.withAlpha(color, 255.0F * (uiContext.getThemeSnapshot().getLight4() ? 0.05F : 0.045F) * floatValue2 * floatValue3));
      }
   }

   public static void updateStateForUiContext2(UiContext uiContext, float x, float y, float floatValue3, float floatValue4) {
      uiContext.getUiRenderContext().fillRect(x, y, 1.0F, floatValue3 - y, UiContext.multiplyAlpha(uiContext.getThemeSnapshot().getHairline2(), 0.8F * floatValue4));
   }

   public static void updateStateForUiContext3(UiContext uiContext, float x, float y, float floatValue3, float floatValue4) {
      uiContext.getUiRenderContext().fillRect(x, y, floatValue3 - x, 1.0F, UiContext.multiplyAlpha(uiContext.getThemeSnapshot().getHairline2(), 0.8F * floatValue4));
   }

   public static void updateStateForUiContext4(UiContext uiContext, Rect rect, float radius, float floatValue2, float floatValue3) {
      if (!(floatValue2 <= 0.001F)) {
         ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
         uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getAccentSoft2(), floatValue2 * floatValue3));
         uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getAccent2(), 0.35F * floatValue2 * floatValue3));
      }
   }

   public static void updateStateForUiContext5(UiContext uiContext, Rect rect, float radius, float floatValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      boolean booleanValue = ClickGuiModule.checkCondition2();
      uiContext.getUiRenderContext()
         .drawGlassCard(
            rect.getX(),
            rect.getY(),
            rect.getWidth(),
            rect.getHeight(),
            radius,
            themeSnapshot2,
            UiRenderContext.withAlpha(themeSnapshot2.getShellGlass(), (float)Math.min(255, themeSnapshot2.getShellGlass().getAlpha() + 14)),
            floatValue2,
            booleanValue ? 1.4F : 1.15F,
            0.0F
         );
   }

   private PanelRenderer() {
   }

   public static void updateStateForUiContext6(UiContext uiContext, float floatValue, float floatValue2, float floatValue3) {
      Color color = uiContext.getThemeSnapshot().getLight4() ? new Color(20, 18, 28) : ColorAccess4.getBLACK();
      uiContext.getUiRenderContext().fillRect(((-4.0F)), ((-4.0F)), floatValue + 8.0F, floatValue2 + 8.0F, UiRenderContext.withAlpha(color, 107.1F * floatValue3));
   }

   public static void updateStateForUiContext7(UiContext uiContext, Rect rect, float radius, float floatValue2, float floatValue3) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Color color = UiContext.blendColors(themeSnapshot2.getSurface2(), themeSnapshot2.getSurfaceRaised(), 0.35F + 0.65F * floatValue2);
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(color, floatValue3));
   }

   public static void drawCard(UiContext uiContext, Rect rect, float floatValue) {
      uiContext.getUiRenderContext().drawCard(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 14.0F, uiContext.getThemeSnapshot(), floatValue, 1.5F, 0.0F);
   }

   public static void drawCard2(UiContext uiContext, Rect rect, float floatValue) {
      uiContext.getUiRenderContext().drawCard(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), 10.0F, uiContext.getThemeSnapshot(), floatValue, 0.9F, 0.0F);
   }

   public static void updateStateForUiContext8(UiContext uiContext, Rect rect, float radius, float floatValue2, float floatValue3) {
      Color shadow2 = uiContext.getThemeSnapshot().getTheme().getShadow2();
      uiContext.getUiRenderContext().drawGlowOutline(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 18.0F * floatValue2, 6.0F * floatValue2, UiRenderContext.withAlpha(shadow2, 96.9F * floatValue3));
   }

   public static void updateStateForUiContext9(UiContext uiContext, Rect rect, float radius, float floatValue2) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      uiContext.getUiRenderContext().fillRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, UiContext.multiplyAlpha(themeSnapshot2.getSurfaceSunken(), floatValue2));
      uiContext.getUiRenderContext().strokeRoundedRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight(), radius, 1.0F, UiContext.multiplyAlpha(themeSnapshot2.getHairline2(), 0.55F * floatValue2));
   }
}
