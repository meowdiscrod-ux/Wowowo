package cc.mochi;

public class RangeSliderDragHandler implements DragHandler {
   final SettingEditor settingEditor;

   final float floatState;

   final float floatState2;

   final DoubleRangeSetting doubleRangeSetting;

   public static SettingEditor getSettingEditor(RangeSliderDragHandler rangeSliderDragHandler) {
      return rangeSliderDragHandler.settingEditor;
   }

   public static int getIntState(SettingEditor settingEditor2) {
      return settingEditor2.intState;
   }

   public static DoubleRangeSetting getDoubleRangeSetting(RangeSliderDragHandler rangeSliderDragHandler) {
      return rangeSliderDragHandler.doubleRangeSetting;
   }

   public static float getFloatState(RangeSliderDragHandler rangeSliderDragHandler) {
      return rangeSliderDragHandler.floatState;
   }

   @Override
   public void release(double doubleValue, double doubleValue2) {
      getSettingEditor(this).setting = null;
      setIntState(getSettingEditor(this), -1);
   }

   RangeSliderDragHandler(SettingEditor settingEditor2, float floatState3, float floatState22, DoubleRangeSetting doubleRangeSetting2) {
      this.settingEditor = settingEditor2;
      this.floatState = floatState3;
      this.floatState2 = floatState22;
      this.doubleRangeSetting = doubleRangeSetting2;
   }

   public static void setIntState(SettingEditor settingEditor2, int intState) {
      settingEditor2.intState = intState;
   }

   @Override
   public void drag(double doubleValue, double doubleValue2) {
      float floatValue = SliderWidgets.computeFloat(doubleValue, getFloatState(this), this.floatState2);
      setIntState(this.settingEditor, SettingEditor.computeIntForDoubleRangeSetting(getDoubleRangeSetting(this), getIntState(getSettingEditor(this)), floatValue));
      SettingEditor.updateStateForDoubleRangeSetting(getDoubleRangeSetting(this), this.settingEditor.intState, floatValue);
   }

}
