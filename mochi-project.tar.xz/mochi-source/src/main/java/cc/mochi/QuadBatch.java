package cc.mochi;

record QuadBatch(TextureHandle texture, boolean scissor, int x, int y, int w, int h, int firstQuad, int quadCount) {
   public int getH() {
      return this.h;
   }

   public int getX() {
      return this.x;
   }

   public int getQuadCount() {
      return this.quadCount;
   }

   public int getFirstQuad() {
      return this.firstQuad;
   }

   public int getW() {
      return this.w;
   }

   public int getY() {
      return this.y;
   }

   public TextureHandle getTexture() {
      return this.texture;
   }

   public boolean getScissor() {
      return this.scissor;
   }
}
