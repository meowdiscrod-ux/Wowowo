package cc.mochi;

public class ThemeChoiceSetting extends ChoiceSetting {
   @Override
   public void cycle() {
      super.cycle();
      ThemeManager.updateState(this.getSelected());
   }

   @Override
   public void select(String string) {
      super.select(string);
      ThemeManager.updateState(this.getSelected());
   }

   ThemeChoiceSetting(String name, String string2, String... stringArray) {
      super(name, string2, stringArray);
   }
}
