package cc.mochi;

import cc.mochi.event.types.TransferOrder;

public class TransferOrderAccess {
   public static TransferOrder getRECEIVE() {
      return TransferOrder.RECEIVE;
   }
}
