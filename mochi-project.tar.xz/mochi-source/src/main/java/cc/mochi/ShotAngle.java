package cc.mochi;

public record ShotAngle(float yaw, float pitch, double margin) {
   public float getPitch() {
      return this.pitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public double getMargin() {
      return this.margin;
   }
}
