package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.World;

public final class ProjectileLaunchMath {
   private static final float floatState = (float) (Math.PI / 180.0);

   public static Vec3d computeVec3dForVec3d(float floatValue, float floatValue2, float floatValue3, Vec3d vec3d, Vec3d vec3d2, boolean booleanValue) {
      Vec3d vec3d3 = computeVec3d(floatValue, floatValue2).normalize();
      if (vec3d != null) {
         vec3d3 = vec3d3.add(Vec3dAccess3.getX(vec3d), vec3d.y, Vec3dAccess3.getZ(vec3d));
      }

      vec3d3 = vec3d3.multiply((double)floatValue3);
      return vec3d3.add(Vec3dAccess3.getX(vec3d2), booleanValue ? 0.0 : Vec3dAccess3.getY(vec3d2), vec3d2.z);
   }

   public static float computeFloat(float floatValue) {
      float floatValue2 = MathHelper.wrapDegrees(floatValue);

      float floatValue3 = MathHelper.clamp(floatValue2, ((-90.0F)), 90.0F) % 360.0F;
      return Math.clamp(floatValue3 % 360.0F, ((-90.0F)), 90.0F);
   }

   public static float[] computeFloatArrayForVec3d(Vec3d vec3d) {
      double doubleValue = Math.sqrt(vec3d.x * Vec3dAccess3.getX(vec3d) + Vec3dAccess3.getZ(vec3d) * Vec3dAccess3.getZ(vec3d));
      float floatValue = (float)Math.toDegrees(Math.atan2(-vec3d.x, Vec3dAccess3.getZ(vec3d)));
      float floatValue2 = (float)Math.toDegrees(Math.atan2(-Vec3dAccess3.getY(vec3d), doubleValue));

      float[] floatArray = new float[]{floatValue, 0.0F};

      floatArray[1] = floatValue2;
      return floatArray;
   }

   public static float[] computeFloatArrayForVec3d2(Vec3d vec3d, float floatValue) {
      double doubleValue = Math.sqrt(vec3d.x * vec3d.x + vec3d.z * Vec3dAccess3.getZ(vec3d));

      if (doubleValue <= (1.0E-6) * vec3d.length()) {
         float[] floatArray = new float[]{floatValue, 0.0F};
         double y4 = Vec3dAccess3.getY(vec3d);

         floatArray[1] = y4 >= (0.0) ? ((-90.0F)) : (90.0F);
         return floatArray;
      } else {
         float[] floatArray2 = computeFloatArrayForVec3d(vec3d);

         floatArray2[0] = floatValue + MathHelper.wrapDegrees(floatArray2[0] - floatValue);
         return floatArray2;
      }
   }

   public static boolean testWorld(World world, Box box) {
      if (world == null) {
         return false;
      } else {
         Box box2 = box.contract((0.001));
         int intValue = MathHelper.floor(box2.minX);
         int intValue2 = MathHelper.ceil(Vec3dAccess3.getMaxX(box2));
         int intValue3 = MathHelper.floor(Vec3dAccess3.getMinY(box2));
         int intValue4 = MathHelper.ceil(box2.maxY);
         int intValue5 = MathHelper.floor(box2.minZ);
         int intValue6 = MathHelper.ceil(box2.maxZ);
         Mutable mutable = new Mutable();

         for (int intValue7 = intValue; intValue7 < intValue2; intValue7++) {
            int intValue32 = intValue3;

            while (true) {
               if (intValue32 >= intValue4) {
                  break;
               }

               int intValue52 = intValue5;

               while (intValue52 < intValue6) {
                  mutable.set(intValue7, intValue32, intValue52);
                  FluidState fluidState = world.getFluidState(mutable);
                  if (fluidState.isIn(FluidTags.WATER)) {
                     ThreadLocalRandom.current().nextInt(13);

                     ThreadLocalRandom.current().nextInt(4);
                     if ((double)((float)intValue32 + fluidState.getHeight(world, mutable)) >= Vec3dAccess3.getMinY(box2)) {
                        return true;
                     }
                  } else {
                     ThreadLocalRandom.current().nextInt(8);
                  }

                  intValue52++;
               }

               intValue32++;
            }
         }

         return false;
      }
   }

   public static Vec3d createVec3d(ClientPlayerEntity clientPlayerEntity) {
      return new Vec3d(clientPlayerEntity.getX() - clientPlayerEntity.lastX, clientPlayerEntity.getY() - clientPlayerEntity.lastY, clientPlayerEntity.getZ() - clientPlayerEntity.lastZ);
   }

   public static Vec3d computeVec3dForVec3d2(Vec3d vec3d, double doubleValue) {
      double x = vec3d.x;
      double doubleValue2 = vec3d.y + doubleValue;

      return new Vec3d(x, doubleValue2 - (0.10000000149011612), vec3d.z);
   }

   public static float[] computeFloatArrayForVec3d3(Vec3d vec3d, float floatValue) {
      double doubleValue = (double)(-MathHelper.sin((double)(floatValue * (0.017453292F)))) * vec3d.x
         + (double)MathHelper.cos((double)(floatValue * (0.017453292F))) * Vec3dAccess3.getZ(vec3d);
      float floatValue2 = (float)Math.toDegrees(Math.atan2(-Vec3dAccess3.getY(vec3d), Math.max(0.0, doubleValue)));
      float[] floatArray = new float[2];

      floatArray[0] = floatValue;
      floatArray[1] = floatValue2;
      return floatArray;
   }

   public static double computeDouble(float floatValue, float floatValue2, float floatValue3, float floatValue4) {
      Vec3d vec3d = computeVec3d(floatValue, floatValue2).normalize();
      Vec3d vec3d2 = computeVec3d(floatValue3, floatValue4).normalize();
      return Math.toDegrees(Math.acos(MathHelper.clamp(vec3d.dotProduct(vec3d2), ((-1.0)), 1.0)));
   }

   public static Vec3d computeVec3d(float floatValue, float floatValue2) {
      float floatValue3 = -MathHelper.sin((double)(floatValue * (0.017453292F))) * MathHelper.cos((double)(floatValue2 * (float) (Math.PI / 180.0)));
      float floatValue4 = -MathHelper.sin((double)((floatValue2 + (0.0F)) * (float) (Math.PI / 180.0)));
      float floatValue5 = MathHelper.cos((double)(floatValue * (float) (Math.PI / 180.0))) * MathHelper.cos((double)(floatValue2 * (float) (Math.PI / 180.0)));
      return new Vec3d((double)floatValue3, (double)floatValue4, (double)floatValue5);
   }

   public static Vec3d createVec3d2(Vec3d vec3d, double doubleValue) {
      return new Vec3d(vec3d.x, Vec3dAccess3.getY(vec3d) + doubleValue, Vec3dAccess3.getZ(vec3d));
   }

   public static float max(int intValue) {
      return Math.max((0.0F), Math.min(0.3F, (float)(intValue - 2) / (20.0F)));
   }

   private ProjectileLaunchMath() {
   }

   public static float computeFloat2(float floatValue) {
      float floatValue2 = MathHelper.wrapDegrees(floatValue);

      return floatValue2 % (360.0F);
   }
}
