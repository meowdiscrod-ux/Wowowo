package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.SimpleOption;

public final class SprintModule extends Module {
   public SprintModule() {
      super("Sprint", "Makes you automatically sprint", -1, ModuleCategory.MOVEMENT);
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (this.isWorldUnavailable()) {
         ThreadLocalRandom.current().nextInt(16);
      } else {
         if ((Boolean)mc.options.getSprintToggled().getValue()) {
            SimpleOption sprintToggled = mc.options.getSprintToggled();

            sprintToggled.setValue(false);
         } else {
            ThreadLocalRandom.current().nextInt(11);
         }

         KeyBinding sprintKey = GameOptionsAccess2.getSprintKey(GameOptionsAccess2.getOptions(mc));

         sprintKey.setPressed(true);
      }
   }
}
