package cc.mochi;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

public final class WorldEntityPredicates implements MinecraftAccess {
   private static boolean testEntity(Entity entity) {
      return entity instanceof ItemEntity;
   }

   public static boolean testBlockPos(BlockPos blockPos) {
      if (testBlockPos2(blockPos, MinecraftClientAccess27.getRESPAWN_ANCHOR())) {
         return ((Integer)mc.world.getBlockState(blockPos).get(MinecraftClientAccess27.getCHARGES()) != 0);
      } else {
         return false;
      }
   }

   public static boolean testBlockPos2(BlockPos blockPos, Block block) {
      return (mc.world.getBlockState(blockPos).getBlock() == block);
   }

   public static boolean testBlockPos3(BlockPos blockPos) {
      BlockPos blockPos2 = blockPos.up();
      if (!MinecraftClientAccess27.getWorld(mc).isAir(blockPos2)) {
         return false;
      } else {
         double x = (double)blockPos2.getX();
         double y = (double)blockPos2.getY();
         double z = (double)blockPos2.getZ();
         ClientWorld world2 = MinecraftClientAccess27.getWorld(mc);
         double doubleValue = x + 1.0;

         List otherEntities = world2.getOtherEntities(
            null, new Box(x, y, z, doubleValue, y + (1.0), z + 1.0)
         );
         otherEntities.removeIf(objectValue -> testEntity((Entity)objectValue));
         return otherEntities.isEmpty();
      }
   }
}
