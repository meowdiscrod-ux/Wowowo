package cc.mochi;

public class RefillItemKindAccess2 {
   public static RefillItemKind getTOTEM() {
      return RefillItemKind.TOTEM;
   }

   public static RefillItemKind getPOTION() {
      return RefillItemKind.POTION;
   }

   public static RefillItemKind getNONE() {
      return RefillItemKind.NONE;
   }
}
