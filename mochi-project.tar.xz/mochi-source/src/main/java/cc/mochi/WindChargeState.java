package cc.mochi;

public enum WindChargeState {
   IDLE,
   FLICK,
   THROW,
   RECOVER;

   public static WindChargeState getIDLE() {
      return IDLE;
   }

   private static WindChargeState[] computeWindChargeStateArray() {
      WindChargeState[] windChargeStateArray = new WindChargeState[4];

      windChargeStateArray[0] = getIDLE();

      windChargeStateArray[1] = FLICK;
      windChargeStateArray[2] = THROW;
      windChargeStateArray[3] = getRECOVER();
      return windChargeStateArray;
   }

   public static WindChargeState getRECOVER() {
      return RECOVER;
   }
}
