package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEndEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.render.Render2DEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.mixin.HandledScreenAccessor;
import cc.mochi.mixin.KeyBindingAccessor;
import cc.mochi.utils.combat.SystemInputSimulator;
import cc.mochi.utils.keybinding.simulation.CursorGlide;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BooleanSupplier;
import java.util.function.IntToDoubleFunction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import org.lwjgl.glfw.GLFW;

public final class PotRefillModule extends Module {
   private Slot slot;

   private long longState;

   private final DoubleSetting healingThresholdSetting;

   private final KeybindSetting refillKeySetting;

   private long timestampMillis;

   private Slot slot2;

   private final Random random;

   private PotionRefillSlotMove potionRefillSlotMove;

   private final DoubleRangeSetting clickDelayMsSetting;

   private long longState2;

   private final Stopwatch stopwatch;

   private int counter;

   private final ChoiceSetting refillMethodSetting;

   private final DoubleSetting cursorSpeedSetting;

   private int intState;
   private int intState2;
   private int intState3;

   private boolean booleanState;

   private boolean booleanState2;

   private final BooleanSetting strictTickPacingSetting;

   private Slot slot3;

   private final ChoiceSetting modeSetting;

   private int intState4;

   private final BooleanSetting autoRefillSetting;

   private final BooleanSetting restoreTotemsSetting;

   private final HotbarPatternSetting hotbarPatternSetting = new HotbarPatternSetting("Hotbar Pattern");

   private PotionRefillSlotMove potionRefillSlotMove2;
   private final boolean[] booleanArray2;

   private final CursorGlide cursorGlide;
   private int intState5;

   private String string;

   private PotionRefillState potionRefillState;

   private final BooleanSetting healingFallbackSetting;

   private boolean booleanState3;

   public static CursorGlide getCursorGlide(PotRefillModule potRefillModule) {
      return potRefillModule.cursorGlide;
   }

   public static PotionRefillState getOPENING() {
      return PotionRefillState.OPENING;
   }

   public static Stopwatch getStopwatch(PotRefillModule potRefillModule) {
      return potRefillModule.stopwatch;
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      HotbarSelectionManager.updateState2();
      if (!PlayerStateUtils.isPlayerUnavailable()) {
         if (MinecraftClientAccess51.getInteractionManager(mc) != null) {
            setIntState3(this, HotbarSelectionManager.checkCondition3() ? this.intState3 + 1 : 0);
            boolean booleanState22 = this.checkCondition3();
            byte byteValue;
            if (booleanState22 && !this.booleanState2) {
               byteValue = 17;
               ThreadLocalRandom.current().nextInt(14);
               byteValue = 1;
            } else {
               byteValue = 0;
            }

            byte byteValue2 = byteValue;
            this.booleanState2 = booleanState22;
            if (getPotionRefillState(this) == PotionRefillState.IDLE) {
               if (byteValue2 != 0 || this.checkCondition4()) {
                  this.updateState((byteValue2 != 0));
               }
            }

            if (this.potionRefillState == PotionRefillState.IDLE) {
               return;
            }

            if (this.booleanState3 == this.equals()) {
               this.updateState7(0L);
               return;
            }

            byteValue = 18;
            ThreadLocalRandom.current().nextInt(15);
            if (getBooleanState3(this)) {
               this.updateState5();
            } else {
               this.updateState3();
            }

            return;
         }
      }

      this.updateState10();
   }

   public static void setPotionRefillSlotMove2(PotRefillModule potRefillModule, PotionRefillSlotMove potionRefillSlotMove22) {
      potRefillModule.potionRefillSlotMove2 = potionRefillSlotMove22;
   }

   private boolean checkCondition() {
      if (this.potionRefillState != PotionRefillState.IDLE) {
         if (this.potionRefillState != PotionRefillState.SILENT) {
            if (this.potionRefillState != PotionRefillState.OPENING) {
               ThreadLocalRandom.current().nextInt(7);
               if (!getBooleanState3(this)) {
                  if (MinecraftClientAccess51.getPlayer(mc) != null) {
                     if (MinecraftClientAccess51.getInteractionManager(mc) != null) {
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   public static void setIntState5(PotRefillModule potRefillModule, int intState52) {
      potRefillModule.intState5 = intState52;
   }

   public static void setSlot2(PotRefillModule potRefillModule, Slot slot22) {
      potRefillModule.slot2 = slot22;
   }

   public static PotionRefillState getPotionRefillState(PotRefillModule potRefillModule) {
      return potRefillModule.potionRefillState;
   }

   public static long getLongState2(PotRefillModule potRefillModule) {
      return potRefillModule.longState2;
   }

   private boolean testInventoryScreen(InventoryScreen inventoryScreen) {
      return (!getString(this).equals(HotbarPatternCapture.computeStringForItemStack(((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack())));
   }

   private boolean checkCondition2() {
      int intState42 = getIntState4(this);

      if ((this.intState4 = intState42 + 1) > this.intState) {
         this.updateState7(3000L);

         return false;
      } else {
         ThreadLocalRandom.current().nextInt(7);
         return true;
      }
   }

   public static void setSlot3(PotRefillModule potRefillModule, Slot slot32) {
      potRefillModule.slot3 = slot32;
   }

   public static PotionRefillState getRETURN() {
      return PotionRefillState.RETURN;
   }

   private void updateState(boolean booleanValue) {
      Arrays.fill(this.booleanArray2, false);
      this.potionRefillSlotMove = null;

      this.intState5 = 0;

      setCounter(this, 0);
      if (this.hotbarPatternSetting.hasPatterns()) {
         if (this.computePotionRefillSlotMoveForIntToDoubleFunction(null) != null) {
            setIntState4(this, 0);
            int intValue = this.computeInt();

            setIntState(this, intValue * 3 * 2);
            setBooleanState3(this, ((!this.equals() ? 1 : 0) != 0));
            if (this.booleanState3) {
               if (MinecraftClientAccess51.getCurrentScreen(mc) != null) {
                  return;
               }

               this.updateStateForPotionRefillState(PotionRefillState.SILENT, this.computeLong2());
            } else {
               if (mc.currentScreen instanceof InventoryScreen) {
                  setBooleanState(this, false);
                  this.updateStateForPotionRefillState(PotionRefillState.SETTLE, this.computeLong());
               } else if (mc.currentScreen == null) {
                  this.updateStateForPotionRefillState(PotionRefillState.OPENING, booleanValue ? 0L : this.computeLong2());
               } else {
               }
            }

            return;
         }
      }
   }

   public static boolean getBooleanState(PotRefillModule potRefillModule) {
      return potRefillModule.booleanState;
   }

   public static void setIntState4(PotRefillModule potRefillModule, int intState42) {
      potRefillModule.intState4 = intState42;
   }

   private long computeLong() {
      return (20L) + (long)this.random.nextInt(30);
   }

   public static void setString(PotRefillModule potRefillModule, String string2) {
      potRefillModule.string = string2;
   }

   public static void setBooleanState(PotRefillModule potRefillModule, boolean booleanState4) {
      potRefillModule.booleanState = booleanState4;
   }

   public static PotionRefillState getCLOSING() {
      return PotionRefillState.CLOSING;
   }

   private void updateState2() {
      if (mc.currentScreen instanceof InventoryScreen) {
         ThreadLocalRandom.current().nextInt(10);

         setBooleanState(this, false);
         this.updateStateForPotionRefillState(PotionRefillState.SETTLE, this.computeLong());
      } else {
         if (MinecraftClientAccess51.getCurrentScreen(mc) == null) {
            if (!mc.interactionManager.hasRidingInventory()) {
               ThreadLocalRandom.current().nextInt(11);

               if (!MinecraftClientAccess51.getPlayer(mc).isUsingItem()) {
                  if (this.stopwatch.checkCondition(getLongState2(this))) {
                     mc.setScreen(new InventoryScreen(MinecraftClientAccess51.getPlayer(mc)));
                     setBooleanState(this, true);
                     this.updateStateForPotionRefillState(PotionRefillState.SETTLE, this.computeLong());
                     return;
                  }
               }

               return;
            }
         }

         this.updateState7((0L));
      }
   }

   public static Random getRandom(PotRefillModule potRefillModule) {
      return potRefillModule.random;
   }

   public static int getIntState2(PotRefillModule potRefillModule) {
      return potRefillModule.intState2;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.updateState10();
   }

   public static void setSlot(PotRefillModule potRefillModule, Slot slot4) {
      potRefillModule.slot = slot4;
   }

   private void updateState3() {
      if (getPotionRefillState(this) == PotionRefillState.OPENING) {
         this.updateState2();
      } else {
         Screen currentScreen4 = MinecraftClientAccess51.getCurrentScreen(mc);
         if (currentScreen4 instanceof InventoryScreen) {
            InventoryScreen currentScreen42 = (InventoryScreen)currentScreen4;
            this.updateState6();
            this.counter++;
            this.updateStateForInventoryScreen2(currentScreen42);
         } else {
            this.updateState7(3000L);
         }
      }
   }

   private void updateStateForInventoryScreen(InventoryScreen inventoryScreen) {
      ItemStack cursorStack = ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack();
      switch (this.potionRefillState) {
         case SETTLE:

         case PLAN:
            if (!getStopwatch(this).checkCondition(this.longState2)) {
               return;
            }

            if (!cursorStack.isEmpty()) {
               this.updateState7(3000L);
               return;
            }

            this.updateStateForInventoryScreen5(inventoryScreen);

            break;
         case SOURCE:
            if (this.slot2.hasStack() && getString(this).equals(HotbarPatternCapture.computeStringForItemStack(getSlot2(this).getStack()))) {
               this.updateStateForInventoryScreen4(inventoryScreen);
               break;
            }

            this.updateStateForPotionRefillState(PotionRefillState.PLAN, 0L);
            return;
         case TARGET:
         case RETURN:
            if (cursorStack.isEmpty()) {
               this.updateStateForPotionRefillState(PotionRefillState.PLAN, this.computeLong2());
               return;
            }

            this.updateStateForInventoryScreen4(inventoryScreen);
            break;
         case CLOSING:

            if (!this.stopwatch.checkCondition(getLongState2(this))) {
               return;
            }

            if (getBooleanState(this)) {
               if (cursorStack.isEmpty()) {
                  MinecraftClientAccess51.getPlayer(mc).closeHandledScreen();
               }
            } else {
               ThreadLocalRandom.current().nextInt(5);
            }

            this.updateState8();
      }
   }

   public static PotionRefillState getTARGET() {
      return PotionRefillState.TARGET;
   }

   public static boolean getBooleanState3(PotRefillModule potRefillModule) {
      return potRefillModule.booleanState3;
   }

   private void updateState4() {
      if (this.booleanState) {
         this.slot3 = null;
         PotionRefillState closing = PotionRefillState.CLOSING;

         Random random2 = getRandom(this);

         this.updateStateForPotionRefillState(closing, 60L + (long)random2.nextInt(50));
      } else {
         this.updateState8();
      }
   }

   public static int getIntState4(PotRefillModule potRefillModule) {
      return potRefillModule.intState4;
   }

   private boolean checkCondition3() {
      int keyCode = getRefillKeySetting(this).getKeyCode();

      if (keyCode != -1) {
         if (keyCode != 0) {
            if (mc.currentScreen != null) {
               if (!(mc.currentScreen instanceof InventoryScreen)) {
                  return false;
               }
            }

            return KeybindUtils.checkCondition2(keyCode);
         }
      }

      return false;
   }

   public static PotionRefillSlotMove getPotionRefillSlotMove(PotRefillModule potRefillModule) {
      return potRefillModule.potionRefillSlotMove;
   }

   @EventHandler
   private void onTickEnd(TickEndEvent tickEndEvent) {
      if (MinecraftClientAccess51.getPlayer(mc) != null) {
         if (mc.interactionManager != null) {
            if (this.potionRefillState == PotionRefillState.SILENT) {
               this.updateState9();
            }
         }
      }
   }

   public static int getIntState5(PotRefillModule potRefillModule) {
      return potRefillModule.intState5;
   }

   public static boolean[] getBooleanArray2(PotRefillModule potRefillModule) {
      return potRefillModule.booleanArray2;
   }

   public static PotionRefillSlotMove getPotionRefillSlotMove2(PotRefillModule potRefillModule) {
      return potRefillModule.potionRefillSlotMove2;
   }

   public static void setCounter(PotRefillModule potRefillModule, int counter2) {
      potRefillModule.counter = counter2;
   }

   private void updateStateForInventoryScreen2(InventoryScreen inventoryScreen) {
      int intValue = 0;

      while (true) {
         ThreadLocalRandom.current().nextInt(7);

         if (intValue >= 4) {
            return;
         }

         PotionRefillState potionRefillState2 = this.potionRefillState;
         this.updateStateForInventoryScreen(inventoryScreen);
         if (getPotionRefillState(this) == potionRefillState2) {
            break;
         }

         if (!this.checkCondition()) {
            break;
         }

         ThreadLocalRandom.current().nextInt(9);
         intValue++;
      }
   }

   public static String getString(PotRefillModule potRefillModule) {
      return potRefillModule.string;
   }

   private void updateState5() {
      if (mc.currentScreen != null) {
         this.updateState7((0L));
      } else if (this.computePotionRefillSlotMoveForIntToDoubleFunction(null) == null) {
         this.updateState8();
      } else if (!mc.player.isUsingItem() && this.stopwatch.checkCondition(this.longState2)) {
         if (this.strictTickPacingSetting.isOn()) {
            HotbarSelectionManager.updateState(this);
         } else {
            ThreadLocalRandom.current().nextInt(8);
         }
      } else {
         HotbarSelectionManager.updateState3(this);
      }
   }

   private static boolean isEmpty(InventoryScreen inventoryScreen) {
      return ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack().isEmpty();
   }

   private static boolean testPotionRefillState(PotionRefillState potionRefillState2) {
      if (potionRefillState2 != PotionRefillState.SOURCE) {
         ThreadLocalRandom.current().nextInt(11);
         if (potionRefillState2 != PotionRefillState.TARGET) {
            if (potionRefillState2 != PotionRefillState.RETURN) {
               return false;
            }
         }
      }

      return true;
   }

   public static void setLongState(PotRefillModule potRefillModule, long longState3) {
      potRefillModule.longState = longState3;
   }

   private void updateStateForPotionRefillState(PotionRefillState potionRefillState2, long longValue) {
      setPotionRefillState(this, potionRefillState2);
      this.longState2 = Math.max(0L, longValue);
      getStopwatch(this).updateTimestampMillis();
   }

   private void updateStateForInventoryScreen3(InventoryScreen inventoryScreen, Slot slot4, boolean booleanValue, BooleanSupplier booleanSupplier) {
      if (booleanValue) {
         double scaledCursorX = SystemInputSimulator.getScaledCursorX(inventoryScreen.width);
         double scaledCursorY = SystemInputSimulator.getScaledCursorY(inventoryScreen.height);

         Click click = new Click(scaledCursorX, scaledCursorY, new MouseInput(0, 0));

         inventoryScreen.mouseClicked(click, false);
         if (MinecraftClientAccess51.getCurrentScreen(mc) == inventoryScreen) {
            inventoryScreen.mouseReleased(click);
         }

         HotbarSelectionManager.updateState6();
         if (booleanSupplier.getAsBoolean()) {
            return;
         }

         ThreadLocalRandom.current().nextInt(7);
      }

      InventoryUtils.updateState5(MinecraftClientAccess51.getId(slot4));
   }

   public static PotionRefillState getIDLE() {
      return PotionRefillState.IDLE;
   }

   private int computeInt() {
      int intValue = 0;
      int intValue2 = 0;

      while (true) {
         if (intValue2 >= 9) {
            return Math.max(1, intValue);
         }

         label39: {
            RefillItemKind refillItemKind = HotbarPatterns.computeRefillItemKind(getHotbarPatternSetting(this).getPatternKey(intValue2));
            if (refillItemKind != RefillItemKind.POTION) {
               if (refillItemKind != RefillItemKind.TOTEM) {
                  break label39;
               }

               ThreadLocalRandom.current().nextInt(16);
            }

            intValue++;
         }

         intValue2++;
      }
   }

   private void updateStateForInventoryScreen4(InventoryScreen inventoryScreen) {
      int intState32;
      label114: {
         intState32 = getIntState3(this);

         if (intState32 < 1) {
            ThreadLocalRandom.current().nextInt(9);

            if (this.counter < 6) {
               intState32 = 0;
               break label114;
            }
         }

         intState32 = 1;
      }

      byte intState322 = (byte)intState32;
      Slot slot32 = this.slot3;
      boolean booleanValue = this.testInventoryScreen2(inventoryScreen, slot32);
      if (this.stopwatch.checkCondition(getLongState2(this))) {
         if (intState322 != 0) {
            if (mc.player.age != getIntState2(this)) {
               if (!HotbarSelectionManager.checkCondition4()) {
                  long longValue = System.currentTimeMillis() - this.timestampMillis;

                  int intValue = longValue >= (1500L) ? 1 : 0;
                  if (!booleanValue && intValue == 0) {
                     return;
                  }

                  if (!this.checkCondition2()) {
                     return;
                  }

                  setIntState2(this, mc.player.age);
                  switch (getPotionRefillState(this)) {
                     case SOURCE:
                        if (getRefillMethodSetting(this).equals("Hotbar Keys")) {
                           label95: {
                              if (booleanValue) {
                                 if (this.testInventoryScreen3(inventoryScreen, slot32, getPotionRefillSlotMove2(this).getHotbar())) {
                                    if (getString(this).equals(HotbarPatternCapture.computeStringForItemStack(this.slot.getStack()))) {
                                       break label95;
                                    }

                                    ThreadLocalRandom.current().nextInt(9);
                                 }
                              }

                              InventoryUtils.updateState2(slot32.id, getPotionRefillSlotMove2(this).getHotbar());
                           }

                           this.updateStateForPotionRefillState(PotionRefillState.PLAN, this.computeLong2());
                        } else {
                           this.updateStateForInventoryScreen3(inventoryScreen, slot32, booleanValue, () -> testInventoryScreen4(inventoryScreen));
                           this.updateStateForPotionRefillState2(PotionRefillState.TARGET, getSlot(this), this.computeLong2());
                        }
                        break;
                     case TARGET:
                        this.updateStateForInventoryScreen3(inventoryScreen, slot32, booleanValue, () -> this.testInventoryScreen(inventoryScreen));
                        if (((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack().isEmpty()) {
                           this.updateStateForPotionRefillState(PotionRefillState.PLAN, this.computeLong2());
                        } else {
                           this.updateStateForPotionRefillState2(PotionRefillState.RETURN, this.slot2, this.computeLong2());
                        }
                        break;
                     case RETURN:

                        this.updateStateForInventoryScreen3(inventoryScreen, slot32, booleanValue, () -> isEmpty(inventoryScreen));
                        this.updateStateForPotionRefillState(PotionRefillState.PLAN, this.computeLong2());
                  }

                  return;
               }
            }
         }
      }
   }

   @Override
   public void onEnable() {
      this.updateState10();

      this.longState = (0L);
      this.booleanState2 = this.checkCondition3();
      super.onEnable();
   }

   public static void setBooleanState3(PotRefillModule potRefillModule, boolean booleanState32) {
      potRefillModule.booleanState3 = booleanState32;
   }

   public static KeybindSetting getRefillKeySetting(PotRefillModule potRefillModule) {
      return potRefillModule.refillKeySetting;
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (this.checkCondition()) {
         Screen currentScreen2 = MinecraftClientAccess51.getCurrentScreen(mc);
         if (currentScreen2 instanceof InventoryScreen) {
            ThreadLocalRandom.current().nextInt(7);

            InventoryScreen currentScreen22 = (InventoryScreen)currentScreen2;
            this.updateStateForInventoryScreen2(currentScreen22);
         }
      }

      if (!testPotionRefillState(this.potionRefillState)) {
         getCursorGlide(this).cancel();

         ThreadLocalRandom.current().nextInt(7);
      }
   }

   private boolean checkCondition4() {
      if (this.autoRefillSetting.isOn() && System.currentTimeMillis() >= getLongState(this)) {
         if (MinecraftClientAccess51.getCurrentScreen(mc) == null) {
            if (!mc.player.isUsingItem()) {
               if (this.hotbarPatternSetting.hasPatterns()) {
                  if (HotbarPatternCapture.computeInt() < getHealingThresholdSetting(this).intValue()) {
                     if (this.computePotionRefillSlotMoveForIntToDoubleFunction(null) != null) {
                        return true;
                     }
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(11);
               }
            }
         }
      }

      return false;
   }

   private void updateStateForPotionRefillState2(PotionRefillState potionRefillState2, Slot slot32, long longValue) {
      setSlot3(this, slot32);
      this.timestampMillis = System.currentTimeMillis();
      this.updateStateForPotionRefillState(potionRefillState2, longValue);
   }

   private boolean equals() {
      return this.modeSetting.equals("Legit");
   }

   public static void setIntState(PotRefillModule potRefillModule, int intState6) {
      potRefillModule.intState = intState6;
   }

   private void updateStateForInventoryScreen5(InventoryScreen inventoryScreen) {
      double scaledCursorX = SystemInputSimulator.getScaledCursorX(inventoryScreen.width);
      double scaledCursorY = SystemInputSimulator.getScaledCursorY(inventoryScreen.height);
      HandledScreenAccessor inventoryScreen2 = (HandledScreenAccessor)inventoryScreen;
      PotionRefillSlotMove potionRefillSlotMove3 = this.computePotionRefillSlotMoveForIntToDoubleFunction(intValue -> computeDoubleForInventoryScreen(inventoryScreen, inventoryScreen2, scaledCursorX, scaledCursorY, intValue));
      if (potionRefillSlotMove3 == null) {
         this.updateState4();
      } else if (this.testPotionRefillSlotMove(potionRefillSlotMove3)) {
         PotionRefillState plan = PotionRefillState.PLAN;

         this.updateStateForPotionRefillState(plan, (0L));
      } else {
         setPotionRefillSlotMove2(this, potionRefillSlotMove3);
         this.slot2 = ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getSlot(InventoryUtils.computeInt2(potionRefillSlotMove3.getSource()));
         setSlot(this, ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getSlot(InventoryUtils.computeInt2(potionRefillSlotMove3.getHotbar())));
         setString(this, HotbarPatternCapture.computeStringForItemStack(getSlot2(this).getStack()));
         PotionRefillState source = PotionRefillState.SOURCE;
         Slot slot22 = this.slot2;

         this.updateStateForPotionRefillState2(source, slot22, (0L));
      }
   }

   private boolean checkCondition5(int intValue) {
      return this.booleanArray2[intValue];
   }

   private boolean testPotionRefillSlotMove(PotionRefillSlotMove potionRefillSlotMove3) {
      this.intState5 = potionRefillSlotMove3.equals(getPotionRefillSlotMove(this)) ? getIntState5(this) + 1 : 0;
      setPotionRefillSlotMove(this, potionRefillSlotMove3);

      if (this.intState5 < 2) {
         ThreadLocalRandom.current().nextInt(15);
         return false;
      } else {
         getBooleanArray2(this)[potionRefillSlotMove3.getHotbar()] = true;
         setPotionRefillSlotMove(this, null);
         setIntState5(this, 0);
         return true;
      }
   }

   public static PotionRefillState getPLAN() {
      return PotionRefillState.PLAN;
   }

   public static void setPotionRefillSlotMove(PotRefillModule potRefillModule, PotionRefillSlotMove potionRefillSlotMove3) {
      potRefillModule.potionRefillSlotMove = potionRefillSlotMove3;
   }

   public static void setPotionRefillState(PotRefillModule potRefillModule, PotionRefillState potionRefillState2) {
      potRefillModule.potionRefillState = potionRefillState2;
   }

   public static HotbarPatternSetting getHotbarPatternSetting(PotRefillModule potRefillModule) {
      return potRefillModule.hotbarPatternSetting;
   }

   @Override
   public void onDisable() {
      this.updateState7((0L));
      super.onDisable();
   }

   private void updateState6() {
      KeyBinding keyBinding = MinecraftClientAccess51.getForwardKey(mc.options);

      keyBinding.setPressed(false);

      mc.options.backKey.setPressed(false);
      MinecraftClientAccess51.getLeftKey(MinecraftClientAccess51.getOptions(mc)).setPressed(false);
      keyBinding = MinecraftClientAccess51.getRightKey(mc.options);

      keyBinding.setPressed(false);
      keyBinding = MinecraftClientAccess51.getJumpKey(MinecraftClientAccess51.getOptions(mc));

      keyBinding.setPressed(false);
      MinecraftClientAccess51.getOptions(mc).sprintKey.setPressed(false);
   }

   private void updateState7(long longValue) {
      if (this.booleanState) {
         if (MinecraftClientAccess51.getPlayer(mc) != null) {
            if (mc.currentScreen instanceof InventoryScreen) {
               MinecraftClientAccess51.getPlayer(mc).closeHandledScreen();
            }
         }
      }

      this.updateState10();
      setLongState(this, System.currentTimeMillis() + longValue);
   }

   private static double computeDoubleForInventoryScreen(InventoryScreen inventoryScreen, HandledScreenAccessor handledScreenAccessor, double doubleValue, double doubleValue2, int intValue) {
      Slot slot4 = ((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getSlot(InventoryUtils.computeInt2(intValue));
      double doubleValue3 = (double)(handledScreenAccessor.getX() + MinecraftClientAccess51.getX(slot4));

      double doubleValue4 = doubleValue3 + (8.0) - doubleValue;
      double doubleValue5 = (double)(handledScreenAccessor.getY() + slot4.y) + 8.0 - doubleValue2;
      return doubleValue4 * doubleValue4 + doubleValue5 * doubleValue5;
   }

   private PotionRefillSlotMove computePotionRefillSlotMoveForIntToDoubleFunction(IntToDoubleFunction intToDoubleFunction) {
      if (mc.player != null) {
         if (this.hotbarPatternSetting.hasPatterns()) {
            ThreadLocalRandom.current().nextInt(13);

            String[] stringArray = HotbarPatternCapture.computeStringArray();

            String[] stringArray2 = new String[9];
            System.arraycopy(stringArray, 0, stringArray2, 0, stringArray2.length);
            return HotbarPatterns.computePotionRefillSlotMoveForIntToDoubleFunction(HotbarPatternCapture.computeStringArrayForHotbarPatternSetting(this.hotbarPatternSetting), stringArray2, stringArray, this.restoreTotemsSetting.isOn(), this.healingFallbackSetting.isOn(), intToDoubleFunction, intValue -> this.checkCondition5(intValue));
         }
      }

      return null;
   }

   public static void setLongState2(PotRefillModule potRefillModule, long longState22) {
      potRefillModule.longState2 = longState22;
   }

   public static Slot getSlot2(PotRefillModule potRefillModule) {
      return potRefillModule.slot2;
   }

   private void updateState8() {
      byte byteValue = 0;
      boolean[] booleanArray = this.booleanArray2;
      int length = booleanArray.length;
      int intValue = 0;

      while (true) {
         if (intValue >= length) {
            this.updateState10();
            long longValue = System.currentTimeMillis();
            long longValue2;
            if (byteValue != 0) {
               longValue2 = (3976743926497718654L);

               longValue2 = 3000L;
            } else {
               longValue2 = 750L;
            }

            setLongState(this, longValue + longValue2);
            return;
         }

         int intValue2 = (booleanArray[intValue]) ? 1 : 0;
         byteValue |= intValue2;
         intValue++;
      }
   }

   public static PotionRefillState getSOURCE() {
      return PotionRefillState.SOURCE;
   }

   private void updateState9() {
      if (mc.currentScreen == null) {
         if (!mc.player.isUsingItem() && this.stopwatch.checkCondition(getLongState2(this))) {
            boolean booleanValue;
            if (this.strictTickPacingSetting.isOn()) {
               if (!HotbarSelectionManager.checkCondition2()) {
                  booleanValue = true;
               } else {
                  booleanValue = false;
               }
            } else {
               booleanValue = HotbarSelectionManager.checkCondition4();
            }

            boolean booleanValue2 = (boolean)booleanValue;
            if (booleanValue2) {
               return;
            }

            PotionRefillSlotMove potionRefillSlotMove3 = this.computePotionRefillSlotMoveForIntToDoubleFunction(null);
            if (potionRefillSlotMove3 != null) {
               if (this.testPotionRefillSlotMove(potionRefillSlotMove3)) {
                  ThreadLocalRandom.current().nextInt(5);

                  potionRefillSlotMove3 = this.computePotionRefillSlotMoveForIntToDoubleFunction(null);
               }
            }

            if (potionRefillSlotMove3 == null) {
               this.updateState8();
               return;
            }

            ThreadLocalRandom.current().nextInt(11);
            if (!this.checkCondition2()) {
               return;
            }

            InventoryUtils.updateState2(InventoryUtils.computeInt2(potionRefillSlotMove3.getSource()), potionRefillSlotMove3.getHotbar());
            this.updateStateForPotionRefillState(PotionRefillState.SILENT, this.computeLong2());
            return;
         }
      }
   }

   public static PotionRefillState getSILENT() {
      return PotionRefillState.SILENT;
   }

   public static DoubleRangeSetting getClickDelayMsSetting(PotRefillModule potRefillModule) {
      return potRefillModule.clickDelayMsSetting;
   }

   public static ChoiceSetting getRefillMethodSetting(PotRefillModule potRefillModule) {
      return potRefillModule.refillMethodSetting;
   }

   public static DoubleSetting getHealingThresholdSetting(PotRefillModule potRefillModule) {
      return potRefillModule.healingThresholdSetting;
   }

   private boolean testInventoryScreen2(InventoryScreen inventoryScreen, Slot slot4) {
      if (slot4 != null && mc.getWindow() != null) {
         if (MinecraftClientAccess51.getPlayer(mc) != null) {
            byte byteValue = 14;
            ThreadLocalRandom.current().nextInt(12);
            if (MinecraftClientAccess51.getPlayer(mc).currentScreenHandler == inventoryScreen.getScreenHandler()) {
               if (((PlayerScreenHandler)inventoryScreen.getScreenHandler()).slots.contains(slot4)) {
                  HandledScreenAccessor inventoryScreen2 = (HandledScreenAccessor)inventoryScreen;
                  double doubleValue = (double)(inventoryScreen2.getX() + MinecraftClientAccess51.getX(slot4));

                  double requestX = doubleValue + (8.0);
                  double requestY = (double)(inventoryScreen2.getY() + MinecraftClientAccess51.getY(slot4)) + 8.0;
                  CursorGlide cursorGlide2 = getCursorGlide(this);
                  int width = inventoryScreen.width;
                  int height = inventoryScreen.height;
                  double value = this.cursorSpeedSetting.getValue();

                  cursorGlide2.glideTo(width, height, requestX, requestY, value, (3.0));
                  double scaledCursorX = SystemInputSimulator.getScaledCursorX(inventoryScreen.width);
                  double scaledCursorY = SystemInputSimulator.getScaledCursorY(inventoryScreen.height);
                  double doubleValue2 = Math.abs(scaledCursorX - requestX);

                  if (!(doubleValue2 > (10.0))) {
                     if (!(Math.abs(scaledCursorY - requestY) > 10.0)) {
                        if (inventoryScreen2.invokeGetSlotAt(scaledCursorX, scaledCursorY) == slot4) {
                           byteValue = 1;
                        } else {
                           byteValue = 0;
                        }

                        return (byteValue != 0);
                     }
                  }

                  return false;
               }
            } else {
               byteValue = 7;
               ThreadLocalRandom.current().nextInt(4);
            }
         }
      }

      getCursorGlide(this).cancel();
      return false;
   }

   public static long getLongState(PotRefillModule potRefillModule) {
      return potRefillModule.longState;
   }

   private Boolean computeBoolean() {
      byte byteValue;
      if (!this.equals()) {
         byteValue = 1;
      } else {
         byteValue = 0;
      }

      ThreadLocalRandom.current().nextInt(7);
      return Boolean.valueOf((byteValue != 0));
   }

   public static void setIntState3(PotRefillModule potRefillModule, int intState32) {
      potRefillModule.intState3 = intState32;
   }

   public static void setIntState2(PotRefillModule potRefillModule, int intState22) {
      potRefillModule.intState2 = intState22;
   }

   private void updateState10() {
      HotbarSelectionManager.updateState3(this);
      getCursorGlide(this).cancel();
      setPotionRefillState(this, PotionRefillState.IDLE);
      setLongState2(this, 0L);
      getStopwatch(this).updateTimestampMillis();
      this.booleanState3 = false;

      this.booleanState = false;
      setPotionRefillSlotMove2(this, null);
      setSlot2(this, null);
      this.slot = null;
      this.slot3 = null;
      this.string = "";

      setIntState4(this, 0);
      this.intState2 = -1;
      Arrays.fill(getBooleanArray2(this), false);
      this.potionRefillSlotMove = null;

      this.intState5 = 0;
   }

   public static int getIntState3(PotRefillModule potRefillModule) {
      return potRefillModule.intState3;
   }

   private boolean testInventoryScreen3(InventoryScreen inventoryScreen, Slot slot4, int intValue) {
      KeyBinding keyBinding = MinecraftClientAccess51.getHotbarKeys(MinecraftClientAccess51.getOptions(mc))[intValue];
      Key boundKey = ((KeyBindingAccessor)keyBinding).getBoundKey();
      if (boundKey != null) {
         if (boundKey.getCategory() != Type.MOUSE && boundKey.getCode() >= 0) {
            int intValue2 = boundKey.getCategory() == Type.KEYSYM ? boundKey.getCode() : -1;
            int code;
            if (boundKey.getCategory() == MinecraftClientAccess51.getSCANCODE()) {
               code = boundKey.getCode();
            } else {
               code = GLFW.glfwGetKeyScancode(intValue2);
            }

            int code2 = code;
            KeyInput keyInput = new KeyInput(intValue2, code2, 0);
            if (keyBinding.matchesKey(keyInput) && intValue2 != 256 && !MinecraftClientAccess51.getInventoryKey(MinecraftClientAccess51.getOptions(mc)).matchesKey(keyInput)) {
               if (!MinecraftClientAccess51.getDropKey(mc.options).matchesKey(keyInput)) {
                  ThreadLocalRandom.current().nextInt(13);
                  if (!MinecraftClientAccess51.getSwapHandsKey(mc.options).matchesKey(keyInput) && !MinecraftClientAccess51.getPickItemKey(MinecraftClientAccess51.getOptions(mc)).matchesKey(keyInput)) {
                     int intValue3 = 0;

                     while (intValue3 < intValue) {
                        if (mc.options.hotbarKeys[intValue3].matchesKey(keyInput)) {
                           return false;
                        }

                        intValue3++;
                     }

                     ((HandledScreenAccessor)inventoryScreen).setFocusedSlot(slot4);
                     inventoryScreen.keyPressed(keyInput);
                     HotbarSelectionManager.updateState6();
                     return true;
                  }
               } else {
                  ThreadLocalRandom.current().nextInt(4);
               }
            }

            return false;
         }
      }

      return false;
   }

   public PotRefillModule() {
      super("Pot Refill", "Refills potions and totems into your imported hotbar pattern", ModuleCategory.PLAYER);

      String[] stringArray = new String[2];

      stringArray[0] = "Legit";

      stringArray[1] = "Silent";
      this.modeSetting = new ChoiceSetting("Mode", "Legit", stringArray);

      this.refillMethodSetting = new ChoiceSetting("Refill Method", "Hotbar Keys", "Hotbar Keys", "Pickup");

      this.cursorSpeedSetting = new DoubleSetting("Cursor Speed", 1.0, 100.0, (75.0), 1.0);

      this.clickDelayMsSetting = new DoubleRangeSetting("Click Delay (ms)", (0.0), (400.0), (5.0), 25.0, 1.0);
      this.strictTickPacingSetting = new BooleanSetting("Strict Tick Pacing", true);
      this.restoreTotemsSetting = new BooleanSetting("Restore Totems", true);
      this.healingFallbackSetting = new BooleanSetting("Healing Fallback", true);
      this.autoRefillSetting = new BooleanSetting("Auto Refill", true);

      this.healingThresholdSetting = new DoubleSetting("Healing Threshold", (1.0), 9.0, (3.0), (1.0));

      this.refillKeySetting = new KeybindSetting("Refill Key", -1, false);
      this.random = new Random();
      this.cursorGlide = new CursorGlide();
      this.stopwatch = new Stopwatch();
      this.potionRefillState = PotionRefillState.IDLE;
      this.string = "";
      this.intState2 = -1;

      this.booleanArray2 = new boolean[9];
      Setting[] settingArray = new Setting[]{this.hotbarPatternSetting, null, null, null, null, null, null, null, null, null, null};

      settingArray[1] = this.modeSetting;

      settingArray[2] = this.refillMethodSetting;
      settingArray[3] = this.cursorSpeedSetting;

      settingArray[4] = this.clickDelayMsSetting;

      settingArray[5] = this.strictTickPacingSetting;

      settingArray[6] = this.restoreTotemsSetting;
      settingArray[7] = this.healingFallbackSetting;
      settingArray[8] = this.autoRefillSetting;

      settingArray[9] = this.healingThresholdSetting;
      settingArray[10] = this.refillKeySetting;
      this.addSettings(settingArray);
      this.refillMethodSetting.setVisibility(() -> this.equals());
      this.cursorSpeedSetting.setVisibility(() -> this.equals());
      this.strictTickPacingSetting.setVisibility(() -> this.computeBoolean());
      this.healingThresholdSetting.setVisibility(() -> this.autoRefillSetting.isOn());
      this.hotbarPatternSetting.setTotemImportCondition(() -> this.restoreTotemsSetting.isOn());
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      this.updateState10();
   }

   private long computeLong2() {
      double lowerValue2 = getClickDelayMsSetting(this).getLowerValue2();
      double upperValue3 = getClickDelayMsSetting(this).getUpperValue3();
      double doubleValue = this.random.nextDouble();

      return Math.round(lowerValue2 + doubleValue * Math.max((0.0), upperValue3 - lowerValue2));
   }

   private static boolean testInventoryScreen4(InventoryScreen inventoryScreen) {
      byte byteValue;
      if (!((PlayerScreenHandler)inventoryScreen.getScreenHandler()).getCursorStack().isEmpty()) {
         byteValue = 1;

         ThreadLocalRandom.current().nextInt(6);
      } else {
         byteValue = 0;
      }

      return (byteValue != 0);
   }

   public static Slot getSlot(PotRefillModule potRefillModule) {
      return potRefillModule.slot;
   }

}
