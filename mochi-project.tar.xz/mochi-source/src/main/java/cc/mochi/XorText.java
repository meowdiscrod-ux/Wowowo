package cc.mochi;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public final class XorText implements CharSequence {
   private final char[] encoded;

   private final char[] key;

   public static XorText fromString(String string) {
      return new XorText(string);
   }

   public boolean contentEquals(CharSequence charSequence) {
      if (charSequence != null) {
         if (charSequence.length() == getEncoded(this).length) {
            int intValue = 0;

            while (true) {
               if (intValue >= getEncoded(this).length) {
                  return true;
               }

               ThreadLocalRandom.current().nextInt(7);
               if (this.charAt(intValue) != charSequence.charAt(intValue)) {
                  return false;
               }

               intValue++;
            }
         }
      }

      return false;
   }

   @Override
   public int length() {
      return this.encoded.length;
   }

   public static char[] getEncoded(XorText xorText) {
      return xorText.encoded;
   }

   @Override
   public int hashCode() {
      int intValue = 0;
      int intValue2 = 0;

      ThreadLocalRandom.current().nextInt(15);

      while (intValue2 < getEncoded(this).length) {
         intValue = 31 * intValue + this.charAt(intValue2);
         intValue2++;
      }

      ThreadLocalRandom.current().nextInt(3);
      return intValue;
   }

   public static char[] getKey(XorText xorText) {
      return xorText.key;
   }

   @Override
   public CharSequence subSequence(int intValue, int intValue2) {
      int intValue3 = intValue2 - intValue;
      char[] charArray = new char[intValue3];
      char[] charArray2 = new char[intValue3];
      System.arraycopy(getEncoded(this), intValue, charArray, 0, intValue3);
      int intValue4 = 0;

      while (intValue4 < intValue3) {
         charArray2[intValue4] = this.key[(intValue + intValue4) % getKey(this).length];
         intValue4++;
      }

      return new XorText(charArray, charArray2, true);
   }

   public char[] copyDecodedTo(char[] charArray, int intValue) {
      ThreadLocalRandom.current().nextInt(17);
      int intValue2 = 0;

      while (intValue2 < this.encoded.length) {
         ThreadLocalRandom.current().nextInt(6);

         int intValue3 = intValue + intValue2;
         char charValue = getEncoded(this)[intValue2];
         char charValue2 = getKey(this)[intValue2 % this.key.length];
         charArray[intValue3] = (char)((charValue | charValue2) - (charValue & charValue2));
         intValue2++;
      }

      ThreadLocalRandom.current().nextInt(15);
      return charArray;
   }

   private static void xorInPlace(char[] charArray, char[] charArray2, int intValue, int intValue2) {
      int intValue3 = intValue;

      while (intValue3 < intValue + intValue2) {
         ThreadLocalRandom.current().nextInt(7);
         charArray[intValue3] = (char)(charArray[intValue3] & ~charArray2[intValue3 % charArray2.length] | charArray2[intValue3 % charArray2.length] & ~charArray[intValue3]);
         intValue3++;

         ThreadLocalRandom.current().nextInt(11);
      }
   }

   @Override
   public char charAt(int intValue) {
      return (char)(this.encoded[intValue] ^ getKey(this)[intValue % this.key.length]);
   }

   @Override
   public boolean isEmpty() {
      byte byteValue;
      if (getEncoded(this).length == 0) {
         byteValue = 1;
      } else {
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(16);
      }

      return (byteValue != 0);
   }

   public XorText(String string) {
      int intValue = string.length();
      char[] key2 = new char[Math.min(Math.max(intValue, 1), 64)];
      ThreadLocalRandom threadLocalRandom = ThreadLocalRandom.current();

      for (int intValue2 = 0; intValue2 < key2.length; intValue2++) {
         key2[intValue2] = (char)threadLocalRandom.nextInt(65535);
      }

      char[] encoded2 = string.toCharArray();
      xorInPlace(encoded2, key2, 0, encoded2.length);
      this.key = key2;
      this.encoded = encoded2;
   }

   public static XorText fromEncoded(char[] charArray, char[] charArray2) {
      return new XorText(charArray, charArray2, true);
   }

   @Override
   public boolean equals(Object objectValue) {
      if (this == objectValue) {
         return true;
      } else {
         if (objectValue instanceof CharSequence) {
            CharSequence charSequence = (CharSequence)objectValue;
            if (this.contentEquals(charSequence)) {
               ThreadLocalRandom.current().nextInt(8);
               return true;
            }
         }

         return false;
      }
   }

   private XorText(char[] encoded2, char[] charArray, boolean booleanValue) {
      this.encoded = encoded2;
      char[] key2;
      if (charArray.length == 0) {
         key2 = new char[1];

         key2[0] = 0;
      } else {
         key2 = charArray;
      }

      this.key = key2;
   }

   @Override
   public String toString() {
      char[] charArray = Arrays.copyOf(this.encoded, getEncoded(this).length);
      xorInPlace(charArray, this.key, 0, charArray.length);
      return new String(charArray);
   }
   public static XorText fromLiteral(String text, char[] key) {
      char[] encoded = text.toCharArray();
      for (int i = 0; i < encoded.length; i++) {
         encoded[i] = (char)(encoded[i] ^ (key.length == 0 ? 0 : key[i % key.length]));
      }
      return new XorText(encoded, key, true);
   }
}
