package cc.mochi;

import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class Render3D {
   private static final Logger logger = NOPLogger.NOP_LOGGER;
   private static final WorldRenderBatch worldRenderBatch = new WorldRenderBatch(WorldRenderLayers.renderLayer3, DrawMode.TRIANGLES, false);

   private static double x;

   private static final WorldRenderBatch worldRenderBatch2 = new WorldRenderBatch(WorldRenderLayers.renderLayer, DrawMode.TRIANGLES, false);
   private static final WorldRenderBatch worldRenderBatch3 = new WorldRenderBatch(WorldRenderLayers.renderLayer4, DrawMode.LINES, true);
   private static final WorldRenderBatch worldRenderBatch4 = new WorldRenderBatch(WorldRenderLayers.renderLayer2, DrawMode.LINES, true);
   private static final Matrix4f matrix4f = new Matrix4f();

   private static final Vector3f vector3f = new Vector3f();

   private static float floatState;

   private static final Vector3f vector3f2 = new Vector3f();

   private static double z;
   private static boolean booleanState;
   private static final double doubleState = Math.PI * 2;
   private static boolean booleanState2;

   private static double y;

   public static void updateState(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, float floatValue, int intValue, int intValue2, boolean booleanValue) {
      int intValue3 = Math.max(3, intValue2);
      double doubleValue82 = doubleValue + doubleValue4;
      double doubleValue6 = doubleValue3;

      for (int intValue4 = 1; intValue4 <= intValue3; intValue4++) {
         double doubleValue7 = (Math.PI * 2) * (double)intValue4 / (double)intValue3;
         double doubleValue8 = doubleValue + Math.cos(doubleValue7) * doubleValue4;
         double doubleValue9 = doubleValue3 + Math.sin(doubleValue7) * doubleValue4;
         updateState9(doubleValue82, doubleValue2, doubleValue6, doubleValue8, doubleValue2, doubleValue9, floatValue, intValue, booleanValue);
         doubleValue82 = doubleValue8;
         doubleValue6 = doubleValue9;
      }
   }

   public static void updateState2(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5, double doubleValue6, int intValue, int intValue2, boolean booleanValue) {
      int intValue3 = intValue & 16777215;
      double doubleValue7 = Math.max(0.0, doubleValue4 - doubleValue5 * 0.5);
      double doubleValue8 = doubleValue4 + doubleValue5 * 0.5;
      updateState4(doubleValue, doubleValue2, doubleValue3, doubleValue7, doubleValue8, intValue, intValue, intValue2, booleanValue);
      if (doubleValue6 > 0.0) {
         int intValue4 = computeInt(intValue, 0.45F);
         updateState4(doubleValue, doubleValue2, doubleValue3, Math.max(0.0, doubleValue7 - doubleValue6), doubleValue7, intValue3, intValue4, intValue2, booleanValue);
         updateState4(doubleValue, doubleValue2, doubleValue3, doubleValue8, doubleValue8 + doubleValue6, intValue4, intValue3, intValue2, booleanValue);
      }
   }

   public static Matrix4fc getMatrix4f() {
      return matrix4f;
   }

   public static float getFloatState() {
      return floatState;
   }

   public static void updateState3(
      double doubleValue,
      double doubleValue2,
      double doubleValue3,
      int intValue,
      double doubleValue4,
      double doubleValue5,
      double doubleValue6,
      int intValue2,
      double doubleValue7,
      double doubleValue8,
      double doubleValue9,
      int intValue3,
      double doubleValue10,
      double doubleValue11,
      double doubleValue12,
      int intValue4,
      boolean booleanValue
   ) {
      updateState10(doubleValue, doubleValue2, doubleValue3, intValue, doubleValue4, doubleValue5, doubleValue6, intValue2, doubleValue7, doubleValue8, doubleValue9, intValue3, booleanValue);
      updateState10(doubleValue7, doubleValue8, doubleValue9, intValue3, doubleValue10, doubleValue11, doubleValue12, intValue4, doubleValue, doubleValue2, doubleValue3, intValue, booleanValue);
   }

   public static void updateState4(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5, int intValue, int intValue2, int intValue3, boolean booleanValue) {
      int intValue4 = Math.max(3, intValue3);
      double doubleValue92 = 1.0;
      double doubleValue102 = 0.0;

      for (int intValue5 = 1; intValue5 <= intValue4; intValue5++) {
         double doubleValue8 = (Math.PI * 2) * (double)intValue5 / (double)intValue4;
         double doubleValue9 = Math.cos(doubleValue8);
         double doubleValue10 = Math.sin(doubleValue8);
         updateState3(
            doubleValue + doubleValue92 * doubleValue4,
            doubleValue2,
            doubleValue3 + doubleValue102 * doubleValue4,
            intValue,
            doubleValue + doubleValue92 * doubleValue5,
            doubleValue2,
            doubleValue3 + doubleValue102 * doubleValue5,
            intValue2,
            doubleValue + doubleValue9 * doubleValue5,
            doubleValue2,
            doubleValue3 + doubleValue10 * doubleValue5,
            intValue2,
            doubleValue + doubleValue9 * doubleValue4,
            doubleValue2,
            doubleValue3 + doubleValue10 * doubleValue4,
            intValue,
            booleanValue
         );
         doubleValue92 = doubleValue9;
         doubleValue102 = doubleValue10;
      }
   }

   public static void updateStateForVec3d(Vec3d vec3d, Vec3d vec3d2, double doubleValue, double doubleValue2, int intValue, int intValue2, int intValue3, boolean booleanValue) {
      Vec3d vec3d3 = vec3d2.lengthSquared() < 1.0E-9 ? new Vec3d(0.0, 1.0, 0.0) : vec3d2.normalize();
      Vec3d vec3d4 = Math.abs(vec3d3.y) < 0.9 ? new Vec3d(0.0, 1.0, 0.0) : new Vec3d(1.0, 0.0, 0.0);
      Vec3d vec3d5 = vec3d3.crossProduct(vec3d4).normalize();
      Vec3d vec3d6 = vec3d3.crossProduct(vec3d5);
      int intValue4 = Math.max(3, intValue3);
      double doubleValue62 = 1.0;
      double doubleValue72 = 0.0;

      for (int intValue5 = 1; intValue5 <= intValue4; intValue5++) {
         double doubleValue5 = (Math.PI * 2) * (double)intValue5 / (double)intValue4;
         double doubleValue6 = Math.cos(doubleValue5);
         double doubleValue7 = Math.sin(doubleValue5);
         updateState3(
            vec3d.x + (vec3d5.x * doubleValue62 + vec3d6.x * doubleValue72) * doubleValue,
            vec3d.y + (vec3d5.y * doubleValue62 + vec3d6.y * doubleValue72) * doubleValue,
            vec3d.z + (vec3d5.z * doubleValue62 + vec3d6.z * doubleValue72) * doubleValue,
            intValue,
            vec3d.x + (vec3d5.x * doubleValue62 + vec3d6.x * doubleValue72) * doubleValue2,
            vec3d.y + (vec3d5.y * doubleValue62 + vec3d6.y * doubleValue72) * doubleValue2,
            vec3d.z + (vec3d5.z * doubleValue62 + vec3d6.z * doubleValue72) * doubleValue2,
            intValue2,
            vec3d.x + (vec3d5.x * doubleValue6 + vec3d6.x * doubleValue7) * doubleValue2,
            vec3d.y + (vec3d5.y * doubleValue6 + vec3d6.y * doubleValue7) * doubleValue2,
            vec3d.z + (vec3d5.z * doubleValue6 + vec3d6.z * doubleValue7) * doubleValue2,
            intValue2,
            vec3d.x + (vec3d5.x * doubleValue6 + vec3d6.x * doubleValue7) * doubleValue,
            vec3d.y + (vec3d5.y * doubleValue6 + vec3d6.y * doubleValue7) * doubleValue,
            vec3d.z + (vec3d5.z * doubleValue6 + vec3d6.z * doubleValue7) * doubleValue,
            intValue,
            booleanValue
         );
         doubleValue62 = doubleValue6;
         doubleValue72 = doubleValue7;
      }
   }

   public static int computeInt(int intValue, float floatValue) {
      int intValue2 = Math.round((float)(intValue >>> 24) * Math.max(0.0F, Math.min(1.0F, floatValue)));
      return intValue2 << 24 | intValue & 16777215;
   }

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static void updateStateForVec3d2(Vec3d vec3d, float floatState2) {
      x = vec3d.x;
      y = vec3d.y;
      z = vec3d.z;
      floatState = floatState2;
      booleanState = true;
   }

   private Render3D() {
   }

   public static void updateStateForBox(Box box, float floatValue, int intValue, boolean booleanValue) {
      double minX = box.minX;
      double minY = box.minY;
      double minZ = box.minZ;
      double maxX = box.maxX;
      double maxY = box.maxY;
      double maxZ = box.maxZ;
      updateState9(minX, minY, minZ, maxX, minY, minZ, floatValue, intValue, booleanValue);
      updateState9(maxX, minY, minZ, maxX, minY, maxZ, floatValue, intValue, booleanValue);
      updateState9(maxX, minY, maxZ, minX, minY, maxZ, floatValue, intValue, booleanValue);
      updateState9(minX, minY, maxZ, minX, minY, minZ, floatValue, intValue, booleanValue);
      updateState9(minX, maxY, minZ, maxX, maxY, minZ, floatValue, intValue, booleanValue);
      updateState9(maxX, maxY, minZ, maxX, maxY, maxZ, floatValue, intValue, booleanValue);
      updateState9(maxX, maxY, maxZ, minX, maxY, maxZ, floatValue, intValue, booleanValue);
      updateState9(minX, maxY, maxZ, minX, maxY, minZ, floatValue, intValue, booleanValue);
      updateState9(minX, minY, minZ, minX, maxY, minZ, floatValue, intValue, booleanValue);
      updateState9(maxX, minY, minZ, maxX, maxY, minZ, floatValue, intValue, booleanValue);
      updateState9(maxX, minY, maxZ, maxX, maxY, maxZ, floatValue, intValue, booleanValue);
      updateState9(minX, minY, maxZ, minX, maxY, maxZ, floatValue, intValue, booleanValue);
   }

   public static void updateState5(double[] doubleArray, float floatValue, int intValue, boolean booleanValue) {
      if (doubleArray != null) {
         for (int vertexOffset = 0; vertexOffset + 5 < doubleArray.length; vertexOffset += 3) {
            updateState9(doubleArray[vertexOffset], doubleArray[vertexOffset + 1], doubleArray[vertexOffset + 2], doubleArray[vertexOffset + 3], doubleArray[vertexOffset + 4], doubleArray[vertexOffset + 5], floatValue, intValue, booleanValue);
         }
      }
   }

   public static void updateState6(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, float floatValue, int intValue, int intValue2, boolean booleanValue) {
      if (booleanState && checkCondition()) {
         int intValue3 = Math.max(3, intValue2);
         double doubleValue112 = doubleValue + (double)vector3f.x * doubleValue4;
         double doubleValue122 = doubleValue2 + (double)vector3f.y * doubleValue4;
         double doubleValue132 = doubleValue3 + (double)vector3f.z * doubleValue4;

         for (int intValue4 = 1; intValue4 <= intValue3; intValue4++) {
            double doubleValue8 = (Math.PI * 2) * (double)intValue4 / (double)intValue3;
            double doubleValue9 = Math.cos(doubleValue8) * doubleValue4;
            double doubleValue10 = Math.sin(doubleValue8) * doubleValue4;
            double doubleValue11 = doubleValue + (double)vector3f.x * doubleValue9 + (double)vector3f2.x * doubleValue10;
            double doubleValue12 = doubleValue2 + (double)vector3f.y * doubleValue9 + (double)vector3f2.y * doubleValue10;
            double doubleValue13 = doubleValue3 + (double)vector3f.z * doubleValue9 + (double)vector3f2.z * doubleValue10;
            updateState9(doubleValue112, doubleValue122, doubleValue132, doubleValue11, doubleValue12, doubleValue13, floatValue, intValue, booleanValue);
            doubleValue112 = doubleValue11;
            doubleValue122 = doubleValue12;
            doubleValue132 = doubleValue13;
         }
      }
   }

   public static void updateState7(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5, int intValue, int intValue2, int intValue3, boolean booleanValue) {
      int intValue4 = Math.max(3, intValue3);
      double doubleValue92 = doubleValue + doubleValue4;
      double doubleValue7 = doubleValue3;

      for (int intValue5 = 1; intValue5 <= intValue4; intValue5++) {
         double doubleValue8 = (Math.PI * 2) * (double)intValue5 / (double)intValue4;
         double doubleValue9 = doubleValue + Math.cos(doubleValue8) * doubleValue4;
         double doubleValue10 = doubleValue3 + Math.sin(doubleValue8) * doubleValue4;
         updateState3(doubleValue92, doubleValue2, doubleValue7, intValue, doubleValue9, doubleValue2, doubleValue10, intValue, doubleValue9, doubleValue2 + doubleValue5, doubleValue10, intValue2, doubleValue92, doubleValue2 + doubleValue5, doubleValue7, intValue2, booleanValue);
         doubleValue92 = doubleValue9;
         doubleValue7 = doubleValue10;
      }
   }

   public static float computeFloat(float floatValue) {
      return floatValue * UiViewport.getScale();
   }

   public static void updateState8(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, int intValue, int intValue2, boolean booleanValue) {
      if (booleanState && checkCondition()) {
         double doubleValue112 = doubleValue + (double)vector3f.x * doubleValue4;
         double doubleValue122 = doubleValue2 + (double)vector3f.y * doubleValue4;
         double doubleValue132 = doubleValue3 + (double)vector3f.z * doubleValue4;

         for (int intValue3 = 1; intValue3 <= 12; intValue3++) {
            double doubleValue8 = (Math.PI * 2) * (double)intValue3 / 12.0;
            double doubleValue9 = Math.cos(doubleValue8) * doubleValue4;
            double doubleValue10 = Math.sin(doubleValue8) * doubleValue4;
            double doubleValue11 = doubleValue + (double)vector3f.x * doubleValue9 + (double)vector3f2.x * doubleValue10;
            double doubleValue12 = doubleValue2 + (double)vector3f.y * doubleValue9 + (double)vector3f2.y * doubleValue10;
            double doubleValue13 = doubleValue3 + (double)vector3f.z * doubleValue9 + (double)vector3f2.z * doubleValue10;
            updateState10(doubleValue, doubleValue2, doubleValue3, intValue, doubleValue112, doubleValue122, doubleValue132, intValue2, doubleValue11, doubleValue12, doubleValue13, intValue2, booleanValue);
            doubleValue112 = doubleValue11;
            doubleValue122 = doubleValue12;
            doubleValue132 = doubleValue13;
         }
      }
   }

   public static void updateStateForBox2(Box box, int intValue, boolean booleanValue) {
      double minX = box.minX;
      double minY = box.minY;
      double minZ = box.minZ;
      double maxX = box.maxX;
      double maxY = box.maxY;
      double maxZ = box.maxZ;
      updateState3(minX, minY, minZ, intValue, maxX, minY, minZ, intValue, maxX, minY, maxZ, intValue, minX, minY, maxZ, intValue, booleanValue);
      updateState3(minX, maxY, minZ, intValue, maxX, maxY, minZ, intValue, maxX, maxY, maxZ, intValue, minX, maxY, maxZ, intValue, booleanValue);
      updateState3(minX, minY, minZ, intValue, maxX, minY, minZ, intValue, maxX, maxY, minZ, intValue, minX, maxY, minZ, intValue, booleanValue);
      updateState3(minX, minY, maxZ, intValue, maxX, minY, maxZ, intValue, maxX, maxY, maxZ, intValue, minX, maxY, maxZ, intValue, booleanValue);
      updateState3(minX, minY, minZ, intValue, minX, minY, maxZ, intValue, minX, maxY, maxZ, intValue, minX, maxY, minZ, intValue, booleanValue);
      updateState3(maxX, minY, minZ, intValue, maxX, minY, maxZ, intValue, maxX, maxY, maxZ, intValue, maxX, maxY, minZ, intValue, booleanValue);
   }

   public static void updateState9(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5, double doubleValue6, float floatValue, int intValue, boolean booleanValue) {
      if (booleanState && intValue >>> 24 != 0) {
         BufferBuilder bufferBuilder = (booleanValue ? worldRenderBatch4 : worldRenderBatch3).computeBufferBuilder();
         float floatValue2 = (float)(doubleValue - x);
         float floatValue3 = (float)(doubleValue2 - y);
         float floatValue4 = (float)(doubleValue3 - z);
         float floatValue5 = (float)(doubleValue4 - x);
         float floatValue6 = (float)(doubleValue5 - y);
         float floatValue7 = (float)(doubleValue6 - z);
         float floatValue8 = floatValue5 - floatValue2;
         float floatValue9 = floatValue6 - floatValue3;
         float floatValue10 = floatValue7 - floatValue4;
         float floatValue11 = (float)Math.sqrt((double)(floatValue8 * floatValue8 + floatValue9 * floatValue9 + floatValue10 * floatValue10));
         if (!(floatValue11 < 1.0E-6F)) {
            floatValue8 /= floatValue11;
            floatValue9 /= floatValue11;
            floatValue10 /= floatValue11;
            bufferBuilder.vertex(floatValue2, floatValue3, floatValue4).color(intValue).normal(floatValue8, floatValue9, floatValue10).lineWidth(floatValue);
            bufferBuilder.vertex(floatValue5, floatValue6, floatValue7).color(intValue).normal(floatValue8, floatValue9, floatValue10).lineWidth(floatValue);
         }
      }
   }

   public static void updateState10(
      double doubleValue,
      double doubleValue2,
      double doubleValue3,
      int intValue,
      double doubleValue4,
      double doubleValue5,
      double doubleValue6,
      int intValue2,
      double doubleValue7,
      double doubleValue8,
      double doubleValue9,
      int intValue3,
      boolean booleanValue
   ) {
      if (booleanState && (intValue | intValue2 | intValue3) >>> 24 != 0) {
         BufferBuilder bufferBuilder = (booleanValue ? worldRenderBatch2 : worldRenderBatch).computeBufferBuilder();
         bufferBuilder.vertex((float)(doubleValue - x), (float)(doubleValue2 - y), (float)(doubleValue3 - z)).color(intValue);
         bufferBuilder.vertex((float)(doubleValue4 - x), (float)(doubleValue5 - y), (float)(doubleValue6 - z)).color(intValue2);
         bufferBuilder.vertex((float)(doubleValue7 - x), (float)(doubleValue8 - y), (float)(doubleValue9 - z)).color(intValue3);
      }
   }

   public static void updateState11() {
      if (booleanState) {
         booleanState = false;

         try {
            worldRenderBatch.updateState2();
            worldRenderBatch3.updateState2();
            worldRenderBatch2.updateState2();
            worldRenderBatch4.updateState2();
         } catch (RuntimeException failure) {
            worldRenderBatch.updateState();
            worldRenderBatch3.updateState();
            worldRenderBatch2.updateState();
            worldRenderBatch4.updateState();
            if (!booleanState2) {
               booleanState2 = true;
               logger.error("World-space rendering failed; this frame's 3D visuals were dropped", failure);
            }
         }
      }
   }

   public static void mul(Matrix4fc matrix4fc, Matrix4fc matrix4fc2) {
      matrix4fc2.mul(matrix4fc, matrix4f);
   }

   private static boolean checkCondition() {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.gameRenderer != null) {
         Quaternionf rotation = minecraftClient.gameRenderer.getCamera().getRotation();
         rotation.transform(1.0F, 0.0F, 0.0F, vector3f);
         rotation.transform(0.0F, 1.0F, 0.0F, vector3f2);
         return true;
      } else {
         return false;
      }
   }

   public static Vec3d createVec3d() {
      return new Vec3d(x, y, z);
   }

   public static int computeInt2(int intValue, int intValue2) {
      return Math.max(0, Math.min(255, intValue2)) << 24 | intValue & 16777215;
   }
}
