package cc.mochi;

import cc.mochi.module.events.MouseModuleHandler;
import cc.mochi.utils.keybinding.simulation.SimulatedClicks;
import cc.mochi.utils.platform.PlatformService;
import io.github.racoondog.norbit.EventBus;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import meteordevelopment.orbit.IEventBus;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.helpers.NOPLogger;

public final class MochiClient implements ClientModInitializer {
   private final Logger logger = NOPLogger.NOP_LOGGER;
   public static MinecraftClient mc;
   public static final String CLIENT_VERSION = "v1.0";
   public final IEventBus MochiEventBus;
   public final ProfileManager profileManager;
   public final ModuleManager moduleManager;
   public static final boolean shouldUseMouseEvent = System.getProperty("os.name").toLowerCase().contains("windows");
   public final ConfigManager configManager;
   public final FontManager fontManager;
   public static MochiClient INSTANCE;
   public final MouseModuleHandler mouseModuleHandler;
   public final NotificationManager notificationManager;

   public Logger getLogger() {
      return this.logger;
   }

   public static void cleanupRenderers() {
      try {
         OutlinesModule.updateState();
      } catch (Throwable failure) {
      }

      try {
         try {
            if (RenderBackendManager.getINSTANCE().checkCondition2()) {
               HudBlurRenderer.updateState();
               GlassPanelRenderer.updateState8();
               CamouflageRenderer.updateState5();
            }
         } finally {
            RenderBackendManager.getINSTANCE().updateState2();
         }
      } catch (Throwable failure2) {
      }
   }

   private static Path configDir() {
      Path path = mc != null && mc.runDirectory != null ? mc.runDirectory.toPath() : Path.of(".");
      return path.resolve("config").resolve("mochi");
   }

   public ProfileManager getProfileManager() {
      return this.profileManager;
   }

   private static void callback$onInitializeClient$2(MinecraftClient minecraftClient) {
      cleanupRenderers();
   }

   public FontManager getFontManager() {
      return this.fontManager;
   }

   public ModuleManager getModuleManager() {
      return this.moduleManager;
   }

   public MochiClient() {
      INSTANCE = this;
      mc = MinecraftClient.getInstance();
      PlatformService.platform();
      this.MochiEventBus = EventBus.threadSafe();
      this.MochiEventBus.registerLambdaFactory("cc.mochi", (method, objectValue) -> callback$new$0(method, objectValue));
      this.moduleManager = new ModuleManager();
      this.fontManager = new FontManager();
      this.profileManager = new ProfileManager();
      this.configManager = new ConfigManager();
      this.mouseModuleHandler = new MouseModuleHandler();
      this.notificationManager = NotificationManager.getINSTANCE();
      this.MochiEventBus.subscribe(this.mouseModuleHandler);
      this.MochiEventBus.subscribe(this.notificationManager);
      this.MochiEventBus.subscribe(SimulatedClicks.get());
      this.MochiEventBus.subscribe(EntityDamageTracker.getINSTANCE());
      this.MochiEventBus.subscribe(ActionSchedulers.getINSTANCE());
      this.MochiEventBus.subscribe(CombatTickBudget.getINSTANCE42());
      new Thread(() -> callback$new$1()).start();
   }

   public MouseModuleHandler getMouseModuleHandler() {
      return this.mouseModuleHandler;
   }

   public IEventBus getMochiEventBus() {
      return this.MochiEventBus;
   }

   private static Lookup callback$new$0(Method method, Class objectValue) throws InvocationTargetException, IllegalAccessException {
      return (Lookup)method.invoke(null, objectValue, MethodHandles.lookup());
   }

   private static void callback$new$1() {
      try {
         ModMenuIntegration.removeFromHiddenMods();
         Thread.sleep(1000L);
         ModMenuIntegration.removeFromHiddenMods();
      } catch (InterruptedException failure) {
         Thread.currentThread().interrupt();
      }
   }

   public void onInitializeClient() {
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)minecraftClient -> callback$onInitializeClient$2(minecraftClient));
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public NotificationManager getNotificationManager() {
      return this.notificationManager;
   }
}
