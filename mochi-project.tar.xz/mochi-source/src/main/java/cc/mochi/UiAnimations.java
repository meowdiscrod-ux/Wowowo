package cc.mochi;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public final class UiAnimations {
   private float deltaSeconds;
   private final Map<String, UiAnimationState> statesById = new HashMap<>();

   private long frameIndex;

   private boolean reducedMotion;

   public boolean isReducedMotion() {
      return isReducedMotion(this);
   }

   public static boolean isReducedMotion(UiAnimations uiAnimations) {
      return uiAnimations.reducedMotion;
   }

   public static float getVelocity(UiAnimationState uiAnimationState) {
      return uiAnimationState.velocity;
   }

   public static float getDeltaSeconds(UiAnimations uiAnimations) {
      return uiAnimations.deltaSeconds;
   }

   private static boolean startsWith(String string, String string2) {
      return string2.startsWith(string);
   }

   public UiAnimations() {
      this.deltaSeconds = 0.016666668F;
   }

   public static void setVelocity(UiAnimationState uiAnimationState, float velocity) {
      uiAnimationState.velocity = velocity;
   }

   public static void setReducedMotion(UiAnimations uiAnimations, boolean reducedMotion2) {
      uiAnimations.reducedMotion = reducedMotion2;
   }

   public static Map<String, UiAnimationState> getStatesById(UiAnimations uiAnimations) {
      return uiAnimations.statesById;
   }

   public void removeByPrefix(String string) {
      getStatesById(this).keySet().removeIf(string2 -> startsWith(string, string2));
   }

   public static void setFrameIndex(UiAnimations uiAnimations, long frameIndex2) {
      uiAnimations.frameIndex = frameIndex2;
   }

   public static long getLastAccessFrame(UiAnimationState uiAnimationState) {
      return uiAnimationState.lastAccessFrame;
   }

   int size() {
      return getStatesById(this).size();
   }

   public float spring(String string, float initialValue, float targetValue, float periodSeconds, float dampingRatio) {
      UiAnimationState uiAnimationState = this.getOrCreateState(string, initialValue);
      if (this.reducedMotion) {
         uiAnimationState.value = targetValue;
         setVelocity(uiAnimationState, 0.0F);
         return targetValue;
      } else {
         float floatValue = (float)((Math.PI * 2) / (double)Math.max(0.02F, periodSeconds));
         float floatValue2 = floatValue * floatValue;
         float floatValue3 = 2.0F * dampingRatio * floatValue;
         float deltaSeconds2 = getDeltaSeconds(this);

         while (deltaSeconds2 > 1.0E-6F) {
            float floatValue4 = Math.min(0.004166667F, deltaSeconds2);
            float floatValue5 = (targetValue - uiAnimationState.value) * floatValue2 - getVelocity(uiAnimationState) * floatValue3;
            setVelocity(uiAnimationState, getVelocity(uiAnimationState) + floatValue5 * floatValue4);
            uiAnimationState.value = uiAnimationState.value + getVelocity(uiAnimationState) * floatValue4;
            deltaSeconds2 -= floatValue4;
         }

         if (Math.abs(targetValue - uiAnimationState.value) < 0.001F && Math.abs(getVelocity(uiAnimationState)) < 0.01F) {
            setValue(uiAnimationState, targetValue);
            uiAnimationState.velocity = 0.0F;
         }

         return uiAnimationState.value;
      }
   }

   public float springDefault(String string, float initialValue, float targetValue) {
      return this.spring(string, initialValue, targetValue, 0.32F, 0.78F);
   }

   public float exponential(String string, float initialValue, float targetValue, float halfLifeSeconds) {
      UiAnimationState uiAnimationState = this.getOrCreateState(string, initialValue);
      if (!isReducedMotion(this) && !(halfLifeSeconds <= 0.0F)) {
         float floatValue = 1.0F - (float)Math.pow(2.0, (double)(-this.deltaSeconds / halfLifeSeconds));
         setValue(uiAnimationState, uiAnimationState.value + (targetValue - uiAnimationState.value) * floatValue);
         if (Math.abs(targetValue - getValue(uiAnimationState)) < 1.0E-4F) {
            setValue(uiAnimationState, targetValue);
         }
      } else {
         uiAnimationState.value = targetValue;
      }

      setVelocity(uiAnimationState, 0.0F);
      return uiAnimationState.value;
   }

   public float getDeltaSeconds() {
      return this.deltaSeconds;
   }

   public static void setValue(UiAnimationState uiAnimationState, float value) {
      uiAnimationState.value = value;
   }

   public static long getFrameIndex(UiAnimations uiAnimations) {
      return uiAnimations.frameIndex;
   }

   public void beginFrame(float deltaSeconds2, boolean reducedMotion2) {
      this.deltaSeconds = Math.max(0.0F, Math.min(0.1F, deltaSeconds2));
      setReducedMotion(this, reducedMotion2);
      setFrameIndex(this, getFrameIndex(this) + 1L);
      if (getFrameIndex(this) % 120L == 0L || getStatesById(this).size() > 2048) {
         this.pruneStaleStates();
      }
   }

   private void pruneStaleStates() {
      Iterator iterator = getStatesById(this).entrySet().iterator();

      while (iterator.hasNext()) {
         if (this.frameIndex - getLastAccessFrame((UiAnimationState)((Entry)iterator.next()).getValue()) > 600L) {
            iterator.remove();
         }
      }

      if (getStatesById(this).size() > 2048) {
         getStatesById(this).clear();
      }
   }

   public float elapsed(String string) {
      UiAnimationState uiAnimationState = this.getOrCreateState(string, 0.0F);
      if (getLastAccessFrame(uiAnimationState) != getFrameIndex(this)) {
         setValue(uiAnimationState, uiAnimationState.value + getDeltaSeconds(this));
      }

      return getValue(uiAnimationState);
   }

   public void setValueForId(String string, float value) {
      UiAnimationState uiAnimationState = this.getOrCreateState(string, value);
      uiAnimationState.value = value;
      uiAnimationState.velocity = 0.0F;
   }

   public static float getValue(UiAnimationState uiAnimationState) {
      return uiAnimationState.value;
   }

   public float animateTo(String string, float targetValue, float halfLifeSeconds) {
      return this.exponential(string, targetValue, targetValue, halfLifeSeconds);
   }

   public float getValueOrDefault(String string, float defaultValue) {
      UiAnimationState uiAnimationState = getStatesById(this).get(string);
      return uiAnimationState == null ? defaultValue : uiAnimationState.value;
   }

   private UiAnimationState getOrCreateState(String string, float initialValue) {
      UiAnimationState uiAnimationState = getStatesById(this).get(string);
      if (uiAnimationState == null) {
         uiAnimationState = new UiAnimationState(initialValue);
         getStatesById(this).put(string, uiAnimationState);
      }

      uiAnimationState.lastAccessFrame = this.frameIndex;
      return uiAnimationState;
   }

}
