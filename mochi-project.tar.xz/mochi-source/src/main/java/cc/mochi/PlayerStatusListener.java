package cc.mochi;

import net.minecraft.entity.player.PlayerEntity;

public interface PlayerStatusListener {
   void onPlayerStatus(PlayerEntity playerEntity);
}
