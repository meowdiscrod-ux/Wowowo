package cc.mochi;

import java.awt.Color;

public class UiLayerAccess3 {
   public static TextInputModel getTextInputModel(ModuleBrowser moduleBrowser) {
      return moduleBrowser.textInputModel;
   }

   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }

   public static UiLayer getBASE() {
      return UiLayer.BASE;
   }

   public static TextStyle getSMALL() {
      return TextStyle.SMALL;
   }

   public static String getVERSION() {
      return MochiMetadata.VERSION;
   }

   public static Color getWHITE() {
      return Color.WHITE;
   }

   public static Icon getIcon(ClickGuiTab clickGuiTab) {
      return clickGuiTab.icon;
   }

   public static ClickGuiTab getSELF_DESTRUCT() {
      return ClickGuiTab.SELF_DESTRUCT;
   }

}
