package cc.mochi;

public class TextStyleAccess3 {
   public static TextStyle getCAPTION() {
      return TextStyle.CAPTION;
   }
}
