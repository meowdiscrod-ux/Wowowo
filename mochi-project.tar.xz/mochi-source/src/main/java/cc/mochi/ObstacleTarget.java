package cc.mochi;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public record ObstacleTarget(ObstacleKind kind, BlockPos cell, Vec3d aimPoint, double distance, int ticksAhead) {
   public static int getTicksAhead(ObstacleTarget obstacleTarget) {
      return obstacleTarget.ticksAhead;
   }

   public static double getDistance(ObstacleTarget obstacleTarget) {
      return obstacleTarget.distance;
   }

   public Vec3d getAimPoint() {
      return this.aimPoint;
   }

   public static ObstacleKind getKind(ObstacleTarget obstacleTarget) {
      return obstacleTarget.kind;
   }

   public double getDistance2() {
      return getDistance(this);
   }

   public int getTicksAhead2() {
      return getTicksAhead(this);
   }

   public ObstacleKind getKind2() {
      return getKind(this);
   }

   public BlockPos getCell() {
      return this.cell;
   }
}
