package cc.mochi;

import net.minecraft.client.MinecraftClient;
import org.joml.Vector4f;

public final class ScreenProjectionMath {
   private static final Vector4f vector4f = new Vector4f();

   public static float[] computeFloatArray(double doubleValue, double doubleValue2, double doubleValue3, double doubleValue4, double doubleValue5) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         int framebufferWidth = minecraftClient.getWindow().getFramebufferWidth();
         int framebufferHeight = minecraftClient.getWindow().getFramebufferHeight();
         float scale = UiViewport.getScale();
         float floatValue = (float)framebufferWidth / scale;
         float floatValue2 = (float)framebufferHeight / scale;
         double doubleValue6 = doubleValue4 * 0.2 + 0.05;
         double doubleValue7 = doubleValue4 + doubleValue6;
         double doubleValue8 = doubleValue2 - 0.06;
         double doubleValue9 = doubleValue2 + doubleValue5 + 0.12;
         float positiveInfinity = Float.POSITIVE_INFINITY;
         float positiveInfinity2 = Float.POSITIVE_INFINITY;
         float negativeInfinity = Float.NEGATIVE_INFINITY;
         float negativeInfinity2 = Float.NEGATIVE_INFINITY;
         boolean booleanValue = false;
         double[] doubleArray = new double[]{doubleValue - doubleValue7, doubleValue + doubleValue7};
         double[] doubleArray2 = new double[]{doubleValue8, doubleValue9};
         double[] doubleArray3 = new double[]{doubleValue3 - doubleValue7, doubleValue3 + doubleValue7};

         for (double doubleValue10 : doubleArray) {
            for (double doubleValue11 : doubleArray2) {
               for (double doubleValue12 : doubleArray3) {
                  vector4f.set((float)doubleValue10, (float)doubleValue11, (float)doubleValue12, 1.0F);
                  ProjectionMatrices.matrix4f.transform(vector4f);
                  ProjectionMatrices.matrix4f2.transform(vector4f);
                  float floatValue3 = vector4f.w();
                  if (!(floatValue3 <= 1.0E-5F)) {
                     float floatValue4 = vector4f.x() / floatValue3;
                     float floatValue5 = vector4f.y() / floatValue3;
                     if (Float.isFinite(floatValue4) && Float.isFinite(floatValue5)) {
                        booleanValue = true;
                        positiveInfinity = Math.min(positiveInfinity, floatValue4);
                        negativeInfinity = Math.max(negativeInfinity, floatValue4);
                        positiveInfinity2 = Math.min(positiveInfinity2, floatValue5);
                        negativeInfinity2 = Math.max(negativeInfinity2, floatValue5);
                     }
                  }
               }
            }
         }

         if (!booleanValue) {
            return null;
         } else {
            float floatValue6 = Math.max(0.0F, (float)framebufferWidth * (positiveInfinity * 0.5F + 0.5F) / scale);
            float floatValue7 = Math.min(floatValue, (float)framebufferWidth * (negativeInfinity * 0.5F + 0.5F) / scale);
            float floatValue8 = Math.max(0.0F, (float)framebufferHeight * (0.5F - negativeInfinity2 * 0.5F) / scale);
            float floatValue9 = Math.min(floatValue2, (float)framebufferHeight * (0.5F - positiveInfinity2 * 0.5F) / scale);
            float floatValue10 = floatValue7 - floatValue6;
            float floatValue11 = floatValue9 - floatValue8;
            if (!(floatValue10 < 2.0F) && !(floatValue11 < 2.0F)) {
               float floatValue12 = floatValue11 / (float)(doubleValue9 - doubleValue8);
               return new float[]{floatValue6, floatValue8, floatValue10, floatValue11, floatValue12};
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private ScreenProjectionMath() {
   }
}
