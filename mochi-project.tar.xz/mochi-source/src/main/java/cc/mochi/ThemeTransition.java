package cc.mochi;

import java.awt.Color;
import java.util.function.DoubleUnaryOperator;

public final class ThemeTransition {
   private static long longState = 420000000L;

   private static Theme theme;
   private static DoubleUnaryOperator doubleUnaryOperator = doubleValue -> computeDouble(doubleValue);

   private static Theme theme2;
   private static long timestampNanos;

   public static long getLongState() {
      return longState;
   }

   static void updateStateForTheme(Theme theme3, Theme theme22) {
      if (theme3 != null && theme22 != null && !theme3.equals(theme22)) {
         theme = computeTheme();
         setTheme2(theme22);
         timestampNanos = System.nanoTime();
      } else {
         updateState();
      }
   }

   public static boolean checkCondition() {
      return getTheme() != null && theme2 != null && System.nanoTime() - getTimestampNanos() < getLongState();
   }

   private static float computeFloat() {
      long longValue = System.nanoTime() - timestampNanos;
      if (longValue <= 0L) {
         return 0.0F;
      } else if (longValue >= getLongState()) {
         return 1.0F;
      } else {
         float floatValue = (float)longValue / (float)getLongState();
         return (float)doubleUnaryOperator.applyAsDouble((double)floatValue);
      }
   }

   public static void setTheme2(Theme theme22) {
      theme2 = theme22;
   }

   public static Theme getTheme() {
      return theme;
   }

   public static long getTimestampNanos() {
      return timestampNanos;
   }

   public static void updateState() {
      setTheme(null);
      setTheme2(null);
   }

   private static Color createColor(Color color, Color color2, float floatValue) {
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }

   public static void setTheme(Theme theme3) {
      theme = theme3;
   }

   private static Theme computeThemeForTheme(Theme theme3, Theme theme4, float floatValue) {
      if (floatValue <= 0.0F) {
         return theme3;
      } else {
         return floatValue >= 1.0F
            ? theme4
            : new Theme(
               theme4.getName(),
               createColor(theme3.getBackdropDim(), theme4.getBackdropDim(), floatValue),
               createColor(theme3.getShellGlass22(), theme4.getShellGlass22(), floatValue),
               createColor(theme3.getCardGlass(), theme4.getCardGlass(), floatValue),
               createColor(theme3.getControlGlass2(), theme4.getControlGlass2(), floatValue),
               createColor(theme3.getBorder2(), theme4.getBorder2(), floatValue),
               createColor(theme3.getInnerHighlight(), theme4.getInnerHighlight(), floatValue),
               createColor(theme3.getShadow2(), theme4.getShadow2(), floatValue),
               createColor(theme3.getGlow2(), theme4.getGlow2(), floatValue),
               createColor(theme3.getPrimaryText3(), theme4.getPrimaryText3(), floatValue),
               createColor(theme3.getSecondaryText(), theme4.getSecondaryText(), floatValue),
               createColor(theme3.getDisabledText(), theme4.getDisabledText(), floatValue),
               createColor(theme3.getAccent2(), theme4.getAccent2(), floatValue),
               createColor(theme3.getSecondaryAccent(), theme4.getSecondaryAccent(), floatValue),
               createColor(theme3.getGradientStart22(), theme4.getGradientStart22(), floatValue),
               createColor(theme3.getGradientMid2(), theme4.getGradientMid2(), floatValue),
               createColor(theme3.getGradientEnd3(), theme4.getGradientEnd3(), floatValue),
               createColor(theme3.getDanger(), theme4.getDanger(), floatValue),
               floatValue >= 0.5F ? theme4.getLight() : theme3.getLight()
            );
      }
   }

   private static Theme computeTheme() {
      Theme theme3 = ThemeManager.getOrDefault();
      return theme == null ? theme3 : computeThemeForTheme(theme, theme3, computeFloat());
   }

   private static double computeDouble(double doubleValue) {
      return doubleValue < 0.5 ? 4.0 * doubleValue * doubleValue * doubleValue : 1.0 - Math.pow(((-2.0)) * doubleValue + 2.0, 3.0) / 2.0;
   }

   private ThemeTransition() {
   }

   public static Theme computeTheme2() {
      Theme theme3 = ThemeManager.getOrDefault();
      if (theme != null && getTheme2() != null && theme2 == theme3) {
         float floatValue = computeFloat();
         if (floatValue >= 1.0F) {
            setTheme(null);
            theme2 = null;
            return theme3;
         } else {
            return computeThemeForTheme(theme, theme3, floatValue);
         }
      } else {
         return theme3;
      }
   }

   public static Theme getTheme2() {
      return theme2;
   }

}
