package cc.mochi;

public enum WebRotationState {
   IDLE,
   ROTATING,
   SETTLING;

   private static WebRotationState[] computeWebRotationStateArray() {
      WebRotationState[] webRotationStateArray = new WebRotationState[]{IDLE, null, null};

      webRotationStateArray[1] = ROTATING;
      webRotationStateArray[2] = SETTLING;
      return webRotationStateArray;
   }
}
