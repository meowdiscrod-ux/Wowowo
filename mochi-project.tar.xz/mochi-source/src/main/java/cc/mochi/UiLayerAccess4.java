package cc.mochi;

public class UiLayerAccess4 {
   public static UiLayer getPOPOVER() {
      return UiLayer.POPOVER;
   }

   public static UiLayer getRAISED() {
      return UiLayer.RAISED;
   }
}
