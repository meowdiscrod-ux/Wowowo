package cc.mochi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;

public abstract class Module implements MinecraftAccess {
   private final List<Setting> settings = new ArrayList<>();
   protected static final MinecraftClient mc = MinecraftClient.getInstance();
   private final String description;
   private final KeybindSetting keybind;
   private final ModuleCategory category;
   private boolean subscribedToEvents;

   private boolean enabled;
   private final String name;

   private int keyCode;

   private String displaySuffix;

   public static MinecraftClient getMc() {
      return mc;
   }

   public static void setSubscribedToEvents2(Module module, boolean subscribedToEvents2) {
      module.subscribedToEvents = subscribedToEvents2;
   }

   public static ModuleCategory getCategory2(Module module) {
      return module.category;
   }

   public void addSetting(Setting setting) {
      this.settings.add(setting);
   }

   public static void setEnabled2(Module module, boolean enabled2) {
      module.enabled = enabled2;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getName() {
      return this.name;
   }

   public void onEnable() {
   }

   public static String getDisplaySuffix2(Module module) {
      return module.displaySuffix;
   }

   public static List<Setting> getSettings2(Module module) {
      return module.settings;
   }

   public String getDescription() {
      return this.description;
   }

   public String getDisplaySuffix() {
      return getDisplaySuffix2(this);
   }

   public final void setEnabled(boolean enabled2) {
      if ((this.enabled != enabled2)) {
         setEnabled2(this, enabled2);
         if (enabled2) {
            this.onEnable();
            if (this.enabled) {
               MochiClient.INSTANCE.getMochiEventBus().subscribe(this);
               this.subscribedToEvents = true;
               if (mc.player != null) {
                  ClientSounds.toggleOn();
               }
               NotificationManager notificationManager = NotificationManager.getINSTANCE();

               notificationManager.updateStateForModule(this, true);
            }
         } else {
            if (getSubscribedToEvents(this)) {
               MochiClientAccess2.getINSTANCE().getMochiEventBus().unsubscribe(this);

               setSubscribedToEvents2(this, false);
            }

            this.onDisable();
            if (mc.player != null) {
               ClientSounds.toggleOff();
            }
            NotificationManager.getINSTANCE().updateStateForModule(this, false);
         }
      }
   }

   public static KeybindSetting getKeybind2(Module module) {
      return module.keybind;
   }

   public boolean checkCondition15() {
      return false;
   }

   public void addSettings(Setting... settingArray) {
      getSettings2(this).addAll(Arrays.asList(settingArray));
   }

   public Module(String name2, String description2, int keyCode2, ModuleCategory category2) {
      this.name = name2;
      this.description = description2;
      this.keyCode = keyCode2;
      this.category = category2;
      this.enabled = false;
      this.keybind = new KeybindSetting("Keybind", keyCode2, true);
      this.addSetting(this.keybind);
   }

   public void setKeyCode(int keyCode2) {
      this.keyCode = keyCode2;
      if (getKeybind2(this) != null) {
         this.keybind.setKeyCode(keyCode2);
      } else {
         ThreadLocalRandom.current().nextInt(8);
      }
   }

   public void disableSilently() {
      setEnabled2(this, false);
      if (this.subscribedToEvents) {
         MochiClientAccess2.getINSTANCE().getMochiEventBus().unsubscribe(this);
         setSubscribedToEvents2(this, false);
      }

      this.onDisable();
   }

   public static boolean getSubscribedToEvents(Module module) {
      return module.subscribedToEvents;
   }

   public void toggle() {
      byte byteValue;
      if (!this.enabled) {
         byteValue = 1;
      } else {
         byteValue = 17;
         ThreadLocalRandom.current().nextInt(9);
         byteValue = 0;
      }

      this.setEnabled((byteValue != 0));
   }

   public boolean isWorldUnavailable() {
      if (MochiClientAccess2.getPlayer(mc) != null) {
         ThreadLocalRandom.current().nextInt(3);
         if (getMc().world != null) {
            return false;
         }
      }

      return true;
   }

   public void setDisplaySuffix(String displaySuffix2) {
      this.displaySuffix = displaySuffix2;
   }

   public ModuleCategory getCategory() {
      return getCategory2(this);
   }

   public Module(String name2, String description2, ModuleCategory category2) {
      this(name2, description2, -1, category2);
   }

   public void setSubscribedToEvents(boolean subscribedToEvents2) {
      setSubscribedToEvents2(this, subscribedToEvents2);
   }

   public void onDisable() {
   }

   public KeybindSetting getKeybind() {
      return this.keybind;
   }

   public int getKeyCode() {
      if (this.keybind != null) {
         return getKeybind2(this).getKeyCode();
      } else {
         return this.keyCode;
      }
   }

   public boolean isSubscribedToEvents() {
      return this.subscribedToEvents;
   }

   public List getSettings() {
      return this.settings;
   }
}
